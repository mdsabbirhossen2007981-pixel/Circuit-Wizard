# Circuit Wizard ProGuard / R8 Keep Rules

-keepattributes Signature,InnerClasses,EnclosingMethod
-keepattributes *Annotation*

# Preserve Moshi reflective & codegen JSON models
-keep class com.example.domain.model.** { *; }
-keepclassmembers class com.example.domain.model.** { *; }
-keep class * extends com.squareup.moshi.JsonAdapter { *; }

# Preserve Room database & entities
-keep class * extends androidx.room.RoomDatabase
-keep class com.example.data.local.db.entity.** { *; }

# Keep stack trace line numbers for diagnostics
-keepattributes SourceFile,LineNumberTable
