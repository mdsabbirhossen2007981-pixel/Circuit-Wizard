package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.CircuitDatabase
import com.example.data.repository.LabProjectRepository
import com.example.domain.lab.LabComponentCatalog
import com.example.domain.model.LabCategory
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabInstrumentState
import com.example.domain.model.LabInstrumentType
import com.example.domain.model.LabRenderMode
import com.example.domain.model.LabWire
import com.example.domain.model.LabWireColor
import com.example.domain.model.PinEndpoint
import com.example.domain.model.PlacedComponent
import com.example.domain.model.WireRouteStyle
import com.example.simulation.NetlistExtractor
import com.example.simulation.SimulationStatus
import com.example.ui.lab.LabCamera3D
import com.example.ui.lab.LabWorkspaceViewModel
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CircuitWizardPhase3Test {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun labCatalogCoversAll21CategoriesWithValidPinsAndStarterBench() {
        val presentCategories = LabComponentCatalog.all.map { it.category }.toSet()
        for (category in LabCategory.entries) {
            assertTrue("Missing 3D Lab category: ${category.name}", category in presentCategories)
        }
        assertEquals(21, presentCategories.size)

        for (def in LabComponentCatalog.all) {
            assertTrue("${def.typeId} missing pins", def.pins.isNotEmpty())
            assertTrue("${def.typeId} missing bilingual names", def.nameEn.isNotBlank() && def.nameBn.isNotBlank())
        }

        val starter = LabComponentCatalog.defaultLedCircuitStarter()
        assertTrue(starter.components.size >= 4)
        assertTrue(starter.wires.size >= 6)
        assertEquals(5, starter.instruments.size)
    }

    @Test
    fun camera3DProjectionAndGroundUnprojectionRoundTripIsExact() {
        val cam3D = LabCamera3D(
            yawDeg = -22f,
            pitchDeg = 42f,
            zoom = 1.35f,
            panX = 28f,
            panY = -16f,
            renderMode = LabRenderMode.PERSPECTIVE_3D
        )
        val viewW = 1080f
        val viewH = 720f

        for ((col, row) in listOf(0f to 0f, 14.5f to 5.5f, 29f to 13f, 6f to -2f)) {
            val projected = cam3D.projectWorldToScreen(col, row, 0f, viewW, viewH)
            val (uCol, uRow) = cam3D.screenToWorldGround(projected.offset.x, projected.offset.y, viewW, viewH)
            assertEquals("Col round-trip mismatch in 3D", col, uCol, 0.02f)
            assertEquals("Row round-trip mismatch in 3D", row, uRow, 0.02f)
        }

        val cam2D = cam3D.toggleMode()
        assertEquals(LabRenderMode.LIGHTWEIGHT_2D, cam2D.renderMode)
        val p2d = cam2D.projectWorldToScreen(9f, 7f, 0f, viewW, viewH)
        val (u2Col, u2Row) = cam2D.screenToWorldGround(p2d.offset.x, p2d.offset.y, viewW, viewH)
        assertEquals(9f, u2Col, 0.01f)
        assertEquals(7f, u2Row, 0.01f)
    }

    @Test
    fun netlistExtractorDetectsBreadboardContinuityRailShortsAndPreventsBadWires() = runBlocking {
        // Breadboard bus rules
        assertEquals("RAIL_TOP_POS", NetlistExtractor.breadboardBusKey(4, -2))
        assertEquals("RAIL_TOP_POS", NetlistExtractor.breadboardBusKey(29, -2))
        assertEquals("RAIL_BOT_NEG", NetlistExtractor.breadboardBusKey(12, 13))
        assertEquals("COL_5_TOP", NetlistExtractor.breadboardBusKey(5, 0))
        assertEquals("COL_5_TOP", NetlistExtractor.breadboardBusKey(5, 4))
        assertEquals("COL_5_BOT", NetlistExtractor.breadboardBusKey(5, 6))
        assertEquals(null, NetlistExtractor.breadboardBusKey(5, 5)) // center trench

        // Starter LED bench has no rail short
        val starter = LabComponentCatalog.defaultLedCircuitStarter()
        val starterNet = NetlistExtractor.stageNetlist(starter)
        assertFalse(starterNet.railShortDetected)
        assertEquals(4, starterNet.componentCount)
        assertEquals(6, starterNet.wireCount)
        assertTrue(starterNet.activeNodeCount >= 3)

        // Short top '+' and '-' rails cleanly sets railShortDetected = true
        val shorted = starter.copy(
            wires = starter.wires + LabWire(
                id = "short_wire",
                start = PinEndpoint(true, holeCol = 0, holeRow = -2),
                end = PinEndpoint(true, holeCol = 0, holeRow = -1)
            )
        )
        assertTrue(NetlistExtractor.stageNetlist(shorted).railShortDetected)

        // ViewModel self-loop & duplicate wire guard + Room save/load round-trip
        val context = ApplicationProvider.getApplicationContext<Context>()
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val db = Room.inMemoryDatabaseBuilder(context, CircuitDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = LabProjectRepository(db.labProjectDao(), moshi)
            val vm = LabWorkspaceViewModel(repo, UserPrefsStore(context))
            val initialWireCount = vm.uiState.value.snapshot.wires.size

            // Prevent self-loop wire
            val holeA = PinEndpoint(true, holeCol = 20, holeRow = 2)
            vm.beginOrCompleteWire(holeA)
            vm.beginOrCompleteWire(holeA)
            assertEquals(initialWireCount, vm.uiState.value.snapshot.wires.size)

            // Add valid wire then duplicate -> only +1 wire
            val holeB = PinEndpoint(true, holeCol = 22, holeRow = 2)
            vm.beginOrCompleteWire(holeA)
            vm.beginOrCompleteWire(holeB)
            assertEquals(initialWireCount + 1, vm.uiState.value.snapshot.wires.size)

            vm.beginOrCompleteWire(holeB)
            vm.beginOrCompleteWire(holeA)
            assertEquals(initialWireCount + 1, vm.uiState.value.snapshot.wires.size)

            // Save custom snapshot via Repository and reload intact
            val savedId = repo.saveProject(
                LabCircuitSnapshot(
                    projectName = "LM358 OpAmp Rig",
                    components = listOf(
                        PlacedComponent("ic1", "ic_lm358", 8f, 4f, 0, mapOf("part" to "LM358")),
                        PlacedComponent("r1", "resistor", 14f, 2f, 90, mapOf("value" to "4.7", "unit" to "kΩ"))
                    ),
                    wires = listOf(
                        LabWire("w1", holeA, holeB, LabWireColor.PURPLE.key, WireRouteStyle.MANHATTAN.name, 1.1f)
                    ),
                    instruments = listOf(
                        LabInstrumentState(LabInstrumentType.DIGITAL_MULTIMETER.name, "VDC", "IC:OUT1", "GND", isEnabled = true)
                    )
                )
            )
            val reloaded = repo.loadProject(savedId)
            assertNotNull(reloaded)
            assertEquals("LM358 OpAmp Rig", reloaded!!.projectName)
            assertEquals(2, reloaded.components.size)
            assertEquals("4.7", reloaded.components[1].properties["value"])
            assertEquals(LabWireColor.PURPLE.key, reloaded.wires.first().colorKey)
            assertEquals("IC:OUT1", reloaded.instruments.first().positiveProbeKey)

            val list = repo.observeSavedProjects().first()
            assertEquals(1, list.size)
            repo.deleteProject(savedId)
            assertTrue(repo.observeSavedProjects().first().isEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun endToEndVirtualLabLibraryPropertiesUndoSimulationAndSaveCuj() {
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("nav_lab").fetchSemanticsNodes().isNotEmpty()
        }

        // Switch to 3D Virtual Lab tab
        composeRule.onNodeWithTag("nav_lab").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("virtual_lab_screen").fetchSemanticsNodes().isNotEmpty()
        }

        // Verify key controls across the 14+ item toolbar are present
        composeRule.onNodeWithTag("tool_select").assertIsDisplayed()
        composeRule.onNodeWithTag("tool_wire").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("lab_parts_button").performScrollTo().performClick()

        // Open Library, search & place a Resistor
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("lab_library_panel").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("lab_part_search_input").performTextInput("resistor")
        composeRule.onNodeWithTag("lab_catalog_item_resistor").performClick()
        composeRule.waitForIdle()

        // Newly placed resistor is selected -> open Properties & modify value + rotate + duplicate
        composeRule.onNodeWithTag("lab_properties_button").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("prop_resistor_value_input").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("prop_resistor_value_input").performTextClearance()
        composeRule.onNodeWithTag("prop_resistor_value_input").performTextInput("470")
        composeRule.onNodeWithTag("prop_unit_kΩ").performClick()
        composeRule.onNodeWithTag("lab_properties_button").performScrollTo().performClick() // close drawer

        composeRule.onNodeWithTag("lab_rotate").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_duplicate").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_undo").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_redo").performScrollTo().performClick()

        // Camera 3D/2D & Zoom controls
        composeRule.onNodeWithTag("lab_zoom_in").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_mode_3d_2d").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_reset_cam").performScrollTo().performClick()

        // Measurement Instruments drawer (Phase 4 staged state)
        composeRule.onNodeWithTag("lab_meters_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_instruments_panel").assertIsDisplayed()
        composeRule.onNodeWithTag("lab_meters_button").performScrollTo().performClick()

        // Simulation Transport Bar (Run -> Pause -> Stop -> Reset)
        composeRule.onNodeWithTag("sim_run_button").performClick()
        composeRule.waitUntil(timeoutMillis = 3_000) {
            composeRule.onAllNodesWithText("Running", substring = true)
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("sim_pause_button").performClick()
        composeRule.onNodeWithTag("sim_stop_button").performClick()
        composeRule.onNodeWithTag("sim_reset_button").performClick()

        // Save Project via Room dialog
        composeRule.onNodeWithTag("lab_save_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_save_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("lab_save_name_input").performTextClearance()
        composeRule.onNodeWithTag("lab_save_name_input").performTextInput("Phase3 Verify Bench")
        composeRule.onNodeWithTag("lab_save_confirm_button").performClick()
        composeRule.waitForIdle()

        // Open Load dialog & verify saved item appears
        composeRule.onNodeWithTag("lab_load_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("lab_load_dialog").assertIsDisplayed()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("Phase3 Verify Bench", substring = true)
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("lab_load_starter_button").performClick()

        // Confirm Phase 1 Book & Phase 2 Academy still work
        composeRule.onNodeWithTag("nav_book").performClick()
        composeRule.onNodeWithTag("nav_academy").performClick()
        composeRule.waitForIdle()
    }
}
