package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.localization.AppLanguage
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.CircuitDatabase
import com.example.data.local.seed.DatabaseSeeder
import com.example.data.repository.ComponentRepository
import com.example.domain.model.ComponentCategory
import com.example.domain.model.ComponentSeedPayload
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CircuitWizardPhase1Test {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun allSeedCatalogFilesParseCleanlyAndCoverAll11Categories() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val listType = Types.newParameterizedType(List::class.java, ComponentSeedPayload::class.java)
        val adapter = moshi.adapter<List<ComponentSeedPayload>>(listType)

        val files = context.assets.list("seed")
            ?.filter { it.startsWith("catalog_") && it.endsWith(".json") }
            ?.sorted()
            .orEmpty()
        assertTrue("Expected seed catalog files", files.isNotEmpty())

        val allPayloads = mutableListOf<ComponentSeedPayload>()
        for (file in files) {
            val raw = context.assets.open("seed/$file").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val parsed = adapter.fromJson(raw)
            assertNotNull("Failed parsing $file", parsed)
            allPayloads += parsed.orEmpty()
        }

        // Verify unique IDs and full A..K coverage
        val idSet = allPayloads.map { it.id }.toSet()
        assertEquals("Duplicate component IDs found", allPayloads.size, idSet.size)
        assertTrue("Expected at least 100 components across A-K, got ${allPayloads.size}", allPayloads.size >= 110)

        val categoriesPresent = allPayloads.map { it.categoryId }.toSet()
        for (cat in ComponentCategory.entries) {
            assertTrue("Missing category ${cat.id}", cat.id in categoriesPresent)
        }

        // Verify every relatedComponentId resolves and bilingual fields are non-blank
        for (p in allPayloads) {
            assertTrue("${p.id} missing nameEn", p.nameEn.isNotBlank())
            assertTrue("${p.id} missing nameBn", p.nameBn.isNotBlank())
            assertTrue("${p.id} missing introductionEn", p.introductionEn.isNotBlank())
            assertTrue("${p.id} missing introductionBn", p.introductionBn.isNotBlank())
            for (relId in p.relatedComponentIds) {
                assertTrue("${p.id} references unknown related ID: $relId", relId in idSet)
            }
        }
    }

    @Test
    fun repositoryAndPrefsPersistBookmarksViewsAndLanguage() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val prefs = UserPrefsStore(context)
        val db = Room.inMemoryDatabaseBuilder(context, CircuitDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        try {
            val seeder = DatabaseSeeder(context, db.componentDao(), prefs, moshi)
            val repo = ComponentRepository(db.componentDao(), seeder, moshi)
            repo.initializeCatalog()

            val all = repo.observeAllComponents().first()
            assertTrue(all.size >= 110)

            // Toggle bookmark and studied on resistor
            repo.toggleBookmark("resistor")
            repo.toggleStudied("resistor")
            repo.recordComponentView("resistor")

            val resistor = repo.observeComponentById("resistor").first()
            assertNotNull(resistor)
            assertTrue(resistor!!.isBookmarked)
            assertTrue(resistor.isStudied)
            assertTrue(resistor.viewCount >= 1)

            val recent = repo.observeRecentlyViewed(5).first()
            assertTrue(recent.any { it.id == "resistor" })

            // Verify theme & language preferences
            prefs.setDarkTheme(false)
            assertFalse(prefs.isDarkTheme.first())
            prefs.setDarkTheme(true)
            assertTrue(prefs.isDarkTheme.first())

            prefs.setLanguage(AppLanguage.BANGLA)
            assertEquals(AppLanguage.BANGLA, prefs.language.first())
            prefs.setLanguage(AppLanguage.ENGLISH)
        } finally {
            db.close()
        }
    }

    @Test
    fun endToEndTextbookBrowseDetailBookmarkAndLanguageCuj() {
        // Wait until seeded components appear on Home (continue_learning_button renders once DB is seeded)
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("continue_learning_button").fetchSemanticsNodes().isNotEmpty()
        }

        composeRule.onNodeWithTag("textbook_hero_card").assertIsDisplayed()
        composeRule.onNodeWithTag("book_home_list").performScrollToNode(hasTestTag("category_card_a"))
        composeRule.onNodeWithTag("category_card_a").assertIsDisplayed()

        // Scroll back up to search bar and search for resistor
        composeRule.onNodeWithTag("book_home_list").performScrollToIndex(0)
        composeRule.onNodeWithTag("home_search_input").performScrollTo()
        composeRule.onNodeWithTag("home_search_input").performTextInput("resistor")
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("book_home_list").performScrollToNode(hasTestTag("component_card_resistor"))

        // Open resistor detail page
        composeRule.onNodeWithTag("component_card_resistor").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("detail_studied_button").fetchSemanticsNodes().isNotEmpty()
        }

        // Switch visual tabs & toggle bookmark + studied
        composeRule.onNodeWithTag("visual_tab_1").performClick()
        composeRule.onNodeWithTag("visual_tab_2").performClick()
        composeRule.onNodeWithTag("detail_bookmark_button").performClick()
        composeRule.onNodeWithTag("detail_studied_button").performClick()
        composeRule.onNodeWithTag("component_detail_list").performScrollToNode(hasTestTag("level_advanced_button"))
        composeRule.onNodeWithTag("level_advanced_button").performClick()
        composeRule.waitForIdle()

        // Go back to Home & clear search
        composeRule.onNodeWithTag("detail_back_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("book_home_list").performScrollToNode(hasTestTag("home_search_input_clear"))
        composeRule.onNodeWithTag("home_search_input_clear").performClick()

        // Navigate to Settings and switch language to Bangla
        composeRule.onNodeWithTag("nav_settings").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("language_bn_option").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("language_bn_option").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("nav_book").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("nav_book").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("book_home_list").performScrollToIndex(0)
        composeRule.onNodeWithText("সার্কিট উইজার্ড").assertIsDisplayed()

        // Switch back to English cleanly
        composeRule.onNodeWithTag("nav_settings").performClick()
        composeRule.onNodeWithTag("language_en_option").performScrollTo().performClick()
        composeRule.waitForIdle()
    }
}
