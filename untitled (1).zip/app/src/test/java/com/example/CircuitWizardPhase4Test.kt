package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabWire
import com.example.domain.model.PinEndpoint
import com.example.domain.model.PlacedComponent
import com.example.simulation.CircuitMnaSolver
import com.example.simulation.CircuitTransientState
import com.example.simulation.ComponentSupportLevel
import com.example.simulation.NetlistExtractor
import com.example.simulation.WarningCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CircuitWizardPhase4Test {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    private fun pin(compId: String, pinId: String) =
        PinEndpoint(isBreadboardHole = false, componentId = compId, pinId = pinId)

    @Test
    fun test1_dcSourceAndResistorOhmsLaw() {
        val snap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("psu", "dc_psu", 0f, -8f, properties = mapOf("voltage" to "5.0", "currentLimit" to "2.0", "state" to "ON")),
                PlacedComponent("r1", "resistor", 6f, 2f, properties = mapOf("value" to "1", "unit" to "kΩ"))
            ),
            wires = listOf(
                LabWire("w1", pin("psu", "pos"), pin("r1", "p1")),
                LabWire("w2", pin("r1", "p2"), pin("psu", "neg"))
            )
        )
        val res = CircuitMnaSolver.stepTransient(snap, CircuitTransientState(), 0.01)
        assertTrue(res.converged)
        val rReading = res.componentReadings.getValue("r1")
        assertEquals(5.0, rReading.currentMa, 0.05)
        assertEquals(5.0, rReading.voltageDropV, 0.01)
        assertEquals(25.0, rReading.powerMw, 0.25)
        assertTrue(rReading.isConducting)
        assertFalse(rReading.isFloating)
    }

    @Test
    fun test2_ledWithSeriesResistorLightsProportionally() {
        val snap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("psu", "dc_psu", 0f, -8f, properties = mapOf("voltage" to "5.0", "state" to "ON")),
                PlacedComponent("r1", "resistor", 5f, 2f, properties = mapOf("value" to "330", "unit" to "Ω")),
                PlacedComponent("led1", "led_5mm", 12f, 2f, properties = mapOf("color" to "Red", "vf" to "2.0", "maxMa" to "20"))
            ),
            wires = listOf(
                LabWire("w1", pin("psu", "pos"), pin("r1", "p1")),
                LabWire("w2", pin("r1", "p2"), pin("led1", "anode")),
                LabWire("w3", pin("led1", "cathode"), pin("psu", "neg"))
            )
        )
        val res = CircuitMnaSolver.stepTransient(snap, CircuitTransientState(), 0.01)
        assertTrue(res.converged)
        val led = res.componentReadings.getValue("led1")
        assertTrue("Expected forward LED current ~7-11 mA, was ${led.currentMa}", led.currentMa in 7.0..11.5)
        assertTrue("Expected positive brightness, was ${led.brightnessFraction}", led.brightnessFraction > 0.30f)
        assertTrue(led.isConducting)
        assertFalse(led.isReverseBiased)
    }

    @Test
    fun test3_reverseBiasedLedBlocksCurrentAndWarns() {
        val snap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("psu", "dc_psu", 0f, -8f, properties = mapOf("voltage" to "5.0", "state" to "ON")),
                PlacedComponent("r1", "resistor", 5f, 2f, properties = mapOf("value" to "330", "unit" to "Ω")),
                PlacedComponent("led1", "led_5mm", 12f, 2f, properties = mapOf("color" to "Red", "vf" to "2.0", "maxMa" to "20"))
            ),
            wires = listOf(
                LabWire("w1", pin("psu", "pos"), pin("r1", "p1")),
                LabWire("w2", pin("r1", "p2"), pin("led1", "cathode")),
                LabWire("w3", pin("led1", "anode"), pin("psu", "neg"))
            )
        )
        val res = CircuitMnaSolver.stepTransient(snap, CircuitTransientState(), 0.01)
        val led = res.componentReadings.getValue("led1")
        assertTrue("Reverse current should be negligible, was ${led.currentMa}", abs(led.currentMa) < 0.01)
        assertEquals(0f, led.brightnessFraction, 0.001f)
        assertTrue(led.isReverseBiased)
        assertTrue(res.warnings.any { it.category == WarningCategory.REVERSE_POLARITY && it.componentId == "led1" })
    }

    @Test
    fun test4_openSwitchInterruptsCurrent() {
        val snap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("psu", "dc_psu", 0f, -8f, properties = mapOf("voltage" to "5.0", "state" to "ON")),
                PlacedComponent("sw1", "slide_switch", 4f, 7f, properties = mapOf("state" to "OFF")),
                PlacedComponent("r1", "resistor", 10f, 2f, properties = mapOf("value" to "330", "unit" to "Ω")),
                PlacedComponent("led1", "led_5mm", 18f, 2f, properties = mapOf("color" to "Green", "vf" to "2.2", "maxMa" to "20"))
            ),
            wires = listOf(
                LabWire("w1", pin("psu", "pos"), pin("sw1", "t1")),
                LabWire("w2", pin("sw1", "com"), pin("r1", "p1")),
                LabWire("w3", pin("r1", "p2"), pin("led1", "anode")),
                LabWire("w4", pin("led1", "cathode"), pin("psu", "neg"))
            )
        )
        val res = CircuitMnaSolver.stepTransient(snap, CircuitTransientState(), 0.01)
        val led = res.componentReadings.getValue("led1")
        assertTrue("Open switch should interrupt current, was ${led.currentMa}", abs(led.currentMa) < 0.001)
        assertEquals(0f, led.brightnessFraction, 0.001f)
    }

    @Test
    fun test5_shortCircuitTriggersWarningWithoutSolverCrash() {
        val snap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("psu", "dc_psu", 0f, -8f, properties = mapOf("voltage" to "5.0", "currentLimit" to "1.5", "state" to "ON"))
            ),
            wires = listOf(
                LabWire("w_short", pin("psu", "pos"), pin("psu", "neg"))
            )
        )
        val res = CircuitMnaSolver.stepTransient(snap, CircuitTransientState(), 0.01)
        assertTrue(res.converged)
        assertTrue(res.warnings.any { it.category == WarningCategory.SHORT_CIRCUIT })
        val psu = res.componentReadings.getValue("psu")
        assertTrue(psu.voltageDropV.isFinite())
        assertTrue(psu.currentMa.isFinite())
    }

    @Test
    fun test6_rcCircuitChargesAndDischargesRealistically() {
        // 5V source -> SPDT slide_switch (t1=+5V, t2=GND) -> 10kΩ resistor -> 100µF cap -> GND
        // Time constant tau = 10kΩ * 100µF = 1.0 s
        val state = CircuitTransientState()
        val baseComponents = listOf(
            PlacedComponent("psu", "dc_psu", 0f, -8f, properties = mapOf("voltage" to "5.0", "state" to "ON")),
            PlacedComponent("sw", "slide_switch", 4f, 7f, properties = mapOf("state" to "ON")),
            PlacedComponent("r1", "resistor", 10f, 2f, properties = mapOf("value" to "10", "unit" to "kΩ")),
            PlacedComponent("c1", "cap_electrolytic", 18f, 2f, properties = mapOf("capacitance" to "100", "unit" to "µF", "voltageRating" to "25V"))
        )
        val wires = listOf(
            LabWire("w1", pin("psu", "pos"), pin("sw", "t1")),
            LabWire("w2", pin("psu", "neg"), pin("sw", "t2")),
            LabWire("w3", pin("sw", "com"), pin("r1", "p1")),
            LabWire("w4", pin("r1", "p2"), pin("c1", "pos")),
            LabWire("w5", pin("c1", "neg"), pin("psu", "neg"))
        )

        var snap = LabCircuitSnapshot(components = baseComponents, wires = wires)
        // Charge for 1.0 second (50 steps of 20ms)
        var lastResult = CircuitMnaSolver.stepTransient(snap, state, 0.02)
        repeat(49) {
            lastResult = CircuitMnaSolver.stepTransient(snap, state, 0.02)
        }
        val vAt1Tau = lastResult.componentReadings.getValue("c1").voltageDropV
        // 5.0 * (1 - exp(-1)) = 3.1606 V (Backward Euler with dt=20ms is ~3.14V)
        assertTrue("Expected VC(1 tau) around 3.16V, got $vAt1Tau", vAt1Tau in 2.95..3.35)

        // Toggle switch OFF so com bridges to t2 (GND) -> capacitor discharges cleanly
        snap = snap.copy(
            components = baseComponents.map { if (it.instanceId == "sw") it.copy(properties = mapOf("state" to "OFF")) else it }
        )
        repeat(100) {
            lastResult = CircuitMnaSolver.stepTransient(snap, state, 0.02)
        }
        val vAfterDischarge = lastResult.componentReadings.getValue("c1").voltageDropV
        assertTrue("Expected capacitor discharge near <0.6V after 2 tau, got $vAfterDischarge", vAfterDischarge < 0.65)
    }

    @Test
    fun test7_disconnectedFloatingCircuitDetected() {
        val snap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("r1", "resistor", 5f, 2f, properties = mapOf("value" to "1", "unit" to "kΩ")),
                PlacedComponent("led1", "led_5mm", 14f, 2f, properties = mapOf("color" to "Red"))
            ),
            wires = emptyList()
        )
        val res = CircuitMnaSolver.stepTransient(snap, CircuitTransientState(), 0.01)
        val rReading = res.componentReadings.getValue("r1")
        assertTrue(rReading.isFloating)
        assertEquals(0.0, rReading.currentMa, 1e-6)
        assertTrue(res.warnings.any { it.category == WarningCategory.FLOATING_NODE })
    }

    @Test
    fun additionalSemiconductorRelayAndMotorModelsValidateCleanly() {
        // Zener 5.1V regulator with 9V & 470Ω
        val zenerSnap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("bat", "battery_9v", 0f, -8f, properties = mapOf("voltage" to "9.0")),
                PlacedComponent("r1", "resistor", 5f, 2f, properties = mapOf("value" to "470", "unit" to "Ω")),
                PlacedComponent("z1", "diode_zener", 12f, 2f, properties = mapOf("vz" to "5.1"))
            ),
            wires = listOf(
                LabWire("w1", pin("bat", "pos"), pin("r1", "p1")),
                LabWire("w2", pin("r1", "p2"), pin("z1", "cathode")),
                LabWire("w3", pin("z1", "anode"), pin("bat", "neg"))
            )
        )
        val zRes = CircuitMnaSolver.stepTransient(zenerSnap, CircuitTransientState(), 0.01)
        val vCathode = zRes.componentReadings.getValue("z1").pinVoltagesV.getValue("cathode")
        assertTrue("Expected Zener clamping ~4.2-5.4V, got $vCathode", vCathode in 4.0..5.6)

        // Relay 5V pickup energizes NO contact & spins DC motor
        val relayMotorSnap = LabCircuitSnapshot(
            components = listOf(
                PlacedComponent("psu", "dc_psu", 0f, -8f, properties = mapOf("voltage" to "5.0", "state" to "ON")),
                PlacedComponent("rel", "relay_5v", 8f, 4f, properties = mapOf("coilV" to "5.0", "coilOhms" to "70")),
                PlacedComponent("mot", "dc_motor", 18f, 16f, properties = mapOf("ratedV" to "6.0", "rpm" to "6000"))
            ),
            wires = listOf(
                LabWire("w1", pin("psu", "pos"), pin("rel", "coil1")),
                LabWire("w2", pin("rel", "coil2"), pin("psu", "neg")),
                LabWire("w3", pin("psu", "pos"), pin("rel", "com")),
                LabWire("w4", pin("rel", "no"), pin("mot", "t1")),
                LabWire("w5", pin("mot", "t2"), pin("psu", "neg"))
            )
        )
        val rmRes = CircuitMnaSolver.stepTransient(relayMotorSnap, CircuitTransientState(), 0.01)
        assertTrue(rmRes.componentReadings.getValue("rel").relayEnergized)
        assertTrue(rmRes.componentReadings.getValue("mot").motorRpm > 3000f)

        // Support matrix honesty check: IC/MCU parts must never claim FULLY_SIMULATED
        val supportById = NetlistExtractor.componentSupportCatalog.associateBy { it.typeId }
        for (unsupportedId in listOf("ic_555", "ic_lm358", "hcsr04", "arduino_uno", "esp32_devkit", "lcd_16x2")) {
            assertEquals(ComponentSupportLevel.NOT_SUPPORTED, supportById.getValue(unsupportedId).supportLevel)
        }
    }

    @Test
    fun endToEndPhase4VirtualLabSimulationInstrumentsAndReportCuj() {
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("nav_lab").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("nav_lab").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("sim_run_button").fetchSemanticsNodes().isNotEmpty()
        }

        // Run starter circuit simulation
        composeRule.onNodeWithTag("sim_run_button").performClick()
        composeRule.waitUntil(timeoutMillis = 3_000) {
            composeRule.onAllNodesWithText("Running", substring = true)
                .fetchSemanticsNodes().isNotEmpty()
        }

        // Cycle Speed & Time-Step controls
        composeRule.onNodeWithTag("sim_speed_button").performClick()
        composeRule.onNodeWithTag("sim_dt_button").performClick()

        // Open Instruments panel -> check real DMM & Oscilloscope canvas
        composeRule.onNodeWithTag("lab_meters_button").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 3_000) {
            composeRule.onAllNodesWithTag("lab_instruments_panel").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("oscilloscope_canvas").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("lab_meters_button").performScrollTo().performClick()

        // Open Simulation Report & Support Matrix dialog
        composeRule.onNodeWithTag("sim_report_button").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 3_000) {
            composeRule.onAllNodesWithTag("lab_report_dialog").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("lab_report_dialog").assertIsDisplayed()
        composeRule.onAllNodesWithText("Not Supported", substring = true).fetchSemanticsNodes().isNotEmpty().let {
            assertTrue("Expected honest Not Supported labels in support matrix", it)
        }
    }
}
