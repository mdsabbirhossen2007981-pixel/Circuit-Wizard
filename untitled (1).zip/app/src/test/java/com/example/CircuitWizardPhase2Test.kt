package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.CircuitDatabase
import com.example.data.local.seed.AcademyDatabaseSeeder
import com.example.data.local.seed.DatabaseSeeder
import com.example.data.repository.AcademyRepository
import com.example.data.repository.ComponentRepository
import com.example.data.repository.QuizRepository
import com.example.domain.calculator.EngineeringCalculators
import com.example.domain.model.AcademyCourse
import com.example.domain.model.ComponentSeedPayload
import com.example.domain.model.LessonSeedPayload
import com.example.domain.model.QuizQuestionPayload
import com.example.domain.model.QuizQuestionType
import com.example.ui.academy.LessonDetailViewModel
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CircuitWizardPhase2Test {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun engineeringCalculatorsComputeAccurateElectronicsValues() {
        // Ohm's Law: 12V across 400 Ohm -> 30 mA, 360 mW
        val ohm = EngineeringCalculators.solveOhmsLawFromVR(12.0, 400.0)
        assertEquals(30.0, ohm.currentMa, 0.05)
        assertEquals(360.0, ohm.powerMw, 0.5)

        // LED Series Resistor: 5V supply, 2V LED, 15mA -> 200 Ohm
        val led = EngineeringCalculators.solveLedSeriesResistor(5.0, 2.0, 15.0)
        assertEquals(200.0, led.resistanceOhm, 0.1)

        // Series / Parallel: 1k and 1k -> Series 2k, Parallel 500
        val (series, parallel) = EngineeringCalculators.solveSeriesParallel(1000.0, 1000.0)
        assertEquals(2000.0, series, 0.1)
        assertEquals(500.0, parallel, 0.1)

        // Voltage Divider: 5V, 1k top, 2k bottom -> 3.33V
        val div = EngineeringCalculators.solveVoltageDivider(5.0, 1000.0, 2000.0)
        assertEquals(3.33, div.vOut, 0.02)

        // RC Circuit: 10k Ohm + 1 uF -> 10 ms tau, ~15.92 Hz cutoff
        val rc = EngineeringCalculators.solveRcCircuit(10_000.0, 1.0)
        assertEquals(10.0, rc.tauMs, 0.05)
        assertEquals(15.92, rc.cutoffHz, 0.2)

        // Buck Converter: 24V @ 25% duty -> 6.0V
        val (vBuck, _, _) = EngineeringCalculators.solveBuckConverter(24.0, 25.0)
        assertEquals(6.0, vBuck, 0.05)

        // 4-band Resistor: Yellow (4) - Violet (7) - Red (x100) - Gold (5%) -> 4700 Ohm
        val yellow = EngineeringCalculators.resistorBands.first { it.key == "YELLOW" }
        val violet = EngineeringCalculators.resistorBands.first { it.key == "VIOLET" }
        val red = EngineeringCalculators.resistorBands.first { it.key == "RED" }
        val gold = EngineeringCalculators.resistorBands.first { it.key == "GOLD" }
        val (rVal, tol) = EngineeringCalculators.decodeFourBandResistor(yellow, violet, red, gold)
        assertEquals(4700.0, rVal, 0.1)
        assertEquals(5.0, tol, 0.01)
    }

    @Test
    fun all61AcademyLessonsAndQuizzesSeedCleanlyWithValidReferences() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

        // Load catalog IDs to validate resolved relatedComponentIds
        val compType = Types.newParameterizedType(List::class.java, ComponentSeedPayload::class.java)
        val compAdapter = moshi.adapter<List<ComponentSeedPayload>>(compType)
        val seedFiles = context.assets.list("seed")?.sorted().orEmpty()
        val catalogIds = seedFiles
            .filter { it.startsWith("catalog_") && it.endsWith(".json") }
            .flatMap { f ->
                val raw = context.assets.open("seed/$f").bufferedReader(Charsets.UTF_8).use { it.readText() }
                compAdapter.fromJson(raw).orEmpty()
            }
            .map { it.id }
            .toSet()

        // Parse all Academy lessons
        val lessonType = Types.newParameterizedType(List::class.java, LessonSeedPayload::class.java)
        val lessonAdapter = moshi.adapter<List<LessonSeedPayload>>(lessonType)
        val allLessons = seedFiles
            .filter { it.startsWith("academy_") && it.endsWith(".json") }
            .flatMap { f ->
                val raw = context.assets.open("seed/$f").bufferedReader(Charsets.UTF_8).use { it.readText() }
                lessonAdapter.fromJson(raw) ?: error("Failed parsing $f")
            }

        assertEquals("Expected exact 61 Academy lessons across Courses 1–7", 61, allLessons.size)
        assertEquals("Duplicate lesson IDs detected", 61, allLessons.map { it.id }.toSet().size)

        val expectedCourseCounts = mapOf(
            AcademyCourse.COURSE_1_BASIC.id to 12,
            AcademyCourse.COURSE_2_PASSIVE.id to 7,
            AcademyCourse.COURSE_3_SEMI.id to 10,
            AcademyCourse.COURSE_4_ANALOG.id to 7,
            AcademyCourse.COURSE_5_DIGITAL.id to 9,
            AcademyCourse.COURSE_6_POWER.id to 7,
            AcademyCourse.COURSE_7_MCU.id to 9
        )
        for ((cId, expectedCount) in expectedCourseCounts) {
            val count = allLessons.count { it.courseId == cId }
            assertEquals("Mismatch lesson count for course $cId", expectedCount, count)
        }

        for (l in allLessons) {
            assertTrue("${l.id} missing titleEn", l.titleEn.isNotBlank())
            assertTrue("${l.id} missing titleBn", l.titleBn.isNotBlank())
            assertTrue("${l.id} missing beginnerEn", l.beginnerEn.isNotBlank())
            assertTrue("${l.id} missing intermediateEn", l.intermediateEn.isNotBlank())
            assertTrue("${l.id} missing advancedEn", l.advancedEn.isNotBlank())
            assertTrue("${l.id} missing workingPrincipleBn", l.workingPrincipleBn.isNotBlank())
            assertTrue("${l.id} missing summaryBn", l.summaryBn.isNotBlank())
            assertTrue("${l.id} missing inlineChecks", l.inlineChecks.isNotEmpty())
            for (rawCompId in l.relatedComponentIds) {
                val resolved = LessonDetailViewModel.resolveComponentAlias(rawCompId)
                assertTrue("${l.id} relatedComponentId '$rawCompId' (resolved '$resolved') missing from catalog", resolved in catalogIds)
            }
        }

        // Parse all Quiz files
        val quizType = Types.newParameterizedType(List::class.java, QuizQuestionPayload::class.java)
        val quizAdapter = moshi.adapter<List<QuizQuestionPayload>>(quizType)
        val allQuizzes = seedFiles
            .filter { it.startsWith("quizzes_") && it.endsWith(".json") }
            .flatMap { f ->
                val raw = context.assets.open("seed/$f").bufferedReader(Charsets.UTF_8).use { it.readText() }
                quizAdapter.fromJson(raw) ?: error("Failed parsing $f")
            }

        assertTrue("Expected at least 40 standalone quiz questions", allQuizzes.size >= 40)
        assertEquals("Duplicate quiz question IDs", allQuizzes.size, allQuizzes.map { it.id }.toSet().size)

        val validTypes = QuizQuestionType.entries.map { it.name }.toSet()
        for (q in allQuizzes) {
            assertTrue("${q.id} invalid questionType ${q.questionType}", q.questionType in validTypes)
            assertTrue("${q.id} missing promptEn", q.promptEn.isNotBlank())
            assertTrue("${q.id} missing promptBn", q.promptBn.isNotBlank())
            assertTrue("${q.id} invalid correctIndex", q.correctIndex in q.optionsEn.indices)
            assertEquals("${q.id} EN/BN option count mismatch", q.optionsEn.size, q.optionsBn.size)
        }
    }

    @Test
    fun academyAndQuizRepositoriesPersistProgressNotesAndAchievements() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        val prefs = UserPrefsStore(context)
        val db = Room.inMemoryDatabaseBuilder(context, CircuitDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        try {
            val compSeeder = DatabaseSeeder(context, db.componentDao(), prefs, moshi)
            val compRepo = ComponentRepository(db.componentDao(), compSeeder, moshi)
            compRepo.initializeCatalog()

            val acadSeeder = AcademyDatabaseSeeder(context, db.lessonDao(), db.quizDao(), prefs, moshi)
            val academyRepo = AcademyRepository(db.lessonDao(), db.quizDao(), prefs, acadSeeder, moshi)
            val quizRepo = QuizRepository(db.quizDao(), prefs, acadSeeder, moshi)

            academyRepo.initializeAcademy()
            val all = academyRepo.observeAllLessons().first()
            assertEquals(61, all.size)

            // Mark lesson complete, bookmark, and save personal note
            academyRepo.recordLessonView("c1_ohms_law")
            academyRepo.toggleLessonBookmark("c1_ohms_law")
            academyRepo.toggleLessonCompleted("c1_ohms_law")
            academyRepo.saveLessonNote("c1_ohms_law", "V = I * R verified on 330 ohm resistor")

            val ohmLesson = academyRepo.observeLessonById("c1_ohms_law").first()
            assertNotNull(ohmLesson)
            assertTrue(ohmLesson!!.isBookmarked)
            assertTrue(ohmLesson.isCompleted)
            assertEquals("V = I * R verified on 330 ohm resistor", academyRepo.observeLessonNote("c1_ohms_law").first())

            // Quiz attempt & achievement unlock
            val c1Questions = quizRepo.getQuestionsForSession("c1_basic", timedExam = false)
            assertTrue(c1Questions.isNotEmpty())
            quizRepo.saveAttempt(
                courseId = "c1_basic",
                quizTitle = "Basic Electronics",
                isTimedExam = true,
                score = c1Questions.size,
                totalQuestions = c1Questions.size,
                durationSeconds = 42,
                wrongQuestionIds = emptyList()
            )
            val attempts = quizRepo.observeAttempts().first()
            assertTrue(attempts.isNotEmpty())
            assertEquals(100, attempts.first().percentage)

            val achievements = quizRepo.observeAchievements().first()
            assertTrue(achievements.first { it.id == "ach_first_lesson" }.isUnlocked)
            assertTrue(achievements.first { it.id == "ach_quiz_master" }.isUnlocked)
            assertTrue(achievements.first { it.id == "ach_timed_exam_pass" }.isUnlocked)
        } finally {
            db.close()
        }
    }

    @Test
    fun endToEndAcademyLessonVirtualLabNoteAndQuizCuj() {
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("nav_academy").fetchSemanticsNodes().isNotEmpty()
        }

        // Open Academy tab
        composeRule.onNodeWithTag("nav_academy").performClick()
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("academy_hero_card").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("academy_home_list")
            .performScrollToNode(hasTestTag("course_card_c1_basic"))
        composeRule.onNodeWithTag("course_card_c1_basic").performClick()

        // Inside Course 1 -> open Ohm's Law lesson
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("course_detail_list").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("course_detail_list")
            .performScrollToNode(hasTestTag("lesson_card_c1_ohms_law"))
        composeRule.onNodeWithTag("lesson_card_c1_ohms_law").performClick()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("lesson_detail_list").fetchSemanticsNodes().isNotEmpty()
        }

        // Switch Beginner -> Intermediate -> Advanced
        composeRule.onNodeWithTag("level_intermediate_button").performClick()
        composeRule.onNodeWithTag("level_advanced_button").performClick()

        // Visual tabs
        composeRule.onNodeWithTag("lesson_visual_tab_1").performClick()
        composeRule.onNodeWithTag("lesson_visual_tab_2").performClick()

        // Open interactive Virtual Lab preview bench & close cleanly
        composeRule.onNodeWithTag("lesson_detail_list")
            .performScrollToNode(hasTestTag("open_virtual_lab_button"))
        composeRule.onNodeWithTag("open_virtual_lab_button").performClick()
        composeRule.onNodeWithTag("virtual_lab_preview_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("close_virtual_lab_button").performClick()

        // Save personal study note & mark completed
        composeRule.onNodeWithTag("lesson_detail_list")
            .performScrollToNode(hasTestTag("lesson_note_input"))
        composeRule.onNodeWithTag("lesson_note_input").performTextInput("Check 330 ohm wattage")
        composeRule.onNodeWithTag("save_note_button").performClick()

        composeRule.onNodeWithTag("lesson_detail_list")
            .performScrollToNode(hasTestTag("lesson_complete_button"))
        composeRule.onNodeWithTag("lesson_complete_button").performClick()

        // Return to Quiz Center and run Course 1 Quiz
        composeRule.onNodeWithTag("lesson_back_button").performClick()
        composeRule.onNodeWithTag("course_back_button").performClick()
        composeRule.onNodeWithTag("nav_quiz").performClick()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("quiz_hub_list").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("quiz_hub_list")
            .performScrollToNode(hasTestTag("start_quiz_c1_basic"))
        composeRule.onNodeWithTag("start_quiz_c1_basic").performClick()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("quiz_option_0").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("quiz_option_0").performClick()
        composeRule.onNodeWithTag("quiz_submit_button").performClick()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithTag("quiz_score_card").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("quiz_score_card").assertIsDisplayed()
        composeRule.onNodeWithTag("quiz_done_button").performClick()
        composeRule.waitForIdle()
    }
}
