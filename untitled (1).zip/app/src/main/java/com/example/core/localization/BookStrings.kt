package com.example.core.localization

data class LocalizedText(
    val en: String,
    val bn: String
) {
    fun get(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> en
        AppLanguage.BANGLA -> bn
    }
}

object BookStrings {
    fun appTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Circuit Wizard"
        AppLanguage.BANGLA -> "সার্কিট উইজার্ড"
    }

    fun editionBadge(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "ELECTRONICS TEXTBOOK • EDITION I"
        AppLanguage.BANGLA -> "ইলেকট্রনিক্স পাঠ্যপুস্তক • প্রথম সংস্করণ"
    }

    fun welcomeHeadline(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Master Every Electronic Component"
        AppLanguage.BANGLA -> "প্রতিটি ইলেকট্রনিক কম্পোনেন্ট শিখুন"
    }

    fun welcomeSubtitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "From resistors and semiconductors to microcontrollers and power electronics — complete theory, schematic symbols, pinouts, and real-world circuits offline."
        AppLanguage.BANGLA -> "রেজিস্টর ও সেমিকন্ডাক্টর থেকে মাইক্রোকন্ট্রোলার ও পাওয়ার ইলেকট্রনিক্স — সম্পূর্ণ তত্ত্ব, সার্কিট সিম্বল, পিনআউট ও বাস্তব সার্কিট অফলাইনে।"
    }

    fun searchHint(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Search components in English or বাংলা..."
        AppLanguage.BANGLA -> "ইংরেজি বা বাংলায় কম্পোনেন্ট খুঁজুন..."
    }

    fun navBook(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Book"
        AppLanguage.BANGLA -> "বই"
    }

    fun navLibrary(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Library"
        AppLanguage.BANGLA -> "লাইব্রেরি"
    }

    fun navSaved(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Saved"
        AppLanguage.BANGLA -> "সংরক্ষিত"
    }

    fun navSettings(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Settings"
        AppLanguage.BANGLA -> "সেটিংস"
    }

    fun continueLearning(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Continue Learning"
        AppLanguage.BANGLA -> "শেখা চালিয়ে যান"
    }

    fun startReading(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Start Reading Chapter 1"
        AppLanguage.BANGLA -> "প্রথম অধ্যায় পড়া শুরু করুন"
    }

    fun learningProgress(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Encyclopedia Progress"
        AppLanguage.BANGLA -> "এনসাইক্লোপিডিয়া অগ্রগতি"
    }

    fun componentCategories(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Component Chapters (A–K)"
        AppLanguage.BANGLA -> "কম্পোনেন্ট অধ্যায়সমূহ (A–K)"
    }

    fun featuredComponents(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Featured Essentials"
        AppLanguage.BANGLA -> "গুরুত্বপূর্ণ কম্পোনেন্ট"
    }

    fun recentlyViewed(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Recently Viewed"
        AppLanguage.BANGLA -> "সম্প্রতি দেখা হয়েছে"
    }

    fun bookmarksTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Bookmarked Components"
        AppLanguage.BANGLA -> "বুকমার্ক করা কম্পোনেন্ট"
    }

    fun viewAll(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Browse All"
        AppLanguage.BANGLA -> "সব দেখুন"
    }

    fun allCategories(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "All Categories"
        AppLanguage.BANGLA -> "সব ক্যাটাগরি"
    }

    fun sortCurated(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Chapter"
        AppLanguage.BANGLA -> "অধ্যায়"
    }

    fun sortAZ(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "A–Z"
        AppLanguage.BANGLA -> "A–Z"
    }

    fun sortZA(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Z–A"
        AppLanguage.BANGLA -> "Z–A"
    }

    fun noSearchResults(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "No matching electronic components found."
        AppLanguage.BANGLA -> "কোনো মিল থাকা ইলেকট্রনিক কম্পোনেন্ট পাওয়া যায়নি।"
    }

    fun noBookmarksYet(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "No bookmarks yet. Tap the bookmark icon on any component page to save it for quick study."
        AppLanguage.BANGLA -> "এখনো কোনো বুকমার্ক নেই। দ্রুত পড়ার জন্য যেকোনো কম্পোনেন্ট পেজে বুকমার্ক আইকনে ট্যাপ করুন।"
    }

    fun noRecentYet(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Your recently studied components will appear here."
        AppLanguage.BANGLA -> "আপনার সম্প্রতি পড়া কম্পোনেন্টগুলো এখানে দেখা যাবে।"
    }

    fun markAsStudied(lang: AppLanguage, studied: Boolean) = when (lang) {
        AppLanguage.ENGLISH -> if (studied) "Studied" else "Mark as Studied"
        AppLanguage.BANGLA -> if (studied) "পড়া সম্পন্ন" else "পড়া সম্পন্ন হিসেবে চিহ্নিত করুন"
    }

    fun offlineReadyBadge(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "100% OFFLINE READY"
        AppLanguage.BANGLA -> "১০০% অফলাইন প্রস্তুত"
    }

    fun settingsTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Preferences & Progress"
        AppLanguage.BANGLA -> "সেটিংস ও অগ্রগতি"
    }

    fun themeSection(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Laboratory Appearance"
        AppLanguage.BANGLA -> "ল্যাবরেটরি থিম"
    }

    fun darkLabMode(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Dark Laboratory Theme"
        AppLanguage.BANGLA -> "ডার্ক ল্যাবরেটরি থিম"
    }

    fun lightPaperMode(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Light Engineering Paper"
        AppLanguage.BANGLA -> "লাইট ইঞ্জিনিয়ারিং থিম"
    }

    fun languageSection(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Interface & Textbook Language"
        AppLanguage.BANGLA -> "অ্যাপ ও পাঠ্যপুস্তকের ভাষা"
    }

    fun back(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Back"
        AppLanguage.BANGLA -> "ফিরুন"
    }
}
