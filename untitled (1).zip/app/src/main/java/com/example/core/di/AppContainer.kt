package com.example.core.di

import android.content.Context
import androidx.room.Room
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.CircuitDatabase
import com.example.data.local.seed.AcademyDatabaseSeeder
import com.example.data.local.seed.DatabaseSeeder
import com.example.data.repository.AcademyRepository
import com.example.data.repository.ComponentRepository
import com.example.data.repository.LabProjectRepository
import com.example.data.repository.QuizRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    val userPrefsStore: UserPrefsStore = UserPrefsStore(appContext)

    val database: CircuitDatabase = Room.databaseBuilder(
        appContext,
        CircuitDatabase::class.java,
        "circuit_wizard.db"
    )
        .addMigrations(CircuitDatabase.MIGRATION_1_2, CircuitDatabase.MIGRATION_2_3)
        .build()

    private val databaseSeeder: DatabaseSeeder = DatabaseSeeder(
        context = appContext,
        componentDao = database.componentDao(),
        userPrefsStore = userPrefsStore,
        moshi = moshi
    )

    private val academySeeder: AcademyDatabaseSeeder = AcademyDatabaseSeeder(
        context = appContext,
        lessonDao = database.lessonDao(),
        quizDao = database.quizDao(),
        userPrefsStore = userPrefsStore,
        moshi = moshi
    )

    val componentRepository: ComponentRepository = ComponentRepository(
        componentDao = database.componentDao(),
        seeder = databaseSeeder,
        moshi = moshi
    )

    val academyRepository: AcademyRepository = AcademyRepository(
        lessonDao = database.lessonDao(),
        quizDao = database.quizDao(),
        prefsStore = userPrefsStore,
        seeder = academySeeder,
        moshi = moshi
    )

    val quizRepository: QuizRepository = QuizRepository(
        quizDao = database.quizDao(),
        prefsStore = userPrefsStore,
        seeder = academySeeder,
        moshi = moshi
    )

    val labProjectRepository: LabProjectRepository = LabProjectRepository(
        labProjectDao = database.labProjectDao(),
        moshi = moshi
    )
}
