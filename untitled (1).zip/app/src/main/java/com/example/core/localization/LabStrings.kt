package com.example.core.localization

object LabStrings {
    fun navLab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Lab"
        AppLanguage.BANGLA -> "ল্যাব"
    }

    fun labTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "3D Virtual Lab"
        AppLanguage.BANGLA -> "৩ডি ভার্চুয়াল ল্যাব"
    }

    fun toolSelect(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "নির্বাচন" else "Select"
    fun toolMove(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "সরান" else "Move"
    fun toolWire(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "তার" else "Wire"
    fun toolDelete(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "মুছুন" else "Delete"
    fun rotate(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "ঘোরান" else "Rotate"
    fun duplicate(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "কপি" else "Duplicate"
    fun undo(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "পূর্বাবস্থা" else "Undo"
    fun redo(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "পুনরায়" else "Redo"
    fun zoomIn(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "বড়" else "Zoom+"
    fun zoomOut(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "ছোট" else "Zoom-"
    fun resetCamera(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "রিসেট" else "Reset Cam"
    fun library(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "কম্পোনেন্ট" else "Parts"
    fun properties(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "বৈশিষ্ট্য" else "Properties"
    fun instruments(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "যন্ত্র" else "Meters"
    fun saveProject(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "সংরক্ষণ" else "Save"
    fun loadProject(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "লোড" else "Load"
    fun multiSelect(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "একাধিক" else "Multi"

    fun simRun(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "চালান" else "Run"
    fun simPause(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "বিরতি" else "Pause"
    fun simResume(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "পুনরায়" else "Resume"
    fun simStop(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "থামান" else "Stop"
    fun simReset(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "রিসেট" else "Reset"
    fun simReport(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "রিপোর্ট" else "Report"

    fun simRunning(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "চলছে" else "Running"
    fun simPaused(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "বিরতি" else "Paused"
    fun simStopped(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) "থামানো" else "Stopped"

    fun phase4Pending(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Simulation Engine Ready"
        AppLanguage.BANGLA -> "সিমুলেশন ইঞ্জিন প্রস্তুত"
    }

    fun searchPartsHint(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Search resistors, LEDs, Arduino, 555..."
        AppLanguage.BANGLA -> "রেজিস্টর, এলইডি, আরডুইনো খুঁজুন..."
    }
}
