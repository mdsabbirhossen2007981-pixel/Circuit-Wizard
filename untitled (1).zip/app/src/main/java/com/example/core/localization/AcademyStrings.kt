package com.example.core.localization

object AcademyStrings {
    fun navAcademy(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Academy"
        AppLanguage.BANGLA -> "অ্যাকাডেমি"
    }

    fun navQuiz(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Quiz"
        AppLanguage.BANGLA -> "কুইজ"
    }

    fun academyTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Learning Academy"
        AppLanguage.BANGLA -> "লার্নিং অ্যাকাডেমি"
    }

    fun academySubtitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Structured 7-course curriculum from basic physics to microcontrollers — 100% offline."
        AppLanguage.BANGLA -> "বেসিক ইলেকট্রনিক্স থেকে মাইক্রোকন্ট্রোলার পর্যন্ত ৭টি সম্পূর্ণ কোর্স — ১০০% অফলাইন।"
    }

    fun coursesHeader(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Engineering Courses (1–7)"
        AppLanguage.BANGLA -> "ইঞ্জিনিয়ারিং কোর্সসমূহ (১–৭)"
    }

    fun lessonsCount(lang: AppLanguage, done: Int, total: Int) = when (lang) {
        AppLanguage.ENGLISH -> "$done / $total lessons"
        AppLanguage.BANGLA -> "$done / $total পাঠ"
    }

    fun dailyStreak(lang: AppLanguage, days: Int) = when (lang) {
        AppLanguage.ENGLISH -> if (days == 1) "1 Day Streak" else "$days Days Streak"
        AppLanguage.BANGLA -> "$days দিনের ধারাবাহিকতা"
    }

    fun achievementsTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Earned Achievements"
        AppLanguage.BANGLA -> "অর্জিত অ্যাচিভমেন্ট"
    }

    fun openVirtualLab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Open in Virtual Lab"
        AppLanguage.BANGLA -> "ভার্চুয়াল ল্যাবে খুলুন"
    }

    fun virtualLabPreviewBadge(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "VIRTUAL LAB • INTERACTIVE CIRCUIT BENCH"
        AppLanguage.BANGLA -> "ভার্চুয়াল ল্যাব • ইন্টারঅ্যাক্টিভ সার্কিট বেঞ্চ"
    }

    fun interactiveCalcTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Interactive Lab Calculator"
        AppLanguage.BANGLA -> "ইন্টারঅ্যাক্টিভ ল্যাব ক্যালকুলেটর"
    }

    fun markLessonComplete(lang: AppLanguage, done: Boolean) = when (lang) {
        AppLanguage.ENGLISH -> if (done) "Lesson Completed" else "Complete Lesson"
        AppLanguage.BANGLA -> if (done) "পাঠ সম্পন্ন হয়েছে" else "পাঠ সম্পন্ন চিহ্নিত করুন"
    }

    fun personalNotesTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Personal Study Notes"
        AppLanguage.BANGLA -> "ব্যক্তিগত নোটস"
    }

    fun saveNote(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Save Note"
        AppLanguage.BANGLA -> "নোট সংরক্ষণ করুন"
    }

    fun nextLesson(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Next Lesson"
        AppLanguage.BANGLA -> "পরবর্তী পাঠ"
    }

    fun levelBeginner(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Beginner"
        AppLanguage.BANGLA -> "সহজ"
    }

    fun levelIntermediate(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Intermediate"
        AppLanguage.BANGLA -> "মধ্যম"
    }

    fun levelAdvanced(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Advanced"
        AppLanguage.BANGLA -> "উন্নত"
    }

    fun startChapterQuiz(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Chapter Quiz"
        AppLanguage.BANGLA -> "অধ্যায় কুইজ"
    }

    fun startTimedExam(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Timed Exam"
        AppLanguage.BANGLA -> "সময়সীমাবদ্ধ পরীক্ষা"
    }

    fun quizCenterTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Quiz & Examination"
        AppLanguage.BANGLA -> "কুইজ ও পরীক্ষা কেন্দ্র"
    }

    fun quizCenterSubtitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Test mastery across MCQs, True/False, component symbol ID & circuit analysis."
        AppLanguage.BANGLA -> "MCQ, সত্য/মিথ্যা, কম্পোনেন্ট শনাক্তকরণ ও সার্কিট বিশ্লেষণে নিজের দক্ষতা যাচাই করুন।"
    }

    fun reviewWrongAnswers(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Review Incorrect Answers"
        AppLanguage.BANGLA -> "ভুল উত্তর পর্যালোচনা"
    }

    fun submitQuiz(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Finish & Grade"
        AppLanguage.BANGLA -> "পরীক্ষা জমা দিন"
    }
}
