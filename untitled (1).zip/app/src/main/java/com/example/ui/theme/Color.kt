package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Laboratory Workbench Palette (Default)
val LabBgDark = Color(0xFF0B1016)
val LabSurfaceDark = Color(0xFF121A24)
val LabSurfaceVariantDark = Color(0xFF192432)
val LabSurfaceElevatedDark = Color(0xFF1F2C3D)
val LabOutlineDark = Color(0xFF2D3E52)

val OscilloscopeCyan = Color(0xFF22D3EE)
val OscilloscopeCyanDim = Color(0xFF0E7490)
val OscilloscopeCyanContainer = Color(0xFF083344)

val CopperAmber = Color(0xFFF59E0B)
val CopperAmberContainer = Color(0xFF451A03)

val LogicEmerald = Color(0xFF10B981)
val LogicEmeraldContainer = Color(0xFF064E3B)

val FaultCrimson = Color(0xFFEF4444)
val FaultCrimsonContainer = Color(0xFF450A0A)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)

// Daylight Engineering Paper Palette (Optional Light Theme)
val LabBgLight = Color(0xFFF3F6FA)
val LabSurfaceLight = Color(0xFFFFFFFF)
val LabSurfaceVariantLight = Color(0xFFE6EDF5)
val LabSurfaceElevatedLight = Color(0xFFDCE6F2)
val LabOutlineLight = Color(0xFFCBD5E1)

val OscilloscopeTealLight = Color(0xFF0284C7)
val OscilloscopeTealContainerLight = Color(0xFFE0F2FE)

val CopperAmberLight = Color(0xFFD97706)
val CopperAmberContainerLight = Color(0xFFFEF3C7)

val LogicEmeraldLight = Color(0xFF059669)
val LogicEmeraldContainerLight = Color(0xFFD1FAE5)

val FaultCrimsonLight = Color(0xFFDC2626)
val FaultCrimsonContainerLight = Color(0xFFFEE2E2)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
