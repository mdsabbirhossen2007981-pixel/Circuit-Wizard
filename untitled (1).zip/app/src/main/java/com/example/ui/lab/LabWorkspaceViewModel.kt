package com.example.ui.lab

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.repository.LabProjectRepository
import com.example.data.repository.SavedLabProjectSummary
import com.example.domain.lab.LabComponentCatalog
import com.example.domain.model.LabCategory
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabInstrumentState
import com.example.domain.model.LabInstrumentType
import com.example.domain.model.LabTool
import com.example.domain.model.LabWire
import com.example.domain.model.LabWireColor
import com.example.domain.model.PinEndpoint
import com.example.domain.model.PlacedComponent
import com.example.domain.model.WireRouteStyle
import com.example.simulation.CircuitMnaSolver
import com.example.simulation.CircuitTransientState
import com.example.simulation.NetlistExtractor
import com.example.simulation.NetlistSummary
import com.example.simulation.OscilloscopeSample
import com.example.simulation.SafetySeverity
import com.example.simulation.SimulationResult
import com.example.simulation.SimulationStatus
import com.example.simulation.SimulationWarning
import com.example.simulation.WarningCategory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

enum class LabDrawerPanel {
    NONE,
    LIBRARY,
    PROPERTIES,
    INSTRUMENTS
}

data class LabUiState(
    val snapshot: LabCircuitSnapshot = LabComponentCatalog.defaultLedCircuitStarter(),
    val language: AppLanguage = AppLanguage.ENGLISH,
    val activeTool: LabTool = LabTool.SELECT,
    val multiSelectEnabled: Boolean = false,
    val selectedComponentIds: Set<String> = emptySet(),
    val selectedWireId: String? = null,
    val wiringStart: PinEndpoint? = null,
    val activeWireColor: LabWireColor = LabWireColor.GREEN,
    val activeWireStyle: WireRouteStyle = WireRouteStyle.CURVED,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val camera: LabCamera3D = LabCamera3D(),
    val simulationStatus: SimulationStatus = SimulationStatus.STOPPED,
    val simulationResult: SimulationResult = SimulationResult(),
    val oscilloscopeSamples: List<OscilloscopeSample> = emptyList(),
    val simSpeedMultiplier: Float = 1.0f,
    val simTimeStepMs: Int = 10,
    val flowAnimPhase: Float = 0f,
    val showReportDialog: Boolean = false,
    val netlistSummary: NetlistSummary = NetlistExtractor.stageNetlist(LabComponentCatalog.defaultLedCircuitStarter()),
    val activeDrawer: LabDrawerPanel = LabDrawerPanel.NONE,
    val showSaveDialog: Boolean = false,
    val showLoadDialog: Boolean = false,
    val isFullScreen: Boolean = false,
    val isLandscapeLocked: Boolean = false,
    val searchQuery: String = "",
    val selectedCategory: LabCategory? = null,
    val savedProjects: List<SavedLabProjectSummary> = emptyList(),
    val feedbackBanner: String? = null
)

class LabWorkspaceViewModel(
    private val projectRepository: LabProjectRepository,
    prefsStore: UserPrefsStore
) : ViewModel() {

    private val starter = LabComponentCatalog.defaultLedCircuitStarter()
    private val internalState = MutableStateFlow(LabUiState(snapshot = starter, netlistSummary = NetlistExtractor.stageNetlist(starter)))
    private val undoStack = ArrayDeque<LabCircuitSnapshot>()
    private val redoStack = ArrayDeque<LabCircuitSnapshot>()
    private var pendingMoveUndoCaptured = false
    private val transientState = CircuitTransientState()
    private var simJob: Job? = null

    val uiState: StateFlow<LabUiState> = internalState.asStateFlow()

    init {
        viewModelScope.launch {
            prefsStore.language.collect { lang ->
                internalState.update { it.copy(language = lang) }
            }
        }
        viewModelScope.launch {
            projectRepository.observeSavedProjects().collect { saved ->
                internalState.update { it.copy(savedProjects = saved) }
            }
        }
    }

    private fun commitSnapshot(
        newSnapshot: LabCircuitSnapshot,
        recordUndo: Boolean = true,
        feedback: String? = null
    ) {
        val current = internalState.value
        if (recordUndo) {
            undoStack.addLast(current.snapshot)
            if (undoStack.size > 40) undoStack.removeFirst()
            redoStack.clear()
        }
        val summary = NetlistExtractor.stageNetlist(newSnapshot)
        internalState.value = current.copy(
            snapshot = newSnapshot,
            netlistSummary = summary,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty(),
            feedbackBanner = feedback
        )
    }

    fun selectTool(tool: LabTool) {
        internalState.value = internalState.value.copy(
            activeTool = tool,
            wiringStart = if (tool == LabTool.WIRE) internalState.value.wiringStart else null
        )
    }

    fun toggleMultiSelect() {
        val cur = internalState.value
        internalState.value = cur.copy(
            multiSelectEnabled = !cur.multiSelectEnabled,
            selectedComponentIds = if (!cur.multiSelectEnabled) cur.selectedComponentIds else cur.selectedComponentIds.take(1).toSet()
        )
    }

    fun openDrawer(panel: LabDrawerPanel) {
        val cur = internalState.value
        val next = if (cur.activeDrawer == panel) LabDrawerPanel.NONE else panel
        internalState.value = cur.copy(activeDrawer = next)
    }

    fun closeDrawer() {
        internalState.value = internalState.value.copy(activeDrawer = LabDrawerPanel.NONE)
    }

    fun setShowSaveDialog(show: Boolean) {
        internalState.value = internalState.value.copy(showSaveDialog = show)
    }

    fun setShowLoadDialog(show: Boolean) {
        internalState.value = internalState.value.copy(showLoadDialog = show)
    }

    fun toggleFullScreen() {
        val cur = internalState.value
        internalState.value = cur.copy(isFullScreen = !cur.isFullScreen)
    }

    fun toggleLandscapeLock() {
        val cur = internalState.value
        internalState.value = cur.copy(isLandscapeLocked = !cur.isLandscapeLocked)
    }

    fun updateSearchQuery(query: String) {
        internalState.value = internalState.value.copy(searchQuery = query)
    }

    fun selectCategory(category: LabCategory?) {
        internalState.value = internalState.value.copy(selectedCategory = category)
    }

    fun clearFeedback() {
        internalState.value = internalState.value.copy(feedbackBanner = null)
    }

    fun selectComponent(instanceId: String?) {
        val cur = internalState.value
        if (instanceId == null) {
            internalState.value = cur.copy(selectedComponentIds = emptySet(), selectedWireId = null)
            return
        }
        val nextSet = if (cur.multiSelectEnabled) {
            if (instanceId in cur.selectedComponentIds) cur.selectedComponentIds - instanceId
            else cur.selectedComponentIds + instanceId
        } else {
            setOf(instanceId)
        }
        internalState.value = cur.copy(
            selectedComponentIds = nextSet,
            selectedWireId = null
        )
    }

    fun selectWire(wireId: String?) {
        val cur = internalState.value
        internalState.value = cur.copy(
            selectedWireId = wireId,
            selectedComponentIds = emptySet()
        )
    }

    fun placeComponentFromLibrary(typeId: String, targetCol: Float? = null, targetRow: Float? = null) {
        if (typeId == "jumper_bridge") {
            // Also make sure Wire tool can be triggered easily, or place bridge cleanly
        }
        val def = LabComponentCatalog.find(typeId) ?: return
        val cur = internalState.value
        val existingCols = cur.snapshot.components.map { it.gridCol.roundToInt() }.toSet()

        val rawCol = targetCol ?: run {
            var candidate = 4
            while (candidate in existingCols && candidate < 26) candidate += 3
            candidate.toFloat()
        }
        val rawRow = targetRow ?: when {
            !def.snapToBreadboard -> 16.5f
            typeId == "ic_555" || typeId == "ic_lm358" || typeId == "pushbutton" -> 4f
            else -> 2f
        }
        val (snappedCol, snappedRow) = LabGeometryHelper.snapPlacementGrid(rawCol, rawRow, def)

        val newId = "cmp_${typeId}_${UUID.randomUUID().toString().take(6)}"
        val placed = PlacedComponent(
            instanceId = newId,
            typeId = typeId,
            gridCol = snappedCol,
            gridRow = snappedRow,
            rotationDeg = 0,
            properties = def.defaultProperties
        )
        val updated = cur.snapshot.copy(components = cur.snapshot.components + placed)
        commitSnapshot(updated, recordUndo = true, feedback = "Placed ${def.name(cur.language)}")
        internalState.value = internalState.value.copy(
            selectedComponentIds = setOf(newId),
            selectedWireId = null,
            activeDrawer = LabDrawerPanel.NONE
        )
    }

    fun beginComponentMove() {
        if (!pendingMoveUndoCaptured) {
            undoStack.addLast(internalState.value.snapshot)
            if (undoStack.size > 40) undoStack.removeFirst()
            redoStack.clear()
            pendingMoveUndoCaptured = true
        }
    }

    fun moveSelectedComponentsDelta(deltaCol: Float, deltaRow: Float) {
        val cur = internalState.value
        if (cur.selectedComponentIds.isEmpty()) return
        val updatedComps = cur.snapshot.components.map { comp ->
            if (comp.instanceId in cur.selectedComponentIds) {
                comp.copy(
                    gridCol = (comp.gridCol + deltaCol).coerceIn(-6f, 34f),
                    gridRow = (comp.gridRow + deltaRow).coerceIn(-10f, 22f)
                )
            } else {
                comp
            }
        }
        val updatedSnap = cur.snapshot.copy(components = updatedComps)
        internalState.value = cur.copy(
            snapshot = updatedSnap,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }

    fun finishComponentMove() {
        val cur = internalState.value
        val snappedComps = cur.snapshot.components.map { comp ->
            if (comp.instanceId in cur.selectedComponentIds) {
                val def = LabComponentCatalog.find(comp.typeId)
                if (def != null) {
                    val (sc, sr) = LabGeometryHelper.snapPlacementGrid(comp.gridCol, comp.gridRow, def)
                    comp.copy(gridCol = sc, gridRow = sr)
                } else {
                    comp
                }
            } else {
                comp
            }
        }
        val snappedSnapshot = cur.snapshot.copy(components = snappedComps)
        pendingMoveUndoCaptured = false
        internalState.value = cur.copy(
            snapshot = snappedSnapshot,
            netlistSummary = NetlistExtractor.stageNetlist(snappedSnapshot),
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }

    fun rotateSelected() {
        val cur = internalState.value
        if (cur.selectedComponentIds.isEmpty()) return
        val updated = cur.snapshot.copy(
            components = cur.snapshot.components.map { comp ->
                if (comp.instanceId in cur.selectedComponentIds) {
                    comp.copy(rotationDeg = (comp.rotationDeg + 90) % 360)
                } else comp
            }
        )
        commitSnapshot(updated, recordUndo = true)
    }

    fun duplicateSelected() {
        val cur = internalState.value
        val selected = cur.snapshot.components.filter { it.instanceId in cur.selectedComponentIds }
        if (selected.isEmpty()) return
        val copies = selected.map { comp ->
            val def = LabComponentCatalog.find(comp.typeId)
            val rawCol = (comp.gridCol + 2f).coerceIn(0f, 28f)
            val rawRow = comp.gridRow + if (def?.snapToBreadboard == false) 1.5f else 0f
            val (sc, sr) = if (def != null) LabGeometryHelper.snapPlacementGrid(rawCol, rawRow, def) else rawCol to rawRow
            comp.copy(
                instanceId = "cmp_copy_${UUID.randomUUID().toString().take(6)}",
                gridCol = sc,
                gridRow = sr
            )
        }
        val updated = cur.snapshot.copy(components = cur.snapshot.components + copies)
        commitSnapshot(updated, recordUndo = true, feedback = "Duplicated ${copies.size} part(s)")
        internalState.value = internalState.value.copy(
            selectedComponentIds = copies.map { it.instanceId }.toSet()
        )
    }

    fun deleteSelectedOrTarget(targetCompId: String? = null, targetWireId: String? = null) {
        val cur = internalState.value
        val compIdsToDelete = when {
            targetCompId != null -> setOf(targetCompId)
            else -> cur.selectedComponentIds
        }
        val wireIdToDelete = targetWireId ?: cur.selectedWireId

        if (compIdsToDelete.isEmpty() && wireIdToDelete == null) return

        val remainingComps = cur.snapshot.components.filterNot { it.instanceId in compIdsToDelete }
        val remainingWires = cur.snapshot.wires.filterNot { wire ->
            wire.id == wireIdToDelete ||
                wire.start.componentId in compIdsToDelete ||
                wire.end.componentId in compIdsToDelete
        }
        val updated = cur.snapshot.copy(components = remainingComps, wires = remainingWires)
        commitSnapshot(updated, recordUndo = true)
        internalState.value = internalState.value.copy(
            selectedComponentIds = emptySet(),
            selectedWireId = null
        )
    }

    fun updateComponentProperties(instanceId: String, updatedProperties: Map<String, String>) {
        val cur = internalState.value
        val updated = cur.snapshot.copy(
            components = cur.snapshot.components.map { comp ->
                if (comp.instanceId == instanceId) comp.copy(properties = updatedProperties) else comp
            }
        )
        commitSnapshot(updated, recordUndo = true)
    }

    fun beginOrCompleteWire(endpoint: PinEndpoint) {
        val cur = internalState.value
        val start = cur.wiringStart
        if (start == null) {
            internalState.value = cur.copy(wiringStart = endpoint)
            return
        }
        val startKey = start.canonicalKey()
        val endKey = endpoint.canonicalKey()
        if (startKey == endKey) {
            // Prevent self-loop wire and clear start pin
            internalState.value = cur.copy(
                wiringStart = null,
                feedbackBanner = "Cancelled self-loop wire"
            )
            return
        }
        val duplicate = cur.snapshot.wires.any { w ->
            val ws = w.start.canonicalKey()
            val we = w.end.canonicalKey()
            (ws == startKey && we == endKey) || (ws == endKey && we == startKey)
        }
        if (duplicate) {
            internalState.value = cur.copy(
                wiringStart = null,
                feedbackBanner = "Connection already exists"
            )
            return
        }

        val newWire = LabWire(
            id = "wire_${UUID.randomUUID().toString().take(6)}",
            start = start,
            end = endpoint,
            colorKey = cur.activeWireColor.key,
            routeStyle = cur.activeWireStyle.name,
            bendOffset = 0.85f
        )
        val updated = cur.snapshot.copy(wires = cur.snapshot.wires + newWire)
        commitSnapshot(updated, recordUndo = true)
        internalState.value = internalState.value.copy(
            wiringStart = null,
            selectedWireId = newWire.id,
            selectedComponentIds = emptySet()
        )
    }

    fun cancelActiveWire() {
        internalState.value = internalState.value.copy(wiringStart = null)
    }

    fun setActiveWireColor(color: LabWireColor) {
        val cur = internalState.value
        internalState.value = cur.copy(activeWireColor = color)
        cur.selectedWireId?.let { wireId -> updateWireColor(wireId, color) }
    }

    fun setActiveWireStyle(style: WireRouteStyle) {
        val cur = internalState.value
        internalState.value = cur.copy(activeWireStyle = style)
        cur.selectedWireId?.let { wireId -> updateWireStyle(wireId, style) }
    }

    fun updateWireColor(wireId: String, color: LabWireColor) {
        val cur = internalState.value
        val updated = cur.snapshot.copy(
            wires = cur.snapshot.wires.map { w -> if (w.id == wireId) w.copy(colorKey = color.key) else w }
        )
        commitSnapshot(updated, recordUndo = true)
    }

    fun updateWireStyle(wireId: String, style: WireRouteStyle) {
        val cur = internalState.value
        val updated = cur.snapshot.copy(
            wires = cur.snapshot.wires.map { w -> if (w.id == wireId) w.copy(routeStyle = style.name) else w }
        )
        commitSnapshot(updated, recordUndo = true)
    }

    fun updateWireBend(wireId: String, bendOffset: Float) {
        val cur = internalState.value
        val updated = cur.snapshot.copy(
            wires = cur.snapshot.wires.map { w ->
                if (w.id == wireId) w.copy(bendOffset = bendOffset.coerceIn(0.2f, 2.2f)) else w
            }
        )
        commitSnapshot(updated, recordUndo = false)
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val cur = internalState.value
        redoStack.addLast(cur.snapshot)
        val prev = undoStack.removeLast()
        internalState.value = cur.copy(
            snapshot = prev,
            netlistSummary = NetlistExtractor.stageNetlist(prev),
            selectedComponentIds = emptySet(),
            selectedWireId = null,
            wiringStart = null,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val cur = internalState.value
        undoStack.addLast(cur.snapshot)
        val next = redoStack.removeLast()
        internalState.value = cur.copy(
            snapshot = next,
            netlistSummary = NetlistExtractor.stageNetlist(next),
            selectedComponentIds = emptySet(),
            selectedWireId = null,
            wiringStart = null,
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }

    // Camera Controls
    fun zoomIn() {
        val cam = internalState.value.camera
        internalState.value = internalState.value.copy(
            camera = cam.copy(zoom = (cam.zoom * 1.2f).coerceIn(LabCamera3D.MIN_ZOOM, LabCamera3D.MAX_ZOOM))
        )
    }

    fun zoomOut() {
        val cam = internalState.value.camera
        internalState.value = internalState.value.copy(
            camera = cam.copy(zoom = (cam.zoom / 1.2f).coerceIn(LabCamera3D.MIN_ZOOM, LabCamera3D.MAX_ZOOM))
        )
    }

    fun resetCamera() {
        val cam = internalState.value.camera
        internalState.value = internalState.value.copy(camera = cam.reset())
    }

    fun toggle3D2DMode() {
        val cam = internalState.value.camera
        internalState.value = internalState.value.copy(camera = cam.toggleMode())
    }

    fun orbitCamera(deltaYaw: Float, deltaPitch: Float) {
        val cam = internalState.value.camera
        if (cam.renderMode != com.example.domain.model.LabRenderMode.PERSPECTIVE_3D) return
        internalState.value = internalState.value.copy(
            camera = cam.copy(
                yawDeg = (cam.yawDeg + deltaYaw).coerceIn(-65f, 65f),
                pitchDeg = (cam.pitchDeg + deltaPitch).coerceIn(22f, 82f)
            )
        )
    }

    fun panAndZoomCamera(panDeltaX: Float, panDeltaY: Float, zoomFactor: Float) {
        val cam = internalState.value.camera
        internalState.value = internalState.value.copy(
            camera = cam.copy(
                zoom = (cam.zoom * zoomFactor).coerceIn(LabCamera3D.MIN_ZOOM, LabCamera3D.MAX_ZOOM),
                panX = (cam.panX + panDeltaX).coerceIn(-900f, 900f),
                panY = (cam.panY + panDeltaY).coerceIn(-700f, 700f)
            )
        )
    }

    // Simulation Transport & Background Solver Loop (Phase 4)
    private fun executeSingleStepAndSample(snap: LabCircuitSnapshot): Pair<SimulationResult, List<OscilloscopeSample>> {
        val cur = internalState.value
        val dtSec = ((cur.simTimeStepMs / 1000.0) * cur.simSpeedMultiplier).coerceIn(1e-4, 0.25)
        val res = try {
            CircuitMnaSolver.stepTransient(snap, transientState, dtSec)
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            SimulationResult(
                simTimeSec = transientState.simTimeSec,
                converged = false,
                warnings = listOf(
                    SimulationWarning(
                        category = WarningCategory.SOLVER_ERROR,
                        severity = SafetySeverity.CRITICAL,
                        componentId = null,
                        messageEn = "Solver error: ${t.message ?: t.javaClass.simpleName}"
                    )
                ),
                solverErrorMessage = t.message ?: "Unexpected solver error"
            )
        }

        val scopeInst = snap.instruments.firstOrNull { it.type == LabInstrumentType.OSCILLOSCOPE.name }
        val updatedSamples = if (scopeInst?.positiveProbeKey != null) {
            val vPos = res.nodeVoltagesV[scopeInst.positiveProbeKey]
            val vNeg = scopeInst.negativeProbeKey?.let { res.nodeVoltagesV[it] } ?: 0.0
            if (vPos != null) {
                val sample = OscilloscopeSample(res.simTimeSec, vPos - vNeg)
                (cur.oscilloscopeSamples + sample).takeLast(120)
            } else cur.oscilloscopeSamples
        } else {
            cur.oscilloscopeSamples
        }
        return res to updatedSamples
    }

    fun runOrResumeSimulation() {
        simJob?.cancel()
        val cur = internalState.value
        val staged = NetlistExtractor.stageNetlist(cur.snapshot)
        val (firstResult, firstSamples) = executeSingleStepAndSample(cur.snapshot)
        val anyFlow = firstResult.wireReadings.values.any { abs(it.currentMa) > 0.05 }

        internalState.update {
            it.copy(
                simulationStatus = SimulationStatus.RUNNING,
                netlistSummary = staged,
                simulationResult = firstResult,
                oscilloscopeSamples = firstSamples,
                flowAnimPhase = if (anyFlow) (it.flowAnimPhase + 0.08f) % 1f else 0f
            )
        }

        simJob = viewModelScope.launch(Dispatchers.Default) {
            while (isActive && internalState.value.simulationStatus == SimulationStatus.RUNNING) {
                delay(45L)
                if (!isActive || internalState.value.simulationStatus != SimulationStatus.RUNNING) break
                val latest = internalState.value
                val (stepResult, nextSamples) = executeSingleStepAndSample(latest.snapshot)
                val flowing = stepResult.wireReadings.values.any { abs(it.currentMa) > 0.05 }
                internalState.update { state ->
                    if (state.simulationStatus != SimulationStatus.RUNNING) state
                    else state.copy(
                        simulationResult = stepResult,
                        oscilloscopeSamples = nextSamples,
                        flowAnimPhase = if (flowing) (state.flowAnimPhase + 0.08f * state.simSpeedMultiplier) % 1f else 0f
                    )
                }
            }
        }
    }

    fun pauseSimulation() {
        simJob?.cancel()
        simJob = null
        val cur = internalState.value
        if (cur.simulationStatus == SimulationStatus.RUNNING) {
            internalState.value = cur.copy(simulationStatus = SimulationStatus.PAUSED)
        }
    }

    fun stopSimulation() {
        simJob?.cancel()
        simJob = null
        transientState.reset()
        internalState.update {
            it.copy(
                simulationStatus = SimulationStatus.STOPPED,
                simulationResult = SimulationResult(),
                flowAnimPhase = 0f
            )
        }
    }

    fun resetSimulation() {
        simJob?.cancel()
        simJob = null
        transientState.reset()
        val cur = internalState.value
        val staged = NetlistExtractor.stageNetlist(cur.snapshot)
        internalState.value = cur.copy(
            simulationStatus = SimulationStatus.STOPPED,
            simulationResult = SimulationResult(),
            oscilloscopeSamples = emptyList(),
            flowAnimPhase = 0f,
            netlistSummary = staged
        )
    }

    fun cycleSimSpeed() {
        val speeds = listOf(0.25f, 0.5f, 1.0f, 2.0f)
        val cur = internalState.value.simSpeedMultiplier
        val idx = speeds.indexOfFirst { abs(it - cur) < 0.01f }
        val next = speeds[(idx + 1) % speeds.size]
        internalState.update { it.copy(simSpeedMultiplier = next) }
    }

    fun cycleSimTimeStep() {
        val steps = listOf(5, 10, 25, 50)
        val cur = internalState.value.simTimeStepMs
        val idx = steps.indexOf(cur)
        val next = steps[(idx + 1) % steps.size]
        internalState.update { it.copy(simTimeStepMs = next) }
    }

    fun setShowReportDialog(show: Boolean) {
        internalState.update { it.copy(showReportDialog = show) }
    }

    // Instruments State
    fun updateInstrument(updated: LabInstrumentState) {
        val cur = internalState.value
        val exists = cur.snapshot.instruments.any { it.type == updated.type }
        val nextList = if (exists) {
            cur.snapshot.instruments.map { if (it.type == updated.type) updated else it }
        } else {
            cur.snapshot.instruments + updated
        }
        commitSnapshot(cur.snapshot.copy(instruments = nextList), recordUndo = false)
    }

    fun clearAllAndCreateBlank() {
        stopSimulation()
        val blank = LabCircuitSnapshot(
            projectName = "Blank Breadboard",
            components = emptyList(),
            wires = emptyList(),
            instruments = LabInstrumentType.entries.map {
                LabInstrumentState(type = it.name, mode = if (it == LabInstrumentType.DIGITAL_MULTIMETER) "VDC" else it.name)
            }
        )
        commitSnapshot(blank, recordUndo = true, feedback = "Cleared workspace")
        internalState.value = internalState.value.copy(
            selectedComponentIds = emptySet(),
            selectedWireId = null,
            wiringStart = null,
            oscilloscopeSamples = emptyList()
        )
    }

    fun loadStarterTemplate() {
        stopSimulation()
        val starterCircuit = LabComponentCatalog.defaultLedCircuitStarter()
        commitSnapshot(starterCircuit, recordUndo = true, feedback = "Starter bench loaded")
        internalState.value = internalState.value.copy(
            selectedComponentIds = emptySet(),
            selectedWireId = null,
            wiringStart = null,
            oscilloscopeSamples = emptyList()
        )
    }

    // Room Persistence
    fun saveCurrentProject(projectName: String) {
        viewModelScope.launch {
            val cur = internalState.value
            val savedId = projectRepository.saveProject(cur.snapshot, projectName)
            val updatedSnap = cur.snapshot.copy(
                projectId = savedId,
                projectName = projectName.trim().ifEmpty { cur.snapshot.projectName }
            )
            internalState.value = internalState.value.copy(
                snapshot = updatedSnap,
                showSaveDialog = false,
                feedbackBanner = "Saved '${updatedSnap.projectName}'"
            )
        }
    }

    fun loadSavedProject(id: Long) {
        viewModelScope.launch {
            val loaded = projectRepository.loadProject(id) ?: return@launch
            stopSimulation()
            commitSnapshot(loaded, recordUndo = true, feedback = "Loaded '${loaded.projectName}'")
            internalState.value = internalState.value.copy(
                showLoadDialog = false,
                selectedComponentIds = emptySet(),
                selectedWireId = null,
                wiringStart = null,
                oscilloscopeSamples = emptyList()
            )
        }
    }

    fun deleteSavedProject(id: Long) {
        viewModelScope.launch {
            projectRepository.deleteProject(id)
        }
    }

    override fun onCleared() {
        simJob?.cancel()
        super.onCleared()
    }

    class Factory(
        private val projectRepository: LabProjectRepository,
        private val prefsStore: UserPrefsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LabWorkspaceViewModel(projectRepository, prefsStore) as T
        }
    }
}
