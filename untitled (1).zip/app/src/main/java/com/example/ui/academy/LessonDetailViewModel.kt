package com.example.ui.academy

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.repository.AcademyRepository
import com.example.data.repository.ComponentRepository
import com.example.domain.model.ElectronicComponent
import com.example.domain.model.ExplanationLevel
import com.example.domain.model.Lesson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LessonDetailUiState(
    val isLoading: Boolean = true,
    val lesson: Lesson? = null,
    val nextLesson: Lesson? = null,
    val relatedComponents: List<ElectronicComponent> = emptyList(),
    val noteText: String = "",
    val language: AppLanguage = AppLanguage.ENGLISH,
    val selectedLevel: ExplanationLevel = ExplanationLevel.BEGINNER,
    val noteSavedFeedback: Boolean = false
)

class LessonDetailViewModel(
    private val lessonId: String,
    private val academyRepository: AcademyRepository,
    componentRepository: ComponentRepository,
    prefsStore: UserPrefsStore
) : ViewModel() {

    private val levelFlow = MutableStateFlow(ExplanationLevel.BEGINNER)
    private val noteFeedbackFlow = MutableStateFlow(false)
    private var viewRecorded = false

    init {
        viewModelScope.launch {
            academyRepository.initializeAcademy()
            if (!viewRecorded && lessonId.isNotBlank()) {
                viewRecorded = true
                academyRepository.recordLessonView(lessonId)
            }
        }
    }

    val uiState: StateFlow<LessonDetailUiState> = combine(
        academyRepository.observeAllLessons(),
        academyRepository.observeLessonNote(lessonId),
        componentRepository.observeAllComponents(),
        prefsStore.language,
        levelFlow,
        noteFeedbackFlow
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val allLessons = values[0] as List<Lesson>
        val noteText = values[1] as String
        @Suppress("UNCHECKED_CAST")
        val allComponents = values[2] as List<ElectronicComponent>
        val language = values[3] as AppLanguage
        val level = values[4] as ExplanationLevel
        val feedback = values[5] as Boolean

        val current = allLessons.firstOrNull { it.id == lessonId }
        val next = current?.let { cur ->
            allLessons
                .filter { it.course == cur.course }
                .sortedBy { it.payload.orderIndex }
                .firstOrNull { it.payload.orderIndex > cur.payload.orderIndex }
        }

        val compById = allComponents.associateBy { it.id }
        val resolvedRelated = current?.payload?.relatedComponentIds
            .orEmpty()
            .mapNotNull { rawId -> compById[resolveComponentAlias(rawId)] }
            .distinctBy { it.id }

        LessonDetailUiState(
            isLoading = false,
            lesson = current,
            nextLesson = next,
            relatedComponents = resolvedRelated,
            noteText = noteText,
            language = language,
            selectedLevel = level,
            noteSavedFeedback = feedback
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LessonDetailUiState()
    )

    fun selectLevel(level: ExplanationLevel) {
        levelFlow.value = level
    }

    fun toggleBookmark() {
        viewModelScope.launch {
            academyRepository.toggleLessonBookmark(lessonId)
        }
    }

    fun toggleCompleted() {
        viewModelScope.launch {
            academyRepository.toggleLessonCompleted(lessonId)
        }
    }

    fun saveNote(text: String) {
        viewModelScope.launch {
            academyRepository.saveLessonNote(lessonId, text)
            noteFeedbackFlow.value = true
        }
    }

    fun clearNoteFeedback() {
        noteFeedbackFlow.value = false
    }

    companion object {
        private val componentAliases = mapOf(
            "led" to "led_diode",
            "diode_pn" to "pn_diode",
            "ne555_timer" to "timer_555",
            "lm7805" to "voltage_regulator",
            "ams1117" to "voltage_regulator",
            "ptc_fuse" to "ptc_resettable_fuse",
            "lm386" to "audio_amplifier_ic",
            "pam8403" to "audio_amplifier_ic",
            "switch_tactile" to "switch_component",
            "esp32" to "esp32_board",
            "esp8266" to "esp8266_board",
            "smps_unit" to "smps",
            "inverter_module" to "inverter",
            "tp4056_charger" to "battery_charger",
            "bms_module" to "bms"
        )

        fun resolveComponentAlias(id: String): String = componentAliases[id] ?: id
    }

    class Factory(
        private val lessonId: String,
        private val academyRepository: AcademyRepository,
        private val componentRepository: ComponentRepository,
        private val prefsStore: UserPrefsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LessonDetailViewModel(lessonId, academyRepository, componentRepository, prefsStore) as T
        }
    }
}
