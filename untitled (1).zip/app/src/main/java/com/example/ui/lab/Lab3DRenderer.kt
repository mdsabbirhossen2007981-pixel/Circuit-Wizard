package com.example.ui.lab

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.example.domain.calculator.EngineeringCalculators
import com.example.domain.lab.LabComponentCatalog
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabComponentDef
import com.example.domain.model.LabPinSpec
import com.example.domain.model.LabRenderMode
import com.example.domain.model.LabWire
import com.example.domain.model.LabWireColor
import com.example.domain.model.PinEndpoint
import com.example.domain.model.PlacedComponent
import com.example.domain.model.WireRouteStyle
import com.example.simulation.ComponentSimulationReading
import com.example.simulation.NetlistExtractor
import com.example.simulation.SafetySeverity
import com.example.simulation.SimulationResult
import com.example.simulation.SimulationWarning
import com.example.simulation.WireSimulationReading
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

data class HitTargetPin(
    val endpoint: PinEndpoint,
    val screenPos: Offset,
    val label: String
)

object LabGeometryHelper {
    val validHoleRows = listOf(-2, -1, 0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 12, 13)

    fun resolveEndpointWorld(
        endpoint: PinEndpoint,
        components: List<PlacedComponent>
    ): Pair<Float, Float> {
        if (endpoint.isBreadboardHole) {
            return endpoint.holeCol.toFloat() to endpoint.holeRow.toFloat()
        }
        val comp = components.firstOrNull { it.instanceId == endpoint.componentId } ?: return 0f to 0f
        val def = LabComponentCatalog.find(comp.typeId) ?: return comp.gridCol to comp.gridRow
        val pin = def.pins.firstOrNull { it.id == endpoint.pinId } ?: return comp.gridCol to comp.gridRow
        return NetlistExtractor.resolvePinWorldGrid(comp, pin)
    }

    fun nearestBreadboardHole(col: Float, row: Float): Pair<Int, Int>? {
        val nearestCol = col.roundToInt()
        if (nearestCol !in 0..29) return null
        val nearestRow = validHoleRows.minByOrNull { abs(it - row) } ?: return null
        if (abs(nearestRow - row) > 0.75f || abs(nearestCol - col) > 0.75f) return null
        return nearestCol to nearestRow
    }

    fun snapPlacementGrid(col: Float, row: Float, def: LabComponentDef): Pair<Float, Float> {
        if (!def.snapToBreadboard) {
            return (col * 2f).roundToInt() / 2f to (row * 2f).roundToInt() / 2f
        }
        val snappedCol = col.roundToInt().coerceIn(0, 29).toFloat()
        val snappedRow = if (def.typeId == "ic_555" || def.typeId == "ic_lm358" || def.typeId == "pushbutton") {
            // Two-row DIP / tactile switch can straddle center gap cleanly at row 4
            val candidates = listOf(0, 1, 2, 4, 6, 7, 8)
            candidates.minByOrNull { abs(it - row) }?.toFloat() ?: 4f
        } else {
            val nonRailRows = listOf(0, 1, 2, 3, 4, 6, 7, 8, 9, 10)
            nonRailRows.minByOrNull { abs(it - row) }?.toFloat() ?: 2f
        }
        return snappedCol to snappedRow
    }

    fun findHitComponent(
        screenX: Float,
        screenY: Float,
        viewWidth: Float,
        viewHeight: Float,
        camera: LabCamera3D,
        components: List<PlacedComponent>
    ): PlacedComponent? {
        val (worldCol, worldRow) = camera.screenToWorldGround(screenX, screenY, viewWidth, viewHeight)
        var best: PlacedComponent? = null
        var bestDist = Float.MAX_VALUE
        for (comp in components.reversed()) {
            val def = LabComponentCatalog.find(comp.typeId) ?: continue
            val bounds = componentWorldBounds(comp, def)
            val pad = 0.7f
            if (worldCol in (bounds.minCol - pad)..(bounds.maxCol + pad) &&
                worldRow in (bounds.minRow - pad)..(bounds.maxRow + pad)
            ) {
                val centerCol = (bounds.minCol + bounds.maxCol) * 0.5f
                val centerRow = (bounds.minRow + bounds.maxRow) * 0.5f
                val d = abs(worldCol - centerCol) + abs(worldRow - centerRow)
                if (d < bestDist) {
                    bestDist = d
                    best = comp
                }
            } else {
                // Check elevated top center in 3D mode
                val centerCol = (bounds.minCol + bounds.maxCol) * 0.5f
                val centerRow = (bounds.minRow + bounds.maxRow) * 0.5f
                val p = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ * 0.45f, viewWidth, viewHeight)
                val distPx = kotlin.math.hypot((screenX - p.offset.x).toDouble(), (screenY - p.offset.y).toDouble()).toFloat()
                if (distPx <= p.scale * 1.4f && distPx < bestDist) {
                    bestDist = distPx
                    best = comp
                }
            }
        }
        return best
    }

    fun findNearestPinOrHole(
        screenX: Float,
        screenY: Float,
        viewWidth: Float,
        viewHeight: Float,
        camera: LabCamera3D,
        components: List<PlacedComponent>,
        maxDistancePx: Float = 56f
    ): HitTargetPin? {
        var best: HitTargetPin? = null
        var bestDist = maxDistancePx

        // Component pins first (slightly higher priority)
        for (comp in components) {
            val def = LabComponentCatalog.find(comp.typeId) ?: continue
            for (pin in def.pins) {
                val (wx, wy) = NetlistExtractor.resolvePinWorldGrid(comp, pin)
                val p = camera.projectWorldToScreen(wx, wy, 0.05f, viewWidth, viewHeight).offset
                val d = kotlin.math.hypot((screenX - p.x).toDouble(), (screenY - p.y).toDouble()).toFloat()
                if (d < bestDist * 0.9f) {
                    bestDist = d
                    best = HitTargetPin(
                        endpoint = PinEndpoint(
                            isBreadboardHole = false,
                            componentId = comp.instanceId,
                            pinId = pin.id
                        ),
                        screenPos = p,
                        label = "${def.nameEn.substringBefore(" ")}:${pin.label}"
                    )
                }
            }
        }

        // Breadboard holes
        val (worldCol, worldRow) = camera.screenToWorldGround(screenX, screenY, viewWidth, viewHeight)
        val candidateCol = worldCol.roundToInt()
        if (candidateCol in 0..29) {
            for (r in validHoleRows) {
                if (abs(r - worldRow) <= 1.2f) {
                    val p = camera.projectWorldToScreen(candidateCol.toFloat(), r.toFloat(), 0.02f, viewWidth, viewHeight).offset
                    val d = kotlin.math.hypot((screenX - p.x).toDouble(), (screenY - p.y).toDouble()).toFloat()
                    if (d < bestDist) {
                        bestDist = d
                        best = HitTargetPin(
                            endpoint = PinEndpoint(
                                isBreadboardHole = true,
                                holeCol = candidateCol,
                                holeRow = r
                            ),
                            screenPos = p,
                            label = holeName(candidateCol, r)
                        )
                    }
                }
            }
        }
        return best
    }

    fun findHitWire(
        screenX: Float,
        screenY: Float,
        viewWidth: Float,
        viewHeight: Float,
        camera: LabCamera3D,
        snapshot: LabCircuitSnapshot,
        thresholdPx: Float = 32f
    ): LabWire? {
        var best: LabWire? = null
        var bestDist = thresholdPx
        val touch = Offset(screenX, screenY)
        for (wire in snapshot.wires) {
            val (c1, r1) = resolveEndpointWorld(wire.start, snapshot.components)
            val (c2, r2) = resolveEndpointWorld(wire.end, snapshot.components)
            val pts = sampleWirePoints(c1, r1, c2, r2, wire)
            for (i in 0 until pts.size - 1) {
                val pA = camera.projectWorldToScreen(pts[i].first, pts[i].second, pts[i].third, viewWidth, viewHeight).offset
                val pB = camera.projectWorldToScreen(pts[i + 1].first, pts[i + 1].second, pts[i + 1].third, viewWidth, viewHeight).offset
                val d = distancePointToSegment(touch, pA, pB)
                if (d < bestDist) {
                    bestDist = d
                    best = wire
                }
            }
        }
        return best
    }

    fun holeName(col: Int, row: Int): String {
        val cNum = col + 1
        return when (row) {
            -2 -> "Top + ($cNum)"
            -1 -> "Top − ($cNum)"
            in 0..4 -> "${'a' + row}$cNum"
            in 6..10 -> "${'f' + (row - 6)}$cNum"
            12 -> "Bot + ($cNum)"
            13 -> "Bot − ($cNum)"
            else -> "$cNum,$row"
        }
    }

    fun componentWorldBounds(comp: PlacedComponent, def: LabComponentDef): WorldBounds {
        val rot = ((comp.rotationDeg % 360) + 360) % 360
        val corners = listOf(
            -0.5f to -0.5f,
            (def.spanCols - 0.5f) to -0.5f,
            (def.spanCols - 0.5f) to (def.spanRows - 0.5f),
            -0.5f to (def.spanRows - 0.5f)
        ).map { (lx, ly) ->
            val (rx, ry) = when (rot) {
                90 -> -ly to lx
                180 -> -lx to -ly
                270 -> ly to -lx
                else -> lx to ly
            }
            (comp.gridCol + rx) to (comp.gridRow + ry)
        }
        return WorldBounds(
            minCol = corners.minOf { it.first },
            maxCol = corners.maxOf { it.first },
            minRow = corners.minOf { it.second },
            maxRow = corners.maxOf { it.second }
        )
    }

    fun sampleWirePoints(
        c1: Float,
        r1: Float,
        c2: Float,
        r2: Float,
        wire: LabWire
    ): List<Triple<Float, Float, Float>> {
        val style = runCatching { WireRouteStyle.valueOf(wire.routeStyle) }.getOrDefault(WireRouteStyle.CURVED)
        val archZ = wire.bendOffset.coerceIn(0.15f, 2.5f)
        return when (style) {
            WireRouteStyle.DIRECT -> listOf(
                Triple(c1, r1, 0.08f),
                Triple((c1 + c2) * 0.5f, (r1 + r2) * 0.5f, archZ * 0.55f),
                Triple(c2, r2, 0.08f)
            )
            WireRouteStyle.MANHATTAN -> {
                val midC = if (abs(c2 - c1) >= abs(r2 - r1)) c2 else c1
                val midR = if (abs(c2 - c1) >= abs(r2 - r1)) r1 else r2
                val lift = archZ * 0.45f
                listOf(
                    Triple(c1, r1, 0.06f),
                    Triple(c1, r1, lift),
                    Triple(midC, midR, lift),
                    Triple(c2, r2, lift),
                    Triple(c2, r2, 0.06f)
                )
            }
            WireRouteStyle.CURVED -> {
                val steps = 12
                val perpShift = (wire.bendOffset - 0.8f) * 1.4f
                val dx = c2 - c1
                val dy = r2 - r1
                val len = kotlin.math.hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(0.1f)
                val nx = -dy / len
                val ny = dx / len
                val ctrlC = (c1 + c2) * 0.5f + nx * perpShift
                val ctrlR = (r1 + r2) * 0.5f + ny * perpShift
                (0..steps).map { i ->
                    val t = i / steps.toFloat()
                    val omt = 1f - t
                    val wc = omt * omt * c1 + 2f * omt * t * ctrlC + t * t * c2
                    val wr = omt * omt * r1 + 2f * omt * t * ctrlR + t * t * r2
                    val wz = 0.08f + 4f * t * omt * archZ
                    Triple(wc, wr, wz)
                }
            }
        }
    }

    private fun distancePointToSegment(p: Offset, a: Offset, b: Offset): Float {
        val vx = b.x - a.x
        val vy = b.y - a.y
        val wx = p.x - a.x
        val wy = p.y - a.y
        val c1 = wx * vx + wy * vy
        if (c1 <= 0f) return kotlin.math.hypot((p.x - a.x).toDouble(), (p.y - a.y).toDouble()).toFloat()
        val c2 = vx * vx + vy * vy
        if (c2 <= c1) return kotlin.math.hypot((p.x - b.x).toDouble(), (p.y - b.y).toDouble()).toFloat()
        val ratio = c1 / c2
        val projX = a.x + ratio * vx
        val projY = a.y + ratio * vy
        return kotlin.math.hypot((p.x - projX).toDouble(), (p.y - projY).toDouble()).toFloat()
    }
}

data class WorldBounds(
    val minCol: Float,
    val maxCol: Float,
    val minRow: Float,
    val maxRow: Float
)

@Composable
fun Lab3DCanvas(
    snapshot: LabCircuitSnapshot,
    camera: LabCamera3D,
    selectedComponentIds: Set<String>,
    selectedWireId: String?,
    wiringStart: PinEndpoint?,
    rubberBandEnd: Offset?,
    snapHighlight: HitTargetPin?,
    showPinLabels: Boolean,
    isDarkTheme: Boolean,
    simulationResult: SimulationResult? = null,
    isSimActive: Boolean = false,
    flowAnimPhase: Float = 0f,
    modifier: Modifier = Modifier
) {
    val labelPaint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        // 1. Studio Laboratory Workbench Background
        drawRect(
            brush = Brush.verticalGradient(
                colors = if (isDarkTheme) {
                    listOf(Color(0xFF0A1018), Color(0xFF101926), Color(0xFF0B111A))
                } else {
                    listOf(Color(0xFFE7EEF6), Color(0xFFF3F7FB), Color(0xFFE2EBF4))
                }
            )
        )
        drawWorkbenchGrid(w, h, camera, isDarkTheme)

        // 2. Realistic Solderless Breadboard (3D/2.5D housing, rails, trench, labels, 420 recessed holes)
        drawBreadboard3D(w, h, camera, labelPaint, snapHighlight, isDarkTheme)

        // 3. Depth-sorted electronic components
        val sortedComponents = snapshot.components.sortedBy { comp ->
            val p = camera.projectWorldToScreen(comp.gridCol, comp.gridRow, 0f, w, h)
            p.depth
        }

        val simWarningsByComp = if (isSimActive && simulationResult != null) {
            simulationResult.warnings.filter { it.componentId != null }.groupBy { it.componentId!! }
        } else emptyMap()

        for (comp in sortedComponents) {
            val def = LabComponentCatalog.find(comp.typeId) ?: continue
            val isSelected = comp.instanceId in selectedComponentIds
            val reading = if (isSimActive) simulationResult?.componentReadings?.get(comp.instanceId) else null
            drawComponent3D(
                comp = comp,
                def = def,
                isSelected = isSelected,
                showPins = isSelected || showPinLabels,
                reading = reading,
                warnings = simWarningsByComp[comp.instanceId].orEmpty(),
                simTimeSec = simulationResult?.simTimeSec ?: 0.0,
                viewW = w,
                viewH = h,
                camera = camera,
                paint = labelPaint
            )
        }

        // 4. Elevated 3D / 2.5D Jumper Wires + Live Current Flow Indicators
        for (wire in snapshot.wires) {
            val wireReading = if (isSimActive) simulationResult?.wireReadings?.get(wire.id) else null
            drawWire3D(
                wire = wire,
                components = snapshot.components,
                isSelected = wire.id == selectedWireId,
                wireReading = wireReading,
                flowAnimPhase = flowAnimPhase,
                viewW = w,
                viewH = h,
                camera = camera
            )
        }

        // 5. Active Wiring Source + Rubber-Band Preview + Magnetic Snap Halo
        if (wiringStart != null) {
            val (sc, sr) = LabGeometryHelper.resolveEndpointWorld(wiringStart, snapshot.components)
            val pStart = camera.projectWorldToScreen(sc, sr, 0.08f, w, h)
            drawCircle(
                color = Color(0xFF22D3EE),
                radius = (pStart.scale * 0.42f).coerceIn(7f, 16f),
                center = pStart.offset
            )
            drawCircle(
                color = Color.White,
                radius = (pStart.scale * 0.42f).coerceIn(7f, 16f),
                center = pStart.offset,
                style = Stroke(width = 2.5f)
            )
            if (rubberBandEnd != null) {
                val target = snapHighlight?.screenPos ?: rubberBandEnd
                drawLine(
                    color = Color(0xFF22D3EE),
                    start = pStart.offset,
                    end = target,
                    strokeWidth = 5f,
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
                )
            }
        }

        if (snapHighlight != null) {
            drawCircle(
                color = Color(0xFFF59E0B).copy(alpha = 0.28f),
                radius = 22f,
                center = snapHighlight.screenPos
            )
            drawCircle(
                color = Color(0xFFF59E0B),
                radius = 12f,
                center = snapHighlight.screenPos,
                style = Stroke(width = 3f)
            )
        }
    }
}

private fun DrawScope.drawWorkbenchGrid(
    w: Float,
    h: Float,
    camera: LabCamera3D,
    isDarkTheme: Boolean
) {
    val majorColor = if (isDarkTheme) Color(0xFF1F2D3D) else Color(0xFFCBD5E1)
    val minorColor = if (isDarkTheme) Color(0xFF131D2B) else Color(0xFFE2E8F0)

    for (c in -12..42 step 2) {
        val p1 = camera.projectWorldToScreen(c.toFloat(), -12f, -0.75f, w, h).offset
        val p2 = camera.projectWorldToScreen(c.toFloat(), 24f, -0.75f, w, h).offset
        drawLine(if (c % 6 == 0) majorColor else minorColor, p1, p2, strokeWidth = if (c % 6 == 0) 1.5f else 0.8f)
    }
    for (r in -12..24 step 2) {
        val p1 = camera.projectWorldToScreen(-12f, r.toFloat(), -0.75f, w, h).offset
        val p2 = camera.projectWorldToScreen(42f, r.toFloat(), -0.75f, w, h).offset
        drawLine(if (r % 6 == 0) majorColor else minorColor, p1, p2, strokeWidth = if (r % 6 == 0) 1.5f else 0.8f)
    }
}

private fun DrawScope.drawBreadboard3D(
    w: Float,
    h: Float,
    camera: LabCamera3D,
    paint: Paint,
    snapHighlight: HitTargetPin?,
    isDarkTheme: Boolean
) {
    val is3D = camera.renderMode == LabRenderMode.PERSPECTIVE_3D

    // Drop shadow under breadboard in 3D mode
    if (is3D) {
        drawQuad(
            camera, w, h,
            -1.1f, 30.5f, -2.9f, 14.3f, -0.76f,
            Color.Black.copy(alpha = if (isDarkTheme) 0.42f else 0.18f)
        )
    }

    // 3D Plastic ABS Body
    drawExtrudedBox3D(
        camera = camera,
        viewW = w,
        viewH = h,
        minCol = -1.35f,
        maxCol = 30.35f,
        minRow = -3.15f,
        maxRow = 14.15f,
        zBottom = if (is3D) -0.72f else 0f,
        zTop = 0f,
        topColor = Color(0xFFF3EFE6),
        frontColor = Color(0xFFD6CFC2),
        sideColor = Color(0xFFC2B9A8),
        borderColor = Color(0xFF9E9484)
    )

    // Power rail stripes: Top (+ red above row -2, - blue below row -1) & Bottom (+ red above 12, - blue below 13)
    drawBoardLine(camera, w, h, 0f, -2.45f, 29f, -2.45f, Color(0xFFDC2626), 2.5f)
    drawBoardLine(camera, w, h, 0f, -0.55f, 29f, -0.55f, Color(0xFF2563EB), 2.5f)
    drawBoardLine(camera, w, h, 0f, 11.55f, 29f, 11.55f, Color(0xFFDC2626), 2.5f)
    drawBoardLine(camera, w, h, 0f, 13.45f, 29f, 13.45f, Color(0xFF2563EB), 2.5f)

    // Center IC trench recess (between row 4 and row 6)
    drawQuad(
        camera, w, h,
        -1.35f, 30.35f, 4.62f, 5.38f, 0.004f,
        Color(0xFFDDD6C7)
    )
    drawBoardLine(camera, w, h, -1.35f, 4.62f, 30.35f, 4.62f, Color(0xFFB5AD9C), 1.2f)
    drawBoardLine(camera, w, h, -1.35f, 5.38f, 30.35f, 5.38f, Color(0xFFB5AD9C), 1.2f)

    // '+' and '-' rail labels
    val refScale = camera.projectWorldToScreen(14f, 5f, 0f, w, h).scale
    paint.textSize = (refScale * 0.56f).coerceIn(10f, 22f)
    paint.color = android.graphics.Color.rgb(220, 38, 38)
    drawWorldText(camera, w, h, -0.82f, -2.0f, 0.01f, "+", paint)
    drawWorldText(camera, w, h, -0.82f, 12.0f, 0.01f, "+", paint)
    paint.color = android.graphics.Color.rgb(37, 99, 235)
    drawWorldText(camera, w, h, -0.82f, -1.0f, 0.01f, "−", paint)
    drawWorldText(camera, w, h, -0.82f, 13.0f, 0.01f, "−", paint)

    // Row labels a..e and f..j
    paint.textSize = (refScale * 0.44f).coerceIn(8f, 17f)
    paint.color = android.graphics.Color.rgb(71, 85, 105)
    for (i in 0..4) {
        val label = ('a' + i).toString()
        drawWorldText(camera, w, h, -0.78f, i.toFloat(), 0.01f, label, paint)
        drawWorldText(camera, w, h, 29.78f, i.toFloat(), 0.01f, label, paint)
    }
    for (i in 0..4) {
        val label = ('f' + i).toString()
        val r = (6 + i).toFloat()
        drawWorldText(camera, w, h, -0.78f, r, 0.01f, label, paint)
        drawWorldText(camera, w, h, 29.78f, r, 0.01f, label, paint)
    }

    // Column markings 1, 5, 10, 15, 20, 25, 30
    paint.textSize = (refScale * 0.42f).coerceIn(8f, 16f)
    for (col in listOf(0, 4, 9, 14, 19, 24, 29)) {
        val label = (col + 1).toString()
        drawWorldText(camera, w, h, col.toFloat(), 5.0f, 0.01f, label, paint)
    }

    // 420 Breadboard Holes (30 columns x 14 valid rows)
    val snapHole = snapHighlight?.endpoint?.takeIf { it.isBreadboardHole }
    for (c in 0..29) {
        for (r in LabGeometryHelper.validHoleRows) {
            val pt = camera.projectWorldToScreen(c.toFloat(), r.toFloat(), 0.01f, w, h)
            val holeR = (pt.scale * 0.21f).coerceIn(2.2f, 9f)
            val isSnapped = snapHole?.holeCol == c && snapHole.holeRow == r
            val topLeft = Offset(pt.offset.x - holeR, pt.offset.y - holeR)
            val sz = androidx.compose.ui.geometry.Size(holeR * 2f, holeR * 2f)

            drawRect(
                color = if (isSnapped) Color(0xFFF59E0B) else Color(0xFF475569),
                topLeft = topLeft,
                size = sz
            )
            drawRect(
                color = Color(0xFF0F172A),
                topLeft = Offset(pt.offset.x - holeR * 0.65f, pt.offset.y - holeR * 0.65f),
                size = androidx.compose.ui.geometry.Size(holeR * 1.3f, holeR * 1.3f)
            )
        }
    }
}

private fun DrawScope.drawComponent3D(
    comp: PlacedComponent,
    def: LabComponentDef,
    isSelected: Boolean,
    showPins: Boolean,
    reading: ComponentSimulationReading?,
    warnings: List<SimulationWarning>,
    simTimeSec: Double,
    viewW: Float,
    viewH: Float,
    camera: LabCamera3D,
    paint: Paint
) {
    val bounds = LabGeometryHelper.componentWorldBounds(comp, def)
    val centerCol = (bounds.minCol + bounds.maxCol) * 0.5f
    val centerRow = (bounds.minRow + bounds.maxRow) * 0.5f

    // Selection or safety alert footprint
    val hasCritical = warnings.any { it.severity == SafetySeverity.CRITICAL }
    val hasWarning = warnings.any { it.severity == SafetySeverity.WARNING }
    if (isSelected || hasCritical || hasWarning) {
        val ringColor = when {
            hasCritical -> Color(0xFFEF4444)
            hasWarning -> Color(0xFFF59E0B)
            else -> Color(0xFF22D3EE)
        }
        drawQuad(
            camera, viewW, viewH,
            bounds.minCol - 0.25f, bounds.maxCol + 0.25f,
            bounds.minRow - 0.25f, bounds.maxRow + 0.25f,
            0.015f,
            ringColor.copy(alpha = if (hasCritical) 0.28f else 0.20f)
        )
        drawQuadOutline(
            camera, viewW, viewH,
            bounds.minCol - 0.25f, bounds.maxCol + 0.25f,
            bounds.minRow - 0.25f, bounds.maxRow + 0.25f,
            0.02f,
            ringColor,
            strokeWidth = 3f
        )
    }

    // Metallic component leads from pins to component body level
    val leadZ = (def.heightZ * 0.28f).coerceIn(0.12f, 0.36f)
    for (pin in def.pins) {
        val (px, py) = NetlistExtractor.resolvePinWorldGrid(comp, pin)
        val pBase = camera.projectWorldToScreen(px, py, 0.01f, viewW, viewH).offset
        val pTop = camera.projectWorldToScreen(px, py, leadZ, viewW, viewH).offset
        drawLine(Color(0xFFCBD5E1), pBase, pTop, strokeWidth = 3.2f, cap = StrokeCap.Round)
    }

    // Visual Model Dispatcher
    when (def.visualStyle) {
        "RESISTOR_AXIAL" -> drawResistor3D(comp, def, bounds, camera, viewW, viewH, paint)
        "POTENTIOMETER" -> drawPotentiometer3D(comp, bounds, centerCol, centerRow, camera, viewW, viewH)
        "CAP_CERAMIC" -> drawCeramicCap3D(centerCol, centerRow, def, camera, viewW, viewH, paint)
        "CAP_ELECTRO" -> drawElectroCap3D(comp, def, centerCol, centerRow, camera, viewW, viewH)
        "INDUCTOR_COIL" -> drawInductor3D(bounds, def, camera, viewW, viewH)
        "DIODE_AXIAL", "DIODE_ZENER" -> drawDiode3D(comp, bounds, def, camera, viewW, viewH)
        "LED_DOME" -> drawLed3D(comp, def, centerCol, centerRow, reading, camera, viewW, viewH, paint)
        "TO92_BJT" -> drawTransistor3D(centerCol, centerRow, def, comp, camera, viewW, viewH, paint)
        "TO220_MOSFET" -> drawMosfet3D(centerCol, centerRow, def, camera, viewW, viewH, paint)
        "IC_DIP8" -> drawDipIc3D(comp, def, bounds, centerCol, centerRow, camera, viewW, viewH, paint)
        "SWITCH_SLIDE" -> drawSlideSwitch3D(comp, bounds, def, camera, viewW, viewH)
        "PUSHBUTTON" -> drawPushButton3D(comp, bounds, def, centerCol, centerRow, camera, viewW, viewH)
        "BATTERY_9V" -> drawBattery9V3D(bounds, centerCol, centerRow, camera, viewW, viewH, paint)
        "BATTERY_AA" -> drawBatteryAA3D(bounds, centerCol, centerRow, camera, viewW, viewH, paint)
        "BENCH_PSU" -> drawBenchPsu3D(comp, bounds, centerCol, centerRow, camera, viewW, viewH, paint)
        "SENSOR_LDR" -> drawLdr3D(centerCol, centerRow, def, camera, viewW, viewH)
        "SENSOR_HCSR04" -> drawHcSr043D(bounds, centerCol, centerRow, def, camera, viewW, viewH, paint)
        "MOTOR_DC" -> drawMotor3D(bounds, centerCol, centerRow, def, reading, simTimeSec, camera, viewW, viewH, paint)
        "RELAY_5V" -> drawRelay3D(bounds, centerCol, centerRow, def, reading, camera, viewW, viewH, paint)
        "BOARD_UNO" -> drawArduinoUno3D(bounds, centerCol, centerRow, def, camera, viewW, viewH, paint)
        "BOARD_ESP32" -> drawEsp323D(bounds, centerCol, centerRow, def, camera, viewW, viewH, paint)
        "DISPLAY_7SEG" -> drawSevenSeg3D(bounds, centerCol, centerRow, def, camera, viewW, viewH)
        "DISPLAY_LCD16X2" -> drawLcd16x23D(bounds, centerCol, centerRow, def, camera, viewW, viewH, paint)
        "SCREW_TERM" -> drawScrewTerminal3D(bounds, def, camera, viewW, viewH)
        "WIRE_BRIDGE" -> drawJumperBridge3D(comp, def, camera, viewW, viewH)
        "GND_TERM" -> drawGroundTerminal3D(centerCol, centerRow, camera, viewW, viewH, paint)
        else -> drawExtrudedBox3D(
            camera, viewW, viewH,
            bounds.minCol + 0.1f, bounds.maxCol - 0.1f,
            bounds.minRow + 0.1f, bounds.maxRow - 0.1f,
            0.12f, def.heightZ,
            Color(0xFF475569), Color(0xFF334155), Color(0xFF1E293B), Color(0xFF94A3B8)
        )
    }

    // Draw interactive pin pads when selected or wiring
    if (showPins) {
        for (pin in def.pins) {
            val (px, py) = NetlistExtractor.resolvePinWorldGrid(comp, pin)
            val pt = camera.projectWorldToScreen(px, py, 0.04f, viewW, viewH)
            drawCircle(Color(0xFFF59E0B), radius = (pt.scale * 0.24f).coerceIn(5f, 11f), center = pt.offset)
            drawCircle(Color.White, radius = (pt.scale * 0.24f).coerceIn(5f, 11f), center = pt.offset, style = Stroke(1.8f))
            if (isSelected) {
                paint.textSize = (pt.scale * 0.34f).coerceIn(9f, 14f)
                paint.color = android.graphics.Color.WHITE
                drawContext.canvas.nativeCanvas.drawText(pin.label, pt.offset.x, pt.offset.y - 12f, paint)
            }
        }
    }

    // Live electrical telemetry pill on selected component during active simulation
    if (isSelected && reading != null) {
        val topPt = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ + 0.45f, viewW, viewH)
        val badgeText = "${"%.2f".format(reading.voltageDropV)}V • ${"%.1f".format(reading.currentMa)}mA • ${"%.1f".format(reading.powerMw)}mW"
        paint.textSize = (topPt.scale * 0.34f).coerceIn(10f, 15f)
        paint.color = android.graphics.Color.rgb(34, 211, 238)
        drawContext.canvas.nativeCanvas.drawText(badgeText, topPt.offset.x, topPt.offset.y, paint)
    }
}

private fun DrawScope.drawResistor3D(
    comp: PlacedComponent,
    def: LabComponentDef,
    bounds: WorldBounds,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    val (p1x, p1y) = NetlistExtractor.resolvePinWorldGrid(comp, def.pins[0])
    val (p2x, p2y) = NetlistExtractor.resolvePinWorldGrid(comp, def.pins[1])
    val p1 = camera.projectWorldToScreen(p1x, p1y, 0.24f, viewW, viewH)
    val p2 = camera.projectWorldToScreen(p2x, p2y, 0.24f, viewW, viewH)

    // Wire lead bridge
    drawLine(Color(0xFFCBD5E1), p1.offset, p2.offset, strokeWidth = 4f, cap = StrokeCap.Round)

    // Ceramic body center (50% of span)
    val b1 = Offset(p1.offset.x + (p2.offset.x - p1.offset.x) * 0.24f, p1.offset.y + (p2.offset.y - p1.offset.y) * 0.24f)
    val b2 = Offset(p1.offset.x + (p2.offset.x - p1.offset.x) * 0.76f, p1.offset.y + (p2.offset.y - p1.offset.y) * 0.76f)
    val thickness = (p1.scale * 0.56f).coerceIn(10f, 24f)

    // Subtle shadow on breadboard
    val s1 = camera.projectWorldToScreen(p1x + (p2x - p1x) * 0.24f, p1y + (p2y - p1y) * 0.24f, 0.02f, viewW, viewH).offset
    val s2 = camera.projectWorldToScreen(p1x + (p2x - p1x) * 0.76f, p1y + (p2y - p1y) * 0.76f, 0.02f, viewW, viewH).offset
    drawLine(Color.Black.copy(alpha = 0.25f), s1, s2, strokeWidth = thickness * 0.9f, cap = StrokeCap.Round)

    // Tan epoxy body
    drawLine(Color(0xFFD9B38C), b1, b2, strokeWidth = thickness, cap = StrokeCap.Round)

    // 4 dynamic resistor color bands
    val bandColors = computeFourBandColors(
        valueStr = comp.properties["value"] ?: "330",
        unit = comp.properties["unit"] ?: "Ω"
    )
    val fractions = listOf(0.18f, 0.36f, 0.54f, 0.78f)
    fractions.forEachIndexed { idx, f ->
        val bx1 = b1.x + (b2.x - b1.x) * (f - 0.04f)
        val by1 = b1.y + (b2.y - b1.y) * (f - 0.04f)
        val bx2 = b1.x + (b2.x - b1.x) * (f + 0.04f)
        val by2 = b1.y + (b2.y - b1.y) * (f + 0.04f)
        drawLine(bandColors[idx], Offset(bx1, by1), Offset(bx2, by2), strokeWidth = thickness * 0.92f)
    }

    val center = Offset((b1.x + b2.x) * 0.5f, (b1.y + b2.y) * 0.5f - thickness * 0.85f)
    paint.textSize = (p1.scale * 0.38f).coerceIn(9f, 15f)
    paint.color = android.graphics.Color.WHITE
    val label = "${comp.properties["value"] ?: "330"}${comp.properties["unit"] ?: "Ω"}"
    drawContext.canvas.nativeCanvas.drawText(label, center.x, center.y, paint)
}

fun computeFourBandColors(valueStr: String, unit: String): List<Color> {
    val raw = valueStr.toDoubleOrNull()?.coerceAtLeast(1.0) ?: 330.0
    val multiplierScale = when (unit.trim()) {
        "kΩ", "k" -> 1_000.0
        "MΩ", "M" -> 1_000_000.0
        else -> 1.0
    }
    val ohms = (raw * multiplierScale).coerceIn(1.0, 99_000_000_000.0)
    val exp = floor(log10(ohms)).toInt()
    val norm = (ohms / 10.0.pow((exp - 1).toDouble())).roundToInt().coerceIn(10, 99)
    val d1 = (norm / 10).coerceIn(1, 9)
    val d2 = (norm % 10).coerceIn(0, 9)
    val multExp = (exp - 1).coerceIn(-2, 7)

    fun digitColor(d: Int): Color {
        val band = EngineeringCalculators.resistorBands.firstOrNull { it.digit == d }
        return Color(band?.colorHex ?: 0xFF78350F)
    }
    val multColor = when (multExp) {
        -2 -> Color(0xFFCBD5E1)
        -1 -> Color(0xFFF59E0B)
        else -> digitColor(multExp)
    }
    return listOf(digitColor(d1), digitColor(d2), multColor, Color(0xFFF59E0B))
}

private fun DrawScope.drawPotentiometer3D(
    comp: PlacedComponent,
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.1f, bounds.maxCol - 0.1f,
        bounds.minRow + 0.1f, bounds.maxRow - 0.1f,
        0.14f, 0.55f,
        Color(0xFF1D4ED8), Color(0xFF1E40AF), Color(0xFF1E3A8A), Color(0xFF60A5FA)
    )
    val base = camera.projectWorldToScreen(centerCol, centerRow, 0.6f, viewW, viewH)
    val top = camera.projectWorldToScreen(centerCol, centerRow, 0.92f, viewW, viewH)
    val r = (top.scale * 0.72f).coerceIn(12f, 28f)
    drawCircle(Color(0xFF475569), radius = r, center = base.offset)
    drawCircle(Color(0xFF94A3B8), radius = r, center = top.offset)
    drawCircle(Color(0xFF334155), radius = r * 0.72f, center = top.offset)

    val pct = (comp.properties["wiperPct"]?.toFloatOrNull() ?: 50f).coerceIn(0f, 100f)
    val angleRad = Math.toRadians((-225.0 + (pct / 100f) * 270.0))
    val tip = Offset(
        top.offset.x + kotlin.math.cos(angleRad).toFloat() * r * 0.7f,
        top.offset.y + kotlin.math.sin(angleRad).toFloat() * r * 0.7f
    )
    drawLine(Color(0xFFF59E0B), top.offset, tip, strokeWidth = 3.5f, cap = StrokeCap.Round)
}

private fun DrawScope.drawCeramicCap3D(
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    val p = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ * 0.75f, viewW, viewH)
    val r = (p.scale * 0.58f).coerceIn(10f, 24f)
    drawCircle(Color(0xFFEA580C), radius = r, center = p.offset)
    drawCircle(Color(0xFFFED7AA), radius = r, center = p.offset, style = Stroke(2f))
    paint.textSize = (r * 0.55f).coerceIn(8f, 13f)
    paint.color = android.graphics.Color.WHITE
    drawContext.canvas.nativeCanvas.drawText("104", p.offset.x, p.offset.y + 4f, paint)
}

private fun DrawScope.drawElectroCap3D(
    comp: PlacedComponent,
    def: LabComponentDef,
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    val bot = camera.projectWorldToScreen(centerCol, centerRow, 0.16f, viewW, viewH)
    val top = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ, viewW, viewH)
    val r = (top.scale * 0.58f).coerceIn(10f, 25f)
    drawLine(Color(0xFF1E3A8A), bot.offset, top.offset, strokeWidth = r * 2f, cap = StrokeCap.Round)
    // Negative polarity vertical stripe
    val rot = ((comp.rotationDeg % 360) + 360) % 360
    val stripeShift = if (rot == 180 || rot == 270) -r * 0.5f else r * 0.5f
    drawLine(
        Color(0xFFCBD5E1),
        Offset(bot.offset.x + stripeShift, bot.offset.y),
        Offset(top.offset.x + stripeShift, top.offset.y),
        strokeWidth = 4f
    )
    drawCircle(Color(0xFF94A3B8), radius = r * 0.92f, center = top.offset)
    drawLine(Color(0xFF475569), Offset(top.offset.x - r * 0.5f, top.offset.y), Offset(top.offset.x + r * 0.5f, top.offset.y), 1.5f)
    drawLine(Color(0xFF475569), Offset(top.offset.x, top.offset.y - r * 0.5f), Offset(top.offset.x, top.offset.y + r * 0.5f), 1.5f)
}

private fun DrawScope.drawInductor3D(
    bounds: WorldBounds,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    val p1 = camera.projectWorldToScreen(bounds.minCol + 0.5f, (bounds.minRow + bounds.maxRow) * 0.5f, 0.36f, viewW, viewH)
    val p2 = camera.projectWorldToScreen(bounds.maxCol - 0.5f, (bounds.minRow + bounds.maxRow) * 0.5f, 0.36f, viewW, viewH)
    val thick = (p1.scale * 0.65f).coerceIn(12f, 24f)
    drawLine(Color(0xFF334155), p1.offset, p2.offset, strokeWidth = thick, cap = StrokeCap.Round)
    for (i in 1..5) {
        val t = i / 6f
        val x = p1.offset.x + (p2.offset.x - p1.offset.x) * t
        val y = p1.offset.y + (p2.offset.y - p1.offset.y) * t
        drawCircle(Color(0xFFD97706), radius = thick * 0.54f, center = Offset(x, y), style = Stroke(3.5f))
    }
}

private fun DrawScope.drawDiode3D(
    comp: PlacedComponent,
    bounds: WorldBounds,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    val (ax, ay) = NetlistExtractor.resolvePinWorldGrid(comp, def.pins[0])
    val (kx, ky) = NetlistExtractor.resolvePinWorldGrid(comp, def.pins[1])
    val p1 = camera.projectWorldToScreen(ax, ay, 0.25f, viewW, viewH)
    val p2 = camera.projectWorldToScreen(kx, ky, 0.25f, viewW, viewH)
    drawLine(Color(0xFFCBD5E1), p1.offset, p2.offset, strokeWidth = 3.5f)

    val b1 = Offset(p1.offset.x + (p2.offset.x - p1.offset.x) * 0.26f, p1.offset.y + (p2.offset.y - p1.offset.y) * 0.26f)
    val b2 = Offset(p1.offset.x + (p2.offset.x - p1.offset.x) * 0.74f, p1.offset.y + (p2.offset.y - p1.offset.y) * 0.74f)
    val bodyColor = if (def.visualStyle == "DIODE_ZENER") Color(0xFFF97316) else Color(0xFF1E293B)
    val cathodeBand = if (def.visualStyle == "DIODE_ZENER") Color(0xFF0F172A) else Color(0xFFE2E8F0)
    val thick = (p1.scale * 0.55f).coerceIn(10f, 22f)
    drawLine(bodyColor, b1, b2, strokeWidth = thick, cap = StrokeCap.Butt)

    val kBand1 = Offset(b1.x + (b2.x - b1.x) * 0.78f, b1.y + (b2.y - b1.y) * 0.78f)
    val kBand2 = Offset(b1.x + (b2.x - b1.x) * 0.92f, b1.y + (b2.y - b1.y) * 0.92f)
    drawLine(cathodeBand, kBand1, kBand2, strokeWidth = thick)
}

private fun DrawScope.drawLed3D(
    comp: PlacedComponent,
    def: LabComponentDef,
    centerCol: Float,
    centerRow: Float,
    reading: ComponentSimulationReading?,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    val ledColor = when (comp.properties["color"]?.lowercase()) {
        "green" -> Color(0xFF10B981)
        "blue" -> Color(0xFF3B82F6)
        "yellow" -> Color(0xFFFACC15)
        "white" -> Color(0xFFF1F5F9)
        else -> Color(0xFFEF4444)
    }
    val base = camera.projectWorldToScreen(centerCol, centerRow, 0.28f, viewW, viewH)
    val dome = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ, viewW, viewH)
    val r = (dome.scale * 0.56f).coerceIn(10f, 24f)

    // Physical epoxy rim & body
    drawCircle(ledColor.copy(alpha = 0.78f), radius = r * 1.12f, center = base.offset)
    drawLine(ledColor.copy(alpha = 0.85f), base.offset, dome.offset, strokeWidth = r * 1.8f, cap = StrokeCap.Round)
    drawCircle(ledColor, radius = r * 0.92f, center = dome.offset)
    drawCircle(Color.White.copy(alpha = 0.38f), radius = r * 0.35f, center = Offset(dome.offset.x - r * 0.28f, dome.offset.y - r * 0.28f))

    // Real current-driven LED luminescence
    val bright = reading?.brightnessFraction ?: 0f
    if (bright > 0.02f) {
        drawCircle(
            color = ledColor.copy(alpha = (0.28f * bright).coerceAtMost(0.45f)),
            radius = r * (1.8f + 1.4f * bright),
            center = dome.offset
        )
        drawCircle(
            color = ledColor.copy(alpha = (0.55f * bright).coerceAtMost(0.75f)),
            radius = r * (1.25f + 0.55f * bright),
            center = dome.offset
        )
        drawCircle(
            color = Color.White.copy(alpha = (0.75f * bright).coerceAtMost(0.92f)),
            radius = r * 0.52f,
            center = dome.offset
        )
    } else if (reading?.isReverseBiased == true) {
        paint.textSize = (r * 0.7f).coerceIn(10f, 15f)
        paint.color = android.graphics.Color.rgb(248, 113, 113)
        drawContext.canvas.nativeCanvas.drawText("REV!", dome.offset.x, dome.offset.y - r - 6f, paint)
    }
}

private fun DrawScope.drawTransistor3D(
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    comp: PlacedComponent,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    val bot = camera.projectWorldToScreen(centerCol, centerRow, 0.28f, viewW, viewH)
    val top = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ, viewW, viewH)
    val r = (top.scale * 0.58f).coerceIn(10f, 22f)
    drawLine(Color(0xFF1F2937), bot.offset, top.offset, strokeWidth = r * 2f, cap = StrokeCap.Round)
    drawCircle(Color(0xFF374151), radius = r, center = top.offset)
    paint.textSize = (r * 0.58f).coerceIn(8f, 12f)
    paint.color = android.graphics.Color.LTGRAY
    drawContext.canvas.nativeCanvas.drawText(comp.properties["polarity"] ?: "NPN", top.offset.x, top.offset.y + 4f, paint)
}

private fun DrawScope.drawMosfet3D(
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    val bot = camera.projectWorldToScreen(centerCol, centerRow, 0.3f, viewW, viewH)
    val bodyTop = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ * 0.68f, viewW, viewH)
    val tabTop = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ, viewW, viewH)
    val w = (tabTop.scale * 1.4f).coerceIn(16f, 36f)
    // Metal heatsink tab
    drawLine(Color(0xFFCBD5E1), bodyTop.offset, tabTop.offset, strokeWidth = w, cap = StrokeCap.Butt)
    drawCircle(Color(0xFF475569), radius = w * 0.18f, center = Offset((bodyTop.offset.x + tabTop.offset.x) * 0.5f, (bodyTop.offset.y + tabTop.offset.y) * 0.5f))
    // Black epoxy case
    drawLine(Color(0xFF0F172A), bot.offset, bodyTop.offset, strokeWidth = w, cap = StrokeCap.Butt)
    paint.textSize = (w * 0.34f).coerceIn(8f, 12f)
    paint.color = android.graphics.Color.WHITE
    drawContext.canvas.nativeCanvas.drawText("MOS", bodyTop.offset.x, bodyTop.offset.y + 4f, paint)
}

private fun DrawScope.drawDipIc3D(
    comp: PlacedComponent,
    def: LabComponentDef,
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.1f, bounds.maxCol - 0.1f,
        bounds.minRow + 0.3f, bounds.maxRow - 0.3f,
        0.16f, def.heightZ,
        Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF090D16), Color(0xFF475569)
    )
    // Pin 1 notch
    val notch = camera.projectWorldToScreen(bounds.minCol + 0.35f, centerRow, def.heightZ + 0.01f, viewW, viewH)
    drawCircle(Color(0xFF475569), radius = (notch.scale * 0.25f).coerceIn(3f, 8f), center = notch.offset)

    val labelPt = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ + 0.02f, viewW, viewH)
    paint.textSize = (labelPt.scale * 0.44f).coerceIn(9f, 16f)
    paint.color = android.graphics.Color.LTGRAY
    drawContext.canvas.nativeCanvas.drawText(comp.properties["part"] ?: "IC", labelPt.offset.x, labelPt.offset.y + 5f, paint)
}

private fun DrawScope.drawSlideSwitch3D(
    comp: PlacedComponent,
    bounds: WorldBounds,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.15f, bounds.maxCol - 0.15f,
        bounds.minRow + 0.15f, bounds.maxRow - 0.15f,
        0.14f, 0.45f,
        Color(0xFF94A3B8), Color(0xFF64748B), Color(0xFF475569), Color(0xFFCBD5E1)
    )
    val isOn = comp.properties["state"] == "ON"
    val centerRow = (bounds.minRow + bounds.maxRow) * 0.5f
    val knobMin = if (isOn) (bounds.minCol + bounds.maxCol) * 0.5f else bounds.minCol + 0.4f
    val knobMax = if (isOn) bounds.maxCol - 0.4f else (bounds.minCol + bounds.maxCol) * 0.5f
    drawExtrudedBox3D(
        camera, viewW, viewH,
        knobMin, knobMax,
        centerRow - 0.28f, centerRow + 0.28f,
        0.45f, def.heightZ,
        if (isOn) Color(0xFF10B981) else Color(0xFF0F172A),
        Color(0xFF1E293B), Color(0xFF111827), Color(0xFFE2E8F0)
    )
}

private fun DrawScope.drawPushButton3D(
    comp: PlacedComponent,
    bounds: WorldBounds,
    def: LabComponentDef,
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.2f, bounds.maxCol - 0.2f,
        bounds.minRow + 0.2f, bounds.maxRow - 0.2f,
        0.14f, 0.48f,
        Color(0xFFCBD5E1), Color(0xFF94A3B8), Color(0xFF64748B), Color(0xFFE2E8F0)
    )
    val isPressed = comp.properties["state"] == "ON"
    val capZ = if (isPressed) 0.55f else def.heightZ
    val cap = camera.projectWorldToScreen(centerCol, centerRow, capZ, viewW, viewH)
    drawCircle(
        color = if (isPressed) Color(0xFFEF4444) else Color(0xFF1E293B),
        radius = (cap.scale * 0.58f).coerceIn(10f, 24f),
        center = cap.offset
    )
}

private fun DrawScope.drawBattery9V3D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.1f, bounds.maxCol - 0.1f,
        bounds.minRow + 0.1f, bounds.maxRow - 0.1f,
        0.0f, 1.25f,
        Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF020617), Color(0xFF475569)
    )
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.12f, bounds.maxCol - 0.12f,
        bounds.minRow + 0.12f, bounds.minRow + 1.4f,
        1.25f, 1.28f,
        Color(0xFFD97706), Color(0xFFB45309), Color(0xFF92400E), Color(0xFFF59E0B)
    )
    val pt = camera.projectWorldToScreen(centerCol, centerRow + 0.5f, 1.3f, viewW, viewH)
    paint.textSize = (pt.scale * 0.65f).coerceIn(12f, 24f)
    paint.color = android.graphics.Color.rgb(245, 158, 11)
    drawContext.canvas.nativeCanvas.drawText("9V", pt.offset.x, pt.offset.y, paint)
}

private fun DrawScope.drawBatteryAA3D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.2f, bounds.maxCol - 0.2f,
        bounds.minRow + 0.2f, bounds.maxRow - 0.2f,
        0.05f, 1.0f,
        Color(0xFFB45309), Color(0xFF78350F), Color(0xFF451A03), Color(0xFFF59E0B)
    )
    val pt = camera.projectWorldToScreen(centerCol, centerRow, 1.05f, viewW, viewH)
    paint.textSize = (pt.scale * 0.48f).coerceIn(10f, 18f)
    paint.color = android.graphics.Color.WHITE
    drawContext.canvas.nativeCanvas.drawText("AA 1.5V", pt.offset.x, pt.offset.y, paint)
}

private fun DrawScope.drawBenchPsu3D(
    comp: PlacedComponent,
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol, bounds.maxCol,
        bounds.minRow, bounds.maxRow,
        0.0f, 1.65f,
        Color(0xFF334155), Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF64748B)
    )
    // Digital Display Panel
    drawQuad(
        camera, viewW, viewH,
        bounds.minCol + 0.5f, bounds.maxCol - 0.5f,
        bounds.minRow + 0.5f, centerRow + 0.3f,
        1.68f,
        Color(0xFF06202A)
    )
    val pt = camera.projectWorldToScreen(centerCol, bounds.minRow + 1.25f, 1.72f, viewW, viewH)
    paint.textSize = (pt.scale * 0.48f).coerceIn(10f, 20f)
    paint.color = android.graphics.Color.rgb(34, 211, 238)
    val v = comp.properties["voltage"] ?: "5.0"
    val a = comp.properties["currentLimit"] ?: "1.5"
    drawContext.canvas.nativeCanvas.drawText("${v}V ${a}A", pt.offset.x, pt.offset.y, paint)
}

private fun DrawScope.drawLdr3D(
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    val p = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ, viewW, viewH)
    val r = (p.scale * 0.62f).coerceIn(10f, 24f)
    drawCircle(Color(0xFFE7D3B0), radius = r, center = p.offset)
    drawLine(Color(0xFFB91C1C), Offset(p.offset.x - r * 0.5f, p.offset.y - r * 0.3f), Offset(p.offset.x + r * 0.5f, p.offset.y - r * 0.1f), 2.5f)
    drawLine(Color(0xFFB91C1C), Offset(p.offset.x + r * 0.5f, p.offset.y - r * 0.1f), Offset(p.offset.x - r * 0.5f, p.offset.y + r * 0.1f), 2.5f)
    drawLine(Color(0xFFB91C1C), Offset(p.offset.x - r * 0.5f, p.offset.y + r * 0.1f), Offset(p.offset.x + r * 0.5f, p.offset.y + r * 0.3f), 2.5f)
}

private fun DrawScope.drawHcSr043D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol, bounds.maxCol,
        bounds.minRow, bounds.maxRow,
        0.15f, 0.45f,
        Color(0xFF1D4ED8), Color(0xFF1E40AF), Color(0xFF1E3A8A), Color(0xFF60A5FA)
    )
    val leftEye = camera.projectWorldToScreen(centerCol - 1.1f, centerRow, def.heightZ, viewW, viewH)
    val rightEye = camera.projectWorldToScreen(centerCol + 1.1f, centerRow, def.heightZ, viewW, viewH)
    val r = (leftEye.scale * 0.65f).coerceIn(10f, 24f)
    drawCircle(Color(0xFFCBD5E1), radius = r, center = leftEye.offset)
    drawCircle(Color(0xFF334155), radius = r * 0.7f, center = leftEye.offset)
    drawCircle(Color(0xFFCBD5E1), radius = r, center = rightEye.offset)
    drawCircle(Color(0xFF334155), radius = r * 0.7f, center = rightEye.offset)
    paint.textSize = (r * 0.42f).coerceIn(8f, 13f)
    paint.color = android.graphics.Color.WHITE
    drawContext.canvas.nativeCanvas.drawText("HC-SR04", (leftEye.offset.x + rightEye.offset.x) * 0.5f, leftEye.offset.y + r + 10f, paint)
}

private fun DrawScope.drawMotor3D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    reading: ComponentSimulationReading?,
    simTimeSec: Double,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.3f, bounds.maxCol - 0.3f,
        bounds.minRow + 0.2f, bounds.maxRow - 0.2f,
        0.05f, def.heightZ * 0.85f,
        Color(0xFF94A3B8), Color(0xFF64748B), Color(0xFF475569), Color(0xFFCBD5E1)
    )
    val shaft = camera.projectWorldToScreen(bounds.maxCol + 0.55f, centerRow, def.heightZ * 0.55f, viewW, viewH)
    val end = camera.projectWorldToScreen(bounds.maxCol - 0.3f, centerRow, def.heightZ * 0.55f, viewW, viewH)
    drawLine(Color(0xFFF59E0B), end.offset, shaft.offset, strokeWidth = 6f, cap = StrokeCap.Round)

    val rpm = reading?.motorRpm ?: 0f
    val bladeLen = (shaft.scale * 0.42f).coerceIn(8f, 18f)
    val angle = if (rpm > 0f) simTimeSec * (rpm / 120.0) else 0.0
    val bx = kotlin.math.cos(angle).toFloat() * bladeLen
    val by = kotlin.math.sin(angle).toFloat() * bladeLen
    drawLine(
        color = if (rpm > 0f) Color(0xFF22D3EE) else Color(0xFFE2E8F0),
        start = Offset(shaft.offset.x - bx, shaft.offset.y - by),
        end = Offset(shaft.offset.x + bx, shaft.offset.y + by),
        strokeWidth = 4f,
        cap = StrokeCap.Round
    )

    val lbl = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ * 0.9f, viewW, viewH)
    paint.textSize = (lbl.scale * 0.45f).coerceIn(10f, 16f)
    paint.color = android.graphics.Color.BLACK
    val mText = if (rpm > 0f) "${rpm.roundToInt()} RPM" else "DC MOTOR"
    drawContext.canvas.nativeCanvas.drawText(mText, lbl.offset.x, lbl.offset.y, paint)
}

private fun DrawScope.drawRelay3D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    reading: ComponentSimulationReading?,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    val energized = reading?.relayEnergized == true
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.1f, bounds.maxCol - 0.1f,
        bounds.minRow + 0.1f, bounds.maxRow - 0.1f,
        0.15f, def.heightZ,
        if (energized) Color(0xFF0EA5E9) else Color(0xFF0284C7),
        Color(0xFF0369A1), Color(0xFF075985), Color(0xFF38BDF8)
    )
    val pt = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ + 0.02f, viewW, viewH)
    paint.textSize = (pt.scale * 0.4f).coerceIn(9f, 14f)
    paint.color = if (energized) android.graphics.Color.rgb(167, 243, 208) else android.graphics.Color.WHITE
    drawContext.canvas.nativeCanvas.drawText(if (energized) "RELAY: NO" else "5V RELAY", pt.offset.x, pt.offset.y, paint)
}

private fun DrawScope.drawArduinoUno3D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol, bounds.maxCol,
        bounds.minRow, bounds.maxRow,
        0.0f, 0.35f,
        Color(0xFF0F766E), Color(0xFF115E59), Color(0xFF134E4A), Color(0xFF2DD4BF)
    )
    // Silver USB-B Port on left
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol - 0.2f, bounds.minCol + 1.5f,
        bounds.minRow + 1.0f, bounds.minRow + 2.6f,
        0.35f, def.heightZ,
        Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFF64748B), Color(0xFFFFFFFF)
    )
    // ATmega328 DIP Chip
    drawExtrudedBox3D(
        camera, viewW, viewH,
        centerCol - 1.5f, centerCol + 2.2f,
        centerRow + 0.2f, centerRow + 1.2f,
        0.35f, 0.62f,
        Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF020617), Color(0xFF475569)
    )
    val lbl = camera.projectWorldToScreen(centerCol, bounds.minRow + 1.3f, 0.4f, viewW, viewH)
    paint.textSize = (lbl.scale * 0.48f).coerceIn(10f, 18f)
    paint.color = android.graphics.Color.WHITE
    drawContext.canvas.nativeCanvas.drawText("ARDUINO UNO", lbl.offset.x, lbl.offset.y, paint)
}

private fun DrawScope.drawEsp323D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol, bounds.maxCol,
        bounds.minRow, bounds.maxRow,
        0.0f, 0.32f,
        Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF020617), Color(0xFF64748B)
    )
    // RF Metal Shield
    drawExtrudedBox3D(
        camera, viewW, viewH,
        centerCol - 0.4f, bounds.maxCol - 0.7f,
        bounds.minRow + 0.45f, bounds.maxRow - 0.45f,
        0.32f, def.heightZ,
        Color(0xFFCBD5E1), Color(0xFF94A3B8), Color(0xFF64748B), Color(0xFFFFFFFF)
    )
    val lbl = camera.projectWorldToScreen(centerCol + 1.0f, centerRow, def.heightZ + 0.02f, viewW, viewH)
    paint.textSize = (lbl.scale * 0.4f).coerceIn(8f, 14f)
    paint.color = android.graphics.Color.BLACK
    drawContext.canvas.nativeCanvas.drawText("ESP32", lbl.offset.x, lbl.offset.y, paint)
}

private fun DrawScope.drawSevenSeg3D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.1f, bounds.maxCol - 0.1f,
        bounds.minRow + 0.2f, bounds.maxRow - 0.2f,
        0.15f, def.heightZ,
        Color(0xFF334155), Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF64748B)
    )
    // Unlit figure-8 LED segments
    val segColor = Color(0xFF475569)
    val cL = centerCol - 0.65f
    val cR = centerCol + 0.65f
    val rT = centerRow - 0.65f
    val rM = centerRow
    val rB = centerRow + 0.65f
    val z = def.heightZ + 0.02f
    drawBoardLine(camera, viewW, viewH, cL, rT, cR, rT, segColor, 4f, z)
    drawBoardLine(camera, viewW, viewH, cL, rM, cR, rM, segColor, 4f, z)
    drawBoardLine(camera, viewW, viewH, cL, rB, cR, rB, segColor, 4f, z)
    drawBoardLine(camera, viewW, viewH, cL, rT, cL, rB, segColor, 4f, z)
    drawBoardLine(camera, viewW, viewH, cR, rT, cR, rB, segColor, 4f, z)
}

private fun DrawScope.drawLcd16x23D(
    bounds: WorldBounds,
    centerCol: Float,
    centerRow: Float,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol, bounds.maxCol,
        bounds.minRow, bounds.maxRow,
        0.0f, 0.35f,
        Color(0xFF15803D), Color(0xFF166534), Color(0xFF14532D), Color(0xFF4ADE80)
    )
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.7f, bounds.maxCol - 0.7f,
        bounds.minRow + 0.55f, bounds.maxRow - 0.55f,
        0.35f, def.heightZ,
        Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF020617), Color(0xFF64748B)
    )
    drawQuad(
        camera, viewW, viewH,
        bounds.minCol + 1.0f, bounds.maxCol - 1.0f,
        bounds.minRow + 0.8f, bounds.maxRow - 0.8f,
        def.heightZ + 0.02f,
        Color(0xFFA3E635).copy(alpha = 0.75f)
    )
    val lbl = camera.projectWorldToScreen(centerCol, centerRow, def.heightZ + 0.03f, viewW, viewH)
    paint.textSize = (lbl.scale * 0.45f).coerceIn(10f, 17f)
    paint.color = android.graphics.Color.rgb(20, 83, 45)
    drawContext.canvas.nativeCanvas.drawText("16x2 LCD", lbl.offset.x, lbl.offset.y, paint)
}

private fun DrawScope.drawScrewTerminal3D(
    bounds: WorldBounds,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    drawExtrudedBox3D(
        camera, viewW, viewH,
        bounds.minCol + 0.1f, bounds.maxCol - 0.1f,
        bounds.minRow + 0.1f, bounds.maxRow - 0.1f,
        0.14f, def.heightZ,
        Color(0xFF16A34A), Color(0xFF15803D), Color(0xFF166534), Color(0xFF4ADE80)
    )
}

private fun DrawScope.drawJumperBridge3D(
    comp: PlacedComponent,
    def: LabComponentDef,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float
) {
    val (x1, y1) = NetlistExtractor.resolvePinWorldGrid(comp, def.pins[0])
    val (x2, y2) = NetlistExtractor.resolvePinWorldGrid(comp, def.pins[1])
    val p1 = camera.projectWorldToScreen(x1, y1, 0.25f, viewW, viewH).offset
    val p2 = camera.projectWorldToScreen(x2, y2, 0.25f, viewW, viewH).offset
    drawLine(Color(0xFF10B981), p1, p2, strokeWidth = 6f, cap = StrokeCap.Round)
}

private fun DrawScope.drawGroundTerminal3D(
    centerCol: Float,
    centerRow: Float,
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    paint: Paint
) {
    val pt = camera.projectWorldToScreen(centerCol, centerRow, 0.55f, viewW, viewH)
    val r = (pt.scale * 0.48f).coerceIn(10f, 20f)
    drawCircle(Color(0xFF1E293B), radius = r, center = pt.offset)
    drawCircle(Color(0xFF94A3B8), radius = r, center = pt.offset, style = Stroke(2f))
    paint.textSize = (r * 0.85f).coerceIn(10f, 16f)
    paint.color = android.graphics.Color.WHITE
    drawContext.canvas.nativeCanvas.drawText("GND", pt.offset.x, pt.offset.y + 4f, paint)
}

private fun DrawScope.drawWire3D(
    wire: LabWire,
    components: List<PlacedComponent>,
    isSelected: Boolean,
    wireReading: WireSimulationReading?,
    flowAnimPhase: Float,
    viewW: Float,
    viewH: Float,
    camera: LabCamera3D
) {
    val (c1, r1) = LabGeometryHelper.resolveEndpointWorld(wire.start, components)
    val (c2, r2) = LabGeometryHelper.resolveEndpointWorld(wire.end, components)
    val worldPts = LabGeometryHelper.sampleWirePoints(c1, r1, c2, r2, wire)
    if (worldPts.size < 2) return

    val wireColor = Color(
        LabWireColor.entries.firstOrNull { it.key == wire.colorKey }?.argb ?: LabWireColor.GREEN.argb
    )

    // Shadow on board
    if (camera.renderMode == LabRenderMode.PERSPECTIVE_3D) {
        val shadowPath = Path().apply {
            val s0 = camera.projectWorldToScreen(worldPts.first().first, worldPts.first().second, 0.01f, viewW, viewH).offset
            moveTo(s0.x, s0.y)
            for (i in 1 until worldPts.size) {
                val sp = camera.projectWorldToScreen(worldPts[i].first, worldPts[i].second, 0.01f, viewW, viewH).offset
                lineTo(sp.x, sp.y)
            }
        }
        drawPath(
            path = shadowPath,
            color = Color.Black.copy(alpha = 0.24f),
            style = Stroke(width = 6.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }

    val screenPts = worldPts.map {
        camera.projectWorldToScreen(it.first, it.second, it.third, viewW, viewH).offset
    }
    val wirePath = Path().apply {
        moveTo(screenPts.first().x, screenPts.first().y)
        for (i in 1 until screenPts.size) {
            lineTo(screenPts[i].x, screenPts[i].y)
        }
    }

    if (isSelected) {
        drawPath(
            path = wirePath,
            color = Color(0xFF22D3EE).copy(alpha = 0.55f),
            style = Stroke(width = 13f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }

    drawPath(
        path = wirePath,
        color = wireColor,
        style = Stroke(width = 6.2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
    drawPath(
        path = wirePath,
        color = Color.White.copy(alpha = 0.26f),
        style = Stroke(width = 2.0f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Real current flow visualization beads along energized conducting wires
    if (wireReading != null && abs(wireReading.currentMa) > 0.05 && screenPts.size >= 2) {
        val segCount = screenPts.size - 1
        for (bead in 0 until 3) {
            val baseT = (bead / 3f + if (wireReading.directionForward) flowAnimPhase else (1f - flowAnimPhase)) % 1f
            val fIdx = (baseT * segCount).coerceIn(0f, segCount - 0.001f)
            val idx0 = fIdx.toInt()
            val frac = fIdx - idx0
            val pA = screenPts[idx0]
            val pB = screenPts[(idx0 + 1).coerceAtMost(segCount)]
            val pos = Offset(pA.x + (pB.x - pA.x) * frac, pA.y + (pB.y - pA.y) * frac)
            drawCircle(Color(0xFF22D3EE), radius = 4.6f, center = pos)
            drawCircle(Color.White, radius = 2.0f, center = pos)
        }
    }

    // Stripped metallic tips at both ends
    drawCircle(Color(0xFFCBD5E1), radius = 4.2f, center = screenPts.first())
    drawCircle(Color(0xFFCBD5E1), radius = 4.2f, center = screenPts.last())
}

private fun DrawScope.drawExtrudedBox3D(
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    minCol: Float,
    maxCol: Float,
    minRow: Float,
    maxRow: Float,
    zBottom: Float,
    zTop: Float,
    topColor: Color,
    frontColor: Color,
    sideColor: Color,
    borderColor: Color
) {
    if (camera.renderMode == LabRenderMode.PERSPECTIVE_3D && zTop > zBottom) {
        val bFL = camera.projectWorldToScreen(minCol, maxRow, zBottom, viewW, viewH).offset
        val bFR = camera.projectWorldToScreen(maxCol, maxRow, zBottom, viewW, viewH).offset
        val bBR = camera.projectWorldToScreen(maxCol, minRow, zBottom, viewW, viewH).offset
        val bBL = camera.projectWorldToScreen(minCol, minRow, zBottom, viewW, viewH).offset

        val tFL = camera.projectWorldToScreen(minCol, maxRow, zTop, viewW, viewH).offset
        val tFR = camera.projectWorldToScreen(maxCol, maxRow, zTop, viewW, viewH).offset
        val tBR = camera.projectWorldToScreen(maxCol, minRow, zTop, viewW, viewH).offset
        val tBL = camera.projectWorldToScreen(minCol, minRow, zTop, viewW, viewH).offset

        // Front face (maxRow)
        drawPolygon(listOf(bFL, bFR, tFR, tFL), frontColor, borderColor)

        // Left or Right face depending on yaw
        if (camera.yawDeg >= 0f) {
            drawPolygon(listOf(bBL, bFL, tFL, tBL), sideColor, borderColor)
        } else {
            drawPolygon(listOf(bFR, bBR, tBR, tFR), sideColor, borderColor)
        }
    }

    // Top face
    drawQuad(camera, viewW, viewH, minCol, maxCol, minRow, maxRow, zTop, topColor)
    drawQuadOutline(camera, viewW, viewH, minCol, maxCol, minRow, maxRow, zTop, borderColor, 1.4f)
}

private fun DrawScope.drawQuad(
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    minCol: Float,
    maxCol: Float,
    minRow: Float,
    maxRow: Float,
    z: Float,
    color: Color
) {
    val pts = listOf(
        camera.projectWorldToScreen(minCol, minRow, z, viewW, viewH).offset,
        camera.projectWorldToScreen(maxCol, minRow, z, viewW, viewH).offset,
        camera.projectWorldToScreen(maxCol, maxRow, z, viewW, viewH).offset,
        camera.projectWorldToScreen(minCol, maxRow, z, viewW, viewH).offset
    )
    val path = Path().apply {
        moveTo(pts[0].x, pts[0].y)
        lineTo(pts[1].x, pts[1].y)
        lineTo(pts[2].x, pts[2].y)
        lineTo(pts[3].x, pts[3].y)
        close()
    }
    drawPath(path, color)
}

private fun DrawScope.drawQuadOutline(
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    minCol: Float,
    maxCol: Float,
    minRow: Float,
    maxRow: Float,
    z: Float,
    color: Color,
    strokeWidth: Float
) {
    val pts = listOf(
        camera.projectWorldToScreen(minCol, minRow, z, viewW, viewH).offset,
        camera.projectWorldToScreen(maxCol, minRow, z, viewW, viewH).offset,
        camera.projectWorldToScreen(maxCol, maxRow, z, viewW, viewH).offset,
        camera.projectWorldToScreen(minCol, maxRow, z, viewW, viewH).offset
    )
    val path = Path().apply {
        moveTo(pts[0].x, pts[0].y)
        lineTo(pts[1].x, pts[1].y)
        lineTo(pts[2].x, pts[2].y)
        lineTo(pts[3].x, pts[3].y)
        close()
    }
    drawPath(path, color, style = Stroke(width = strokeWidth))
}

private fun DrawScope.drawPolygon(pts: List<Offset>, fill: Color, border: Color) {
    val path = Path().apply {
        moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
        close()
    }
    drawPath(path, fill)
    drawPath(path, border, style = Stroke(width = 1.2f))
}

private fun DrawScope.drawBoardLine(
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    c1: Float,
    r1: Float,
    c2: Float,
    r2: Float,
    color: Color,
    strokeWidth: Float,
    z: Float = 0.008f
) {
    val p1 = camera.projectWorldToScreen(c1, r1, z, viewW, viewH).offset
    val p2 = camera.projectWorldToScreen(c2, r2, z, viewW, viewH).offset
    drawLine(color, p1, p2, strokeWidth = strokeWidth, cap = StrokeCap.Round)
}

private fun DrawScope.drawWorldText(
    camera: LabCamera3D,
    viewW: Float,
    viewH: Float,
    col: Float,
    row: Float,
    z: Float,
    text: String,
    paint: Paint
) {
    val p = camera.projectWorldToScreen(col, row, z, viewW, viewH).offset
    drawContext.canvas.nativeCanvas.drawText(text, p.x, p.y + paint.textSize * 0.35f, paint)
}
