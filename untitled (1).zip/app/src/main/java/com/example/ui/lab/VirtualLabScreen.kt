package com.example.ui.lab

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.RotateRight
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.core.localization.AppLanguage
import com.example.core.localization.LabStrings
import com.example.domain.model.LabRenderMode
import com.example.domain.model.LabTool
import com.example.simulation.SimulationStatus
import kotlin.math.abs

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun VirtualLabScreen(
    uiState: LabUiState,
    isDarkTheme: Boolean,
    viewModel: LabWorkspaceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val lang = uiState.language

    // Respect user landscape toggle safely and restore orientation on leaving Lab
    DisposableEffect(activity, uiState.isLandscapeLocked) {
        if (activity != null) {
            activity.requestedOrientation = if (uiState.isLandscapeLocked) {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
        onDispose {
            if (activity != null && uiState.isLandscapeLocked) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    BackHandler(enabled = uiState.activeDrawer != LabDrawerPanel.NONE || uiState.isFullScreen) {
        when {
            uiState.activeDrawer != LabDrawerPanel.NONE -> viewModel.closeDrawer()
            uiState.isFullScreen -> viewModel.toggleFullScreen()
        }
    }

    var canvasSize by remember { mutableStateOf(IntSize(1080, 720)) }
    var rubberBandEnd by remember { mutableStateOf<Offset?>(null) }
    var snapHighlight by remember { mutableStateOf<HitTargetPin?>(null) }

    val latestState by rememberUpdatedState(uiState)
    val touchSlop = LocalViewConfiguration.current.touchSlop

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("virtual_lab_screen")
    ) {
        // 1. Primary 14+ Control Laboratory Toolbar
        LabToolbarRow(
            uiState = uiState,
            viewModel = viewModel
        )

        // 2. Simulation Controls & Netlist Staging Status Strip
        if (!uiState.isFullScreen) {
            LabSimulationStatusBar(
                uiState = uiState,
                viewModel = viewModel
            )
        }

        // 3. Interactive 3D Canvas + Floating Overlay Panels
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            val isWide = maxWidth >= 680.dp

            Lab3DCanvas(
                snapshot = uiState.snapshot,
                camera = uiState.camera,
                selectedComponentIds = uiState.selectedComponentIds,
                selectedWireId = uiState.selectedWireId,
                wiringStart = uiState.wiringStart,
                rubberBandEnd = rubberBandEnd,
                snapHighlight = snapHighlight,
                showPinLabels = uiState.activeTool == LabTool.WIRE,
                isDarkTheme = isDarkTheme,
                simulationResult = uiState.simulationResult,
                isSimActive = uiState.simulationStatus != SimulationStatus.STOPPED,
                flowAnimPhase = uiState.flowAnimPhase,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("lab_3d_canvas")
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val firstDown = awaitFirstDown(requireUnconsumed = false)
                            var prevPos = firstDown.position
                            var draggingComponent = false
                            var movedTotal = 0f
                            var pinchOrPan = false

                            val startState = latestState
                            val viewW = canvasSize.width.toFloat().coerceAtLeast(1f)
                            val viewH = canvasSize.height.toFloat().coerceAtLeast(1f)

                            if (startState.activeTool == LabTool.MOVE) {
                                val hitComp = LabGeometryHelper.findHitComponent(
                                    firstDown.position.x,
                                    firstDown.position.y,
                                    viewW,
                                    viewH,
                                    startState.camera,
                                    startState.snapshot.components
                                )
                                if (hitComp != null) {
                                    if (hitComp.instanceId !in startState.selectedComponentIds) {
                                        viewModel.selectComponent(hitComp.instanceId)
                                    }
                                    draggingComponent = true
                                    viewModel.beginComponentMove()
                                }
                            } else if (startState.activeTool == LabTool.WIRE && startState.wiringStart != null) {
                                rubberBandEnd = firstDown.position
                            }

                            while (true) {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.isEmpty()) break

                                if (pressed.size >= 2) {
                                    pinchOrPan = true
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    if (zoom != 1f || pan != Offset.Zero) {
                                        viewModel.panAndZoomCamera(pan.x, pan.y, zoom)
                                    }
                                    event.changes.forEach { it.consume() }
                                    continue
                                }

                                val current = pressed.first()
                                val delta = current.position - prevPos
                                movedTotal += delta.getDistance()
                                prevPos = current.position

                                if (movedTotal > touchSlop && !pinchOrPan) {
                                    val st = latestState
                                    when {
                                        draggingComponent -> {
                                            val w0 = st.camera.screenToWorldGround(current.position.x - delta.x, current.position.y - delta.y, viewW, viewH)
                                            val w1 = st.camera.screenToWorldGround(current.position.x, current.position.y, viewW, viewH)
                                            viewModel.moveSelectedComponentsDelta(w1.first - w0.first, w1.second - w0.second)
                                        }
                                        st.activeTool == LabTool.WIRE -> {
                                            rubberBandEnd = current.position
                                            snapHighlight = LabGeometryHelper.findNearestPinOrHole(
                                                current.position.x,
                                                current.position.y,
                                                viewW,
                                                viewH,
                                                st.camera,
                                                st.snapshot.components
                                            )
                                        }
                                        else -> {
                                            if (st.camera.renderMode == LabRenderMode.PERSPECTIVE_3D) {
                                                viewModel.orbitCamera(delta.x * 0.24f, -delta.y * 0.22f)
                                            } else {
                                                viewModel.panAndZoomCamera(delta.x, delta.y, 1f)
                                            }
                                        }
                                    }
                                    current.consume()
                                }
                            }

                            val endState = latestState
                            if (draggingComponent) {
                                viewModel.finishComponentMove()
                            } else if (!pinchOrPan && movedTotal <= touchSlop) {
                                // Pure tap action
                                val pos = prevPos
                                when (endState.activeTool) {
                                    LabTool.WIRE -> {
                                        val hit = LabGeometryHelper.findNearestPinOrHole(
                                            pos.x, pos.y, viewW, viewH, endState.camera, endState.snapshot.components
                                        )
                                        if (hit != null) {
                                            viewModel.beginOrCompleteWire(hit.endpoint)
                                            snapHighlight = hit
                                        } else {
                                            viewModel.cancelActiveWire()
                                            snapHighlight = null
                                        }
                                    }
                                    LabTool.DELETE -> {
                                        val hitComp = LabGeometryHelper.findHitComponent(
                                            pos.x, pos.y, viewW, viewH, endState.camera, endState.snapshot.components
                                        )
                                        if (hitComp != null) {
                                            viewModel.deleteSelectedOrTarget(targetCompId = hitComp.instanceId)
                                        } else {
                                            val hitWire = LabGeometryHelper.findHitWire(
                                                pos.x, pos.y, viewW, viewH, endState.camera, endState.snapshot
                                            )
                                            if (hitWire != null) {
                                                viewModel.deleteSelectedOrTarget(targetWireId = hitWire.id)
                                            }
                                        }
                                    }
                                    LabTool.SELECT, LabTool.MOVE -> {
                                        val hitComp = LabGeometryHelper.findHitComponent(
                                            pos.x, pos.y, viewW, viewH, endState.camera, endState.snapshot.components
                                        )
                                        if (hitComp != null) {
                                            viewModel.selectComponent(hitComp.instanceId)
                                        } else {
                                            val hitWire = LabGeometryHelper.findHitWire(
                                                pos.x, pos.y, viewW, viewH, endState.camera, endState.snapshot
                                            )
                                            if (hitWire != null) {
                                                viewModel.selectWire(hitWire.id)
                                            } else {
                                                viewModel.selectComponent(null)
                                            }
                                        }
                                    }
                                }
                            } else if (!pinchOrPan && endState.activeTool == LabTool.WIRE && endState.wiringStart != null) {
                                val target = snapHighlight ?: LabGeometryHelper.findNearestPinOrHole(
                                    prevPos.x, prevPos.y, viewW, viewH, endState.camera, endState.snapshot.components
                                )
                                if (target != null) {
                                    viewModel.beginOrCompleteWire(target.endpoint)
                                }
                            }
                            rubberBandEnd = null
                        }
                    }
            )

            // Subtle HUD Status Badge (Project name + Mode + Feedback)
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp),
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = uiState.snapshot.projectName,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (uiState.camera.renderMode == LabRenderMode.PERSPECTIVE_3D) "3D" else "2D",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (uiState.wiringStart != null) {
                        Text(
                            text = if (lang == AppLanguage.BANGLA) "টার্গেট পিন নির্বাচন করুন" else "Tap destination pin",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            uiState.feedbackBanner?.let { msg ->
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    onClick = viewModel::clearFeedback
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Floating Drawers (Library / Properties / Measurement Instruments)
            if (uiState.activeDrawer != LabDrawerPanel.NONE) {
                val drawerModifier = Modifier
                    .align(if (isWide) Alignment.BottomEnd else Alignment.BottomCenter)
                    .padding(10.dp)
                    .then(if (isWide) Modifier.widthIn(max = 420.dp) else Modifier.fillMaxWidth())

                when (uiState.activeDrawer) {
                    LabDrawerPanel.LIBRARY -> LabComponentLibraryPanel(
                        searchQuery = uiState.searchQuery,
                        selectedCategory = uiState.selectedCategory,
                        language = lang,
                        onSearchChange = viewModel::updateSearchQuery,
                        onSelectCategory = viewModel::selectCategory,
                        onPlaceComponent = { typeId -> viewModel.placeComponentFromLibrary(typeId) },
                        onClose = viewModel::closeDrawer,
                        modifier = drawerModifier
                    )
                    LabDrawerPanel.PROPERTIES -> {
                        val selComps = uiState.snapshot.components.filter { it.instanceId in uiState.selectedComponentIds }
                        val selWire = uiState.snapshot.wires.firstOrNull { it.id == uiState.selectedWireId }
                        LabPropertyInspectorPanel(
                            selectedComponents = selComps,
                            selectedWire = selWire,
                            activeWireColor = uiState.activeWireColor,
                            activeWireStyle = uiState.activeWireStyle,
                            language = lang,
                            simulationResult = uiState.simulationResult,
                            simulationStatus = uiState.simulationStatus,
                            onUpdateComponentProps = viewModel::updateComponentProperties,
                            onRotateSelected = viewModel::rotateSelected,
                            onDuplicateSelected = viewModel::duplicateSelected,
                            onDeleteSelected = { viewModel.deleteSelectedOrTarget() },
                            onSelectWireColor = viewModel::setActiveWireColor,
                            onSelectWireStyle = viewModel::setActiveWireStyle,
                            onUpdateWireBend = viewModel::updateWireBend,
                            onClose = viewModel::closeDrawer,
                            modifier = drawerModifier
                        )
                    }
                    LabDrawerPanel.INSTRUMENTS -> {
                        LabInstrumentsPanel(
                            snapshot = uiState.snapshot,
                            simulationResult = uiState.simulationResult,
                            simulationStatus = uiState.simulationStatus,
                            oscilloscopeSamples = uiState.oscilloscopeSamples,
                            language = lang,
                            onUpdateInstrument = viewModel::updateInstrument,
                            onClose = viewModel::closeDrawer,
                            modifier = drawerModifier
                        )
                    }
                    LabDrawerPanel.NONE -> Unit
                }
            }
        }
    }

    if (uiState.showSaveDialog) {
        LabSaveProjectDialog(
            initialName = uiState.snapshot.projectName,
            language = lang,
            onDismiss = { viewModel.setShowSaveDialog(false) },
            onConfirmSave = viewModel::saveCurrentProject
        )
    }

    if (uiState.showLoadDialog) {
        LabLoadProjectDialog(
            savedProjects = uiState.savedProjects,
            language = lang,
            onLoadProject = viewModel::loadSavedProject,
            onDeleteProject = viewModel::deleteSavedProject,
            onLoadStarter = viewModel::loadStarterTemplate,
            onCreateBlank = viewModel::clearAllAndCreateBlank,
            onDismiss = { viewModel.setShowLoadDialog(false) }
        )
    }

    if (uiState.showReportDialog) {
        LabSimulationReportDialog(
            simulationStatus = uiState.simulationStatus,
            simulationResult = uiState.simulationResult,
            language = lang,
            onDismiss = { viewModel.setShowReportDialog(false) }
        )
    }
}

@Composable
private fun LabToolbarRow(
    uiState: LabUiState,
    viewModel: LabWorkspaceViewModel
) {
    val lang = uiState.language
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .testTag("lab_toolbar_row"),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Select
            LabToolButton(
                icon = Icons.Rounded.TouchApp,
                label = LabStrings.toolSelect(lang),
                selected = uiState.activeTool == LabTool.SELECT,
                onClick = { viewModel.selectTool(LabTool.SELECT) },
                tag = "tool_select"
            )
            // 2. Move
            LabToolButton(
                icon = Icons.Rounded.OpenWith,
                label = LabStrings.toolMove(lang),
                selected = uiState.activeTool == LabTool.MOVE,
                onClick = { viewModel.selectTool(LabTool.MOVE) },
                tag = "tool_move"
            )
            // 3. Wire
            LabToolButton(
                icon = Icons.Rounded.Timeline,
                label = LabStrings.toolWire(lang),
                selected = uiState.activeTool == LabTool.WIRE,
                onClick = { viewModel.selectTool(LabTool.WIRE) },
                tag = "tool_wire"
            )
            // 4. Delete Tool / Delete Selected
            LabToolButton(
                icon = Icons.Rounded.Delete,
                label = LabStrings.toolDelete(lang),
                selected = uiState.activeTool == LabTool.DELETE,
                onClick = {
                    if (uiState.selectedComponentIds.isNotEmpty() || uiState.selectedWireId != null) {
                        viewModel.deleteSelectedOrTarget()
                    } else {
                        viewModel.selectTool(LabTool.DELETE)
                    }
                },
                tag = "tool_delete"
            )
            // 5. Rotate
            LabToolButton(
                icon = Icons.AutoMirrored.Rounded.RotateRight,
                label = LabStrings.rotate(lang),
                selected = false,
                enabled = uiState.selectedComponentIds.isNotEmpty(),
                onClick = viewModel::rotateSelected,
                tag = "lab_rotate"
            )
            // Duplicate & Multi-Select
            LabToolButton(
                icon = Icons.Rounded.ContentCopy,
                label = LabStrings.duplicate(lang),
                selected = false,
                enabled = uiState.selectedComponentIds.isNotEmpty(),
                onClick = viewModel::duplicateSelected,
                tag = "lab_duplicate"
            )
            LabToolButton(
                icon = if (uiState.multiSelectEnabled) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
                label = LabStrings.multiSelect(lang),
                selected = uiState.multiSelectEnabled,
                onClick = viewModel::toggleMultiSelect,
                tag = "lab_multi_select"
            )
            // 6. Undo
            LabToolButton(
                icon = Icons.AutoMirrored.Rounded.Undo,
                label = LabStrings.undo(lang),
                selected = false,
                enabled = uiState.canUndo,
                onClick = viewModel::undo,
                tag = "lab_undo"
            )
            // 7. Redo
            LabToolButton(
                icon = Icons.AutoMirrored.Rounded.Redo,
                label = LabStrings.redo(lang),
                selected = false,
                enabled = uiState.canRedo,
                onClick = viewModel::redo,
                tag = "lab_redo"
            )
            // 8. Zoom In
            LabToolButton(
                icon = Icons.Rounded.ZoomIn,
                label = LabStrings.zoomIn(lang),
                selected = false,
                onClick = viewModel::zoomIn,
                tag = "lab_zoom_in"
            )
            // 9. Zoom Out
            LabToolButton(
                icon = Icons.Rounded.ZoomOut,
                label = LabStrings.zoomOut(lang),
                selected = false,
                onClick = viewModel::zoomOut,
                tag = "lab_zoom_out"
            )
            // 10. Reset Camera
            LabToolButton(
                icon = Icons.Rounded.CenterFocusStrong,
                label = LabStrings.resetCamera(lang),
                selected = false,
                onClick = viewModel::resetCamera,
                tag = "lab_reset_cam"
            )
            // 3D / 2D Perspective Toggle
            LabToolButton(
                icon = Icons.Rounded.ViewInAr,
                label = if (uiState.camera.renderMode == LabRenderMode.PERSPECTIVE_3D) "3D/2D" else "2D/3D",
                selected = uiState.camera.renderMode == LabRenderMode.LIGHTWEIGHT_2D,
                onClick = viewModel::toggle3D2DMode,
                tag = "lab_mode_3d_2d"
            )
            // 11. Component Library
            LabToolButton(
                icon = Icons.Rounded.AddCircle,
                label = LabStrings.library(lang),
                selected = uiState.activeDrawer == LabDrawerPanel.LIBRARY,
                onClick = { viewModel.openDrawer(LabDrawerPanel.LIBRARY) },
                tag = "lab_parts_button"
            )
            // 12. Properties Inspector
            LabToolButton(
                icon = Icons.Rounded.Tune,
                label = LabStrings.properties(lang),
                selected = uiState.activeDrawer == LabDrawerPanel.PROPERTIES,
                onClick = { viewModel.openDrawer(LabDrawerPanel.PROPERTIES) },
                tag = "lab_properties_button"
            )
            // Instruments
            LabToolButton(
                icon = Icons.Rounded.Speed,
                label = LabStrings.instruments(lang),
                selected = uiState.activeDrawer == LabDrawerPanel.INSTRUMENTS,
                onClick = { viewModel.openDrawer(LabDrawerPanel.INSTRUMENTS) },
                tag = "lab_meters_button"
            )
            // 13. Save Project
            LabToolButton(
                icon = Icons.Rounded.Save,
                label = LabStrings.saveProject(lang),
                selected = false,
                onClick = { viewModel.setShowSaveDialog(true) },
                tag = "lab_save_button"
            )
            // 14. Load Project
            LabToolButton(
                icon = Icons.Rounded.FolderOpen,
                label = LabStrings.loadProject(lang),
                selected = false,
                onClick = { viewModel.setShowLoadDialog(true) },
                tag = "lab_load_button"
            )
            // Full-Screen & Landscape Orientation
            LabToolButton(
                icon = Icons.Rounded.ScreenRotation,
                label = "Land",
                selected = uiState.isLandscapeLocked,
                onClick = viewModel::toggleLandscapeLock,
                tag = "lab_orientation_toggle"
            )
            LabToolButton(
                icon = if (uiState.isFullScreen) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                label = if (uiState.isFullScreen) "Exit" else "Full",
                selected = uiState.isFullScreen,
                onClick = viewModel::toggleFullScreen,
                tag = "lab_fullscreen_toggle"
            )
        }
    }
}

@Composable
private fun LabToolButton(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit,
    tag: String
) {
    val containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val contentColor = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(10.dp),
        color = if (enabled) containerColor else containerColor.copy(alpha = 0.45f),
        border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = Modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .testTag(tag)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (enabled) contentColor else contentColor.copy(alpha = 0.4f),
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (enabled) contentColor else contentColor.copy(alpha = 0.4f),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun LabSimulationStatusBar(
    uiState: LabUiState,
    viewModel: LabWorkspaceViewModel
) {
    val lang = uiState.language
    val net = uiState.netlistSummary
    val res = uiState.simulationResult
    val isRunning = uiState.simulationStatus == SimulationStatus.RUNNING
    val isPaused = uiState.simulationStatus == SimulationStatus.PAUSED
    val isActive = uiState.simulationStatus != SimulationStatus.STOPPED
    val alertWarnings = if (isActive) {
        res.warnings.filter { it.severity != com.example.simulation.SafetySeverity.INFO }
    } else {
        emptyList()
    }
    val hasCritical = net.railShortDetected || alertWarnings.any { it.severity == com.example.simulation.SafetySeverity.CRITICAL }

    Column(modifier = Modifier.fillMaxWidth()) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Run / Resume
                FilledTonalIconButton(
                    onClick = viewModel::runOrResumeSimulation,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = if (isRunning) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("sim_run_button")
                ) {
                    Icon(
                        Icons.Rounded.PlayArrow,
                        contentDescription = if (isPaused) LabStrings.simResume(lang) else LabStrings.simRun(lang),
                        tint = if (isRunning) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                // Pause
                IconButton(
                    onClick = viewModel::pauseSimulation,
                    enabled = isRunning,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("sim_pause_button")
                ) {
                    Icon(Icons.Rounded.Pause, contentDescription = LabStrings.simPause(lang))
                }

                // Stop
                IconButton(
                    onClick = viewModel::stopSimulation,
                    enabled = isActive,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("sim_stop_button")
                ) {
                    Icon(Icons.Rounded.Stop, contentDescription = LabStrings.simStop(lang))
                }

                // Reset
                IconButton(
                    onClick = viewModel::resetSimulation,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("sim_reset_button")
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = LabStrings.simReset(lang))
                }

                // Simulation Speed Multiplier
                Surface(
                    onClick = viewModel::cycleSimSpeed,
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                        .testTag("sim_speed_button")
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 8.dp)) {
                        val spLabel = if (uiState.simSpeedMultiplier % 1f == 0f) {
                            "${uiState.simSpeedMultiplier.toInt()}×"
                        } else {
                            "${uiState.simSpeedMultiplier}×"
                        }
                        Text(
                            text = spLabel,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Time-Step Selector (dt)
                Surface(
                    onClick = viewModel::cycleSimTimeStep,
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                        .testTag("sim_dt_button")
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 8.dp)) {
                        Text(
                            text = "${uiState.simTimeStepMs}ms",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Simulation Report & Component Support Matrix Button
                Surface(
                    onClick = { viewModel.setShowReportDialog(true) },
                    shape = RoundedCornerShape(8.dp),
                    color = if (alertWarnings.isNotEmpty()) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier
                        .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                        .testTag("sim_report_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = LabStrings.simReport(lang) + if (alertWarnings.isNotEmpty()) " (${alertWarnings.size})" else "",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (alertWarnings.isNotEmpty()) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                // Live MNA Solver Status Chip
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (hasCritical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (hasCritical) Icons.Rounded.Warning else Icons.Rounded.ElectricBolt,
                            contentDescription = null,
                            tint = if (hasCritical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        val simStatusLabel = when (uiState.simulationStatus) {
                            SimulationStatus.STOPPED -> LabStrings.simStopped(lang)
                            SimulationStatus.RUNNING -> "${LabStrings.simRunning(lang)} • t=${"%.2f".format(res.simTimeSec)}s"
                            SimulationStatus.PAUSED -> "${LabStrings.simPaused(lang)} • t=${"%.2f".format(res.simTimeSec)}s"
                        }
                        Text(
                            text = "$simStatusLabel • ${net.componentCount} parts • ${net.wireCount} wires • ${net.activeNodeCount} nets" +
                                if (net.railShortDetected) " • RAIL SHORT!" else "",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (hasCritical) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("sim_status_text")
                        )
                    }
                }
            }
        }

        if (alertWarnings.isNotEmpty()) {
            val topWarning = alertWarnings.first()
            Surface(
                onClick = { viewModel.setShowReportDialog(true) },
                color = if (topWarning.severity == com.example.simulation.SafetySeverity.CRITICAL) {
                    MaterialTheme.colorScheme.errorContainer
                } else {
                    MaterialTheme.colorScheme.tertiaryContainer
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sim_warning_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = "Circuit warning",
                        tint = if (topWarning.severity == com.example.simulation.SafetySeverity.CRITICAL) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.onTertiaryContainer
                        },
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = topWarning.messageEn,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = if (topWarning.severity == com.example.simulation.SafetySeverity.CRITICAL) {
                            MaterialTheme.colorScheme.onErrorContainer
                        } else {
                            MaterialTheme.colorScheme.onTertiaryContainer
                        }
                    )
                }
            }
        }
    }
}
