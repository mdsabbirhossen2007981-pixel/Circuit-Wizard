package com.example.ui.lab

import androidx.compose.ui.geometry.Offset
import com.example.domain.model.LabRenderMode
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

data class LabCamera3D(
    val yawDeg: Float = DEFAULT_YAW_3D,
    val pitchDeg: Float = DEFAULT_PITCH_3D,
    val zoom: Float = 1.0f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val renderMode: LabRenderMode = LabRenderMode.PERSPECTIVE_3D
) {
    companion object {
        const val CENTER_COL = 14.5f
        const val CENTER_ROW = 5.5f
        const val CAMERA_DIST = 44f

        const val DEFAULT_YAW_3D = -14f
        const val DEFAULT_PITCH_3D = 46f

        const val MIN_ZOOM = 0.45f
        const val MAX_ZOOM = 2.8f
    }

    private fun effectiveYawDeg(): Float =
        if (renderMode == LabRenderMode.LIGHTWEIGHT_2D) 0f else yawDeg

    private fun effectiveTiltRad(): Double {
        val pitch = if (renderMode == LabRenderMode.LIGHTWEIGHT_2D) 90f else pitchDeg.coerceIn(18f, 88f)
        return Math.toRadians((90f - pitch).toDouble())
    }

    fun scaleBase(viewWidth: Float, viewHeight: Float): Float {
        val safeW = viewWidth.coerceAtLeast(320f)
        val safeH = viewHeight.coerceAtLeast(240f)
        val fit = min(safeW / 35f, safeH / 24f)
        return fit * zoom.coerceIn(MIN_ZOOM, MAX_ZOOM)
    }

    /**
     * Projects world breadboard coordinates (col, row, z height above board) into screen pixels.
     * Supports both 3D Perspective projection and Lightweight 2D orthographic top-down mode.
     */
    fun projectWorldToScreen(
        col: Float,
        row: Float,
        z: Float,
        viewWidth: Float,
        viewHeight: Float
    ): ProjectedPoint {
        val dx = col - CENTER_COL
        val dy = row - CENTER_ROW

        val yawRad = Math.toRadians(effectiveYawDeg().toDouble())
        val cosYaw = cos(yawRad).toFloat()
        val sinYaw = sin(yawRad).toFloat()

        val x1 = dx * cosYaw - dy * sinYaw
        val y1 = dx * sinYaw + dy * cosYaw

        val tiltRad = effectiveTiltRad()
        val cosTilt = cos(tiltRad).toFloat()
        val sinTilt = sin(tiltRad).toFloat()

        val camRight = x1
        val camDown = y1 * cosTilt - z * sinTilt
        val camDepth = y1 * sinTilt + z * cosTilt

        val persp = if (renderMode == LabRenderMode.LIGHTWEIGHT_2D) {
            1f
        } else {
            CAMERA_DIST / (CAMERA_DIST - camDepth).coerceAtLeast(8f)
        }

        val s = scaleBase(viewWidth, viewHeight)
        val cx = viewWidth * 0.5f + panX
        val cy = viewHeight * 0.52f + panY

        return ProjectedPoint(
            offset = Offset(cx + camRight * persp * s, cy + camDown * persp * s),
            depth = camDepth,
            scale = persp * s
        )
    }

    /**
     * Exact closed-form unprojection from screen coordinates onto the z = 0 ground/breadboard plane.
     */
    fun screenToWorldGround(
        screenX: Float,
        screenY: Float,
        viewWidth: Float,
        viewHeight: Float
    ): Pair<Float, Float> {
        val s = scaleBase(viewWidth, viewHeight)
        val cx = viewWidth * 0.5f + panX
        val cy = viewHeight * 0.52f + panY

        val u = (screenX - cx) / s
        val v = (screenY - cy) / s

        val tiltRad = effectiveTiltRad()
        val cosTilt = cos(tiltRad).toFloat()
        val sinTilt = sin(tiltRad).toFloat()

        val (x1, y1) = if (renderMode == LabRenderMode.LIGHTWEIGHT_2D) {
            u to v
        } else {
            val ySolved = (v * CAMERA_DIST) / (cosTilt * CAMERA_DIST + v * sinTilt).coerceAtLeast(1f)
            val persp = CAMERA_DIST / (CAMERA_DIST - ySolved * sinTilt).coerceAtLeast(8f)
            (u / persp) to ySolved
        }

        val yawRad = Math.toRadians(effectiveYawDeg().toDouble())
        val cosYaw = cos(yawRad).toFloat()
        val sinYaw = sin(yawRad).toFloat()

        val dx = x1 * cosYaw + y1 * sinYaw
        val dy = -x1 * sinYaw + y1 * cosYaw

        return (CENTER_COL + dx) to (CENTER_ROW + dy)
    }

    fun reset(): LabCamera3D = copy(
        yawDeg = if (renderMode == LabRenderMode.LIGHTWEIGHT_2D) 0f else DEFAULT_YAW_3D,
        pitchDeg = if (renderMode == LabRenderMode.LIGHTWEIGHT_2D) 90f else DEFAULT_PITCH_3D,
        zoom = 1.0f,
        panX = 0f,
        panY = 0f
    )

    fun toggleMode(): LabCamera3D = if (renderMode == LabRenderMode.PERSPECTIVE_3D) {
        copy(renderMode = LabRenderMode.LIGHTWEIGHT_2D, yawDeg = 0f, pitchDeg = 90f)
    } else {
        copy(renderMode = LabRenderMode.PERSPECTIVE_3D, yawDeg = DEFAULT_YAW_3D, pitchDeg = DEFAULT_PITCH_3D)
    }
}

data class ProjectedPoint(
    val offset: Offset,
    val depth: Float,
    val scale: Float
)
