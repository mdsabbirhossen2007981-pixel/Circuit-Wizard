package com.example.ui.academy

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.localization.AcademyStrings
import com.example.core.localization.AppLanguage
import com.example.domain.calculator.EngineeringCalculators
import com.example.domain.model.QuizQuestionPayload
import com.example.ui.components.CircuitSymbolCanvas
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun InteractiveAnimationCard(
    animationType: String,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var isPlaying by rememberSaveable { mutableStateOf(true) }
    var manualParam by rememberSaveable { mutableFloatStateOf(0.55f) }
    var gateA by rememberSaveable { mutableStateOf(true) }
    var gateB by rememberSaveable { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "circuit_anim")
    val animPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )
    val phase = if (isPlaying) animPhase else manualParam

    val primary = MaterialTheme.colorScheme.primary
    val amber = MaterialTheme.colorScheme.secondary
    val emerald = MaterialTheme.colorScheme.tertiary
    val errorCol = MaterialTheme.colorScheme.error
    val surfaceVar = MaterialTheme.colorScheme.surfaceVariant
    val onSurface = MaterialTheme.colorScheme.onSurface

    val title = when (animationType) {
        "OHM_LAW_SLIDER" -> if (language == AppLanguage.BANGLA) "লাইভ ওহমের সূত্র ও কারেন্ট অ্যানিমেশন" else "Live Ohm's Law & Current Flow"
        "RC_CHARGE" -> if (language == AppLanguage.BANGLA) "ক্যাপাসিটর চার্জিং কার্ভ (τ = RC)" else "RC Exponential Charge Curve (τ = RC)"
        "DIODE_BIAS" -> if (language == AppLanguage.BANGLA) "ডায়োড ফরোয়ার্ড বনাম রিভার্স বায়াস" else "PN Diode Bias & Depletion Simulation"
        "TRANSISTOR_SWITCH" -> if (language == AppLanguage.BANGLA) "ট্রানজিস্টর বেস গেট সুইচিং অ্যানিমেশন" else "Transistor Base/Gate Switching Flow"
        "PWM_LED" -> if (language == AppLanguage.BANGLA) "PWM ডিউটি সাইকেল ও পালস ওয়েভ" else "PWM Duty Cycle & Pulse Modulation"
        "LOGIC_GATE_STEP" -> if (language == AppLanguage.BANGLA) "ইন্টারেক্টিভ ডিজিটাল লজিক স্টেপ" else "Interactive Digital Logic Stepper"
        "BUCK_SWITCHING" -> if (language == AppLanguage.BANGLA) "সুইচিং ইনডাক্টর এনার্জি পালস" else "Switching Inductor Energy Transfer"
        "RECTIFIER_WAVE" -> if (language == AppLanguage.BANGLA) "AC থেকে DC রেক্টিফায়ার ওয়েভফর্ম" else "AC-to-DC Rectified Waveform"
        else -> if (language == AppLanguage.BANGLA) "বৈদ্যুতিক কারেন্ট প্রবাহ অ্যানিমেশন" else "Closed-Loop Current Flow Simulation"
    }

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier
            .fillMaxWidth()
            .testTag("interactive_animation_card")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = primary,
                    modifier = Modifier.weight(1f)
                )
                FilledTonalButton(
                    onClick = { isPlaying = !isPlaying },
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("animation_play_toggle")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pause simulation" else "Play simulation",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (isPlaying) {
                            if (language == AppLanguage.BANGLA) "থামান" else "Pause"
                        } else {
                            if (language == AppLanguage.BANGLA) "চালান" else "Play"
                        },
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(MaterialTheme.shapes.small)
                    .background(surfaceVar.copy(alpha = 0.7f))
            ) {
                val w = size.width
                val h = size.height
                val cy = h / 2f

                when (animationType) {
                    "RC_CHARGE" -> {
                        // Axes
                        drawLine(onSurface.copy(alpha = 0.4f), Offset(w * 0.08f, h * 0.85f), Offset(w * 0.94f, h * 0.85f), 2.5f)
                        drawLine(onSurface.copy(alpha = 0.4f), Offset(w * 0.08f, h * 0.14f), Offset(w * 0.08f, h * 0.85f), 2.5f)
                        // Asymptote target 100%
                        drawLine(emerald.copy(alpha = 0.45f), Offset(w * 0.08f, h * 0.20f), Offset(w * 0.94f, h * 0.20f), 2f)
                        val curve = Path()
                        val steps = 40
                        val plotW = w * 0.84f
                        val plotH = h * 0.65f
                        for (i in 0..steps) {
                            val tNorm = i.toFloat() / steps
                            val vNorm = 1f - exp(-5f * tNorm)
                            val px = w * 0.08f + tNorm * plotW
                            val py = h * 0.85f - vNorm * plotH
                            if (i == 0) curve.moveTo(px, py) else curve.lineTo(px, py)
                        }
                        drawPath(curve, primary, style = Stroke(4f, cap = StrokeCap.Round))
                        // Animated moving point
                        val dotX = w * 0.08f + phase * plotW
                        val dotY = h * 0.85f - (1f - exp(-5f * phase)) * plotH
                        drawCircle(amber, 10f, Offset(dotX, dotY))
                        // 1 tau line at t = 0.2
                        val tauX = w * 0.08f + 0.2f * plotW
                        drawLine(amber.copy(alpha = 0.6f), Offset(tauX, h * 0.22f), Offset(tauX, h * 0.85f), 2f)
                    }
                    "PWM_LED" -> {
                        val duty = manualParam.coerceIn(0.10f, 0.90f)
                        // Glow circle
                        drawCircle(amber.copy(alpha = 0.15f + 0.85f * duty), radius = h * 0.26f, center = Offset(w * 0.86f, cy))
                        drawCircle(amber, radius = h * 0.16f, center = Offset(w * 0.86f, cy), style = Stroke(3f))
                        // 3 PWM square cycles scrolling
                        val startX = w * 0.06f
                        val cycleW = w * 0.22f
                        val hiY = h * 0.24f
                        val loY = h * 0.76f
                        val p = Path()
                        for (c in 0..2) {
                            val bx = startX + c * cycleW
                            val highW = cycleW * duty
                            if (c == 0) p.moveTo(bx, loY)
                            p.lineTo(bx, hiY)
                            p.lineTo(bx + highW, hiY)
                            p.lineTo(bx + highW, loY)
                            p.lineTo(bx + cycleW, loY)
                        }
                        drawPath(p, primary, style = Stroke(4f, cap = StrokeCap.Round))
                    }
                    "RECTIFIER_WAVE", "BUCK_SWITCHING" -> {
                        // Input sine / square vs output smooth wave
                        val cyIn = h * 0.50f
                        drawLine(onSurface.copy(alpha = 0.35f), Offset(w * 0.06f, cyIn), Offset(w * 0.94f, cyIn), 2f)
                        val acPath = Path()
                        val rectPath = Path()
                        val pts = 60
                        for (i in 0..pts) {
                            val xNorm = i.toFloat() / pts
                            val px = w * 0.06f + xNorm * w * 0.88f
                            val s = sin((xNorm * 3.0 + phase * 2.0) * 2.0 * PI).toFloat()
                            val yAc = cyIn - s * h * 0.30f
                            val yDc = cyIn - abs(s) * h * 0.28f - h * 0.04f
                            if (i == 0) {
                                acPath.moveTo(px, yAc)
                                rectPath.moveTo(px, yDc)
                            } else {
                                acPath.lineTo(px, yAc)
                                rectPath.lineTo(px, yDc)
                            }
                        }
                        drawPath(acPath, primary.copy(alpha = 0.45f), style = Stroke(3f))
                        drawPath(rectPath, emerald, style = Stroke(4.5f, cap = StrokeCap.Round))
                    }
                    "DIODE_BIAS" -> {
                        val forward = manualParam >= 0.4f
                        val diodeCol = if (forward) emerald else errorCol
                        drawLine(onSurface.copy(alpha = 0.6f), Offset(w * 0.12f, cy), Offset(w * 0.88f, cy), 4f)
                        val tri = Path().apply {
                            moveTo(w * 0.42f, cy - h * 0.22f)
                            lineTo(w * 0.42f, cy + h * 0.22f)
                            lineTo(w * 0.56f, cy)
                            close()
                        }
                        drawPath(tri, diodeCol, style = Stroke(5f))
                        drawLine(diodeCol, Offset(w * 0.56f, cy - h * 0.22f), Offset(w * 0.56f, cy + h * 0.22f), 6f)
                        if (forward) {
                            for (k in 0..3) {
                                val t = ((phase + k * 0.25f) % 1f)
                                drawCircle(amber, 7f, Offset(w * 0.12f + t * w * 0.76f, cy))
                            }
                        } else {
                            // Thick depletion wall
                            drawRect(errorCol.copy(alpha = 0.3f), Offset(w * 0.47f, cy - h * 0.26f), Size(w * 0.10f, h * 0.52f))
                        }
                    }
                    "LOGIC_GATE_STEP" -> {
                        val out = gateA && gateB
                        val inACol = if (gateA) emerald else errorCol
                        val inBCol = if (gateB) emerald else errorCol
                        val outCol = if (out) emerald else errorCol
                        drawLine(inACol, Offset(w * 0.12f, h * 0.35f), Offset(w * 0.36f, h * 0.35f), 5f)
                        drawLine(inBCol, Offset(w * 0.12f, h * 0.65f), Offset(w * 0.36f, h * 0.65f), 5f)
                        drawRoundRect(primary.copy(alpha = 0.2f), Offset(w * 0.36f, h * 0.20f), Size(w * 0.28f, h * 0.60f), CornerRadius(12f, 12f))
                        drawRoundRect(primary, Offset(w * 0.36f, h * 0.20f), Size(w * 0.28f, h * 0.60f), CornerRadius(12f, 12f), style = Stroke(3.5f))
                        drawLine(outCol, Offset(w * 0.64f, cy), Offset(w * 0.88f, cy), 6f)
                        drawCircle(outCol, 14f, Offset(w * 0.88f, cy))
                    }
                    else -> {
                        // Closed-loop Current / Ohm / Transistor flow animation around rectangular loop
                        val left = w * 0.16f
                        val right = w * 0.84f
                        val top = h * 0.22f
                        val bot = h * 0.78f
                        drawRect(primary.copy(alpha = 0.6f), Offset(left, top), Size(right - left, bot - top), style = Stroke(4f))
                        // Battery box on left, Load box on right
                        drawRoundRect(amber, Offset(left - 18f, cy - 18f), Size(36f, 36f), CornerRadius(6f, 6f))
                        drawRoundRect(emerald, Offset(right - 18f, cy - 18f), Size(36f, 36f), CornerRadius(6f, 6f))

                        val count = 6
                        for (i in 0 until count) {
                            val p = ((phase + i.toFloat() / count) % 1f) * 4f
                            val dot = when {
                                p < 1f -> Offset(left + (right - left) * p, top)
                                p < 2f -> Offset(right, top + (bot - top) * (p - 1f))
                                p < 3f -> Offset(right - (right - left) * (p - 2f), bot)
                                else -> Offset(left, bot - (bot - top) * (p - 3f))
                            }
                            drawCircle(amber, 6.5f, dot)
                        }
                    }
                }
            }

            if (animationType == "LOGIC_GATE_STEP") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = { gateA = !gateA },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Text("Input A = ${if (gateA) "1 (HIGH)" else "0 (LOW)"}")
                    }
                    FilledTonalButton(
                        onClick = { gateB = !gateB },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Text("Input B = ${if (gateB) "1 (HIGH)" else "0 (LOW)"}")
                    }
                }
                Text(
                    text = if (language == AppLanguage.BANGLA) {
                        "AND গেট আউটপুট Q = ${if (gateA && gateB) "১ (HIGH)" else "০ (LOW)"}"
                    } else {
                        "AND Output Q = ${if (gateA && gateB) "1 (HIGH)" else "0 (LOW)"}"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = if (gateA && gateB) emerald else errorCol
                )
            } else {
                val sliderLabel = when (animationType) {
                    "PWM_LED" -> "Duty Cycle: ${(manualParam * 100).roundToInt()}%"
                    "DIODE_BIAS" -> if (manualParam >= 0.4f) "Bias: Forward (+0.7V)" else "Bias: Reverse (Blocked)"
                    else -> if (isPlaying) {
                        if (language == AppLanguage.BANGLA) "চলমান সিমুলেশন গতি/অবস্থান" else "Adjust phase / parameter:"
                    } else {
                        "Step Phase: ${(manualParam * 100).roundToInt()}%"
                    }
                }
                Column {
                    Text(
                        text = sliderLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = manualParam,
                        onValueChange = { manualParam = it },
                        valueRange = 0.05f..0.95f
                    )
                }
            }
        }
    }
}

@Composable
fun InteractiveCalculatorCard(
    calculatorType: String,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("interactive_calculator_card")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = AcademyStrings.interactiveCalcTitle(language),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            when (calculatorType) {
                "RESISTOR_COLOR" -> ResistorColorCalculatorBody(language)
                "RC_TIME" -> RcTimeCalculatorBody(language)
                "VOLTAGE_DIVIDER" -> VoltageDividerCalculatorBody(language)
                "NE555_ASTABLE" -> Ne555CalculatorBody(language)
                "BUCK_RATIO" -> BuckCalculatorBody(language)
                "SERIES_PARALLEL" -> SeriesParallelCalculatorBody(language)
                else -> OhmPowerCalculatorBody(language, isPowerMode = calculatorType == "POWER")
            }
        }
    }
}

@Composable
private fun OhmPowerCalculatorBody(language: AppLanguage, isPowerMode: Boolean) {
    var voltage by rememberSaveable { mutableFloatStateOf(9f) }
    var resistance by rememberSaveable { mutableFloatStateOf(330f) }
    val res = EngineeringCalculators.solveOhmsLawFromVR(voltage.toDouble(), resistance.toDouble())

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Supply Voltage V = ${voltage.roundToInt()} V", style = MaterialTheme.typography.labelLarge)
        Slider(value = voltage, onValueChange = { voltage = it }, valueRange = 1f..24f)

        Text("Load Resistance R = ${EngineeringCalculators.formatOhms(resistance.toDouble())}", style = MaterialTheme.typography.labelLarge)
        Slider(value = resistance, onValueChange = { resistance = it }, valueRange = 10f..2200f)

        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "I = V / R = ${String.format("%.1f", res.currentMa)} mA",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isPowerMode) {
                        "Power P = V × I = ${String.format("%.1f", res.powerMw)} mW (${String.format("%.2f", res.powerMw / 1000.0)} W)"
                    } else {
                        "Dissipated Power P = ${String.format("%.1f", res.powerMw)} mW"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                if (res.powerMw > 250.0) {
                    Text(
                        text = if (language == AppLanguage.BANGLA) "সতর্কতা: ১/৪ ওয়াট (250 mW) রোধের জন্য পাওয়ার বেশি—১/২ ওয়াট ব্যবহার করুন!" else "Warning: Exceeds 0.25 W quarter-watt resistor rating!",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun SeriesParallelCalculatorBody(language: AppLanguage) {
    var r1 by rememberSaveable { mutableFloatStateOf(1000f) }
    var r2 by rememberSaveable { mutableFloatStateOf(1000f) }
    val (series, parallel) = EngineeringCalculators.solveSeriesParallel(r1.toDouble(), r2.toDouble())

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("R1 = ${EngineeringCalculators.formatOhms(r1.toDouble())}", style = MaterialTheme.typography.labelLarge)
        Slider(value = r1, onValueChange = { r1 = it }, valueRange = 100f..10000f)
        Text("R2 = ${EngineeringCalculators.formatOhms(r2.toDouble())}", style = MaterialTheme.typography.labelLarge)
        Slider(value = r2, onValueChange = { r2 = it }, valueRange = 100f..10000f)
        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = if (language == AppLanguage.BANGLA) {
                        "সিরিজ (R1 + R2) = ${EngineeringCalculators.formatOhms(series)}"
                    } else {
                        "Series Total (R1 + R2) = ${EngineeringCalculators.formatOhms(series)}"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (language == AppLanguage.BANGLA) {
                        "প্যারালাল (R1 || R2) = ${EngineeringCalculators.formatOhms(parallel)}"
                    } else {
                        "Parallel Total (R1 || R2) = ${EngineeringCalculators.formatOhms(parallel)}"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

@Composable
private fun VoltageDividerCalculatorBody(language: AppLanguage) {
    var vIn by rememberSaveable { mutableFloatStateOf(5f) }
    var r1 by rememberSaveable { mutableFloatStateOf(1000f) }
    var r2 by rememberSaveable { mutableFloatStateOf(2000f) }
    val res = EngineeringCalculators.solveVoltageDivider(vIn.toDouble(), r1.toDouble(), r2.toDouble())

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("V_in = ${String.format("%.1f", vIn)} V", style = MaterialTheme.typography.labelLarge)
        Slider(value = vIn, onValueChange = { vIn = it }, valueRange = 3.3f..24f)
        Text("Top R1 = ${EngineeringCalculators.formatOhms(r1.toDouble())} | Bottom R2 = ${EngineeringCalculators.formatOhms(r2.toDouble())}", style = MaterialTheme.typography.labelMedium)
        Slider(value = r1, onValueChange = { r1 = it }, valueRange = 100f..10000f)
        Slider(value = r2, onValueChange = { r2 = it }, valueRange = 100f..10000f)
        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "V_out = ${String.format("%.2f", res.vOut)} V  (I = ${String.format("%.2f", res.currentMa)} mA)",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (language == AppLanguage.BANGLA) "V_out = V_in × R2 / (R1 + R2)" else "V_out = V_in × R2 / (R1 + R2)",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun RcTimeCalculatorBody(language: AppLanguage) {
    var rOhm by rememberSaveable { mutableFloatStateOf(10000f) }
    var cUf by rememberSaveable { mutableFloatStateOf(100f) }
    val rc = EngineeringCalculators.solveRcCircuit(rOhm.toDouble(), cUf.toDouble())

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("R = ${EngineeringCalculators.formatOhms(rOhm.toDouble())}", style = MaterialTheme.typography.labelLarge)
        Slider(value = rOhm, onValueChange = { rOhm = it }, valueRange = 100f..47000f)
        Text("Capacitance C = ${cUf.roundToInt()} µF", style = MaterialTheme.typography.labelLarge)
        Slider(value = cUf, onValueChange = { cUf = it }, valueRange = 1f..470f)
        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("τ = R × C = ${String.format("%.1f", rc.tauMs)} ms (63.2% charge)", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text("Full charge (5τ) = ${String.format("%.1f", rc.fullChargeMs)} ms | Cutoff f_c = ${EngineeringCalculators.formatFreq(rc.cutoffHz)}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun Ne555CalculatorBody(language: AppLanguage) {
    var ra by rememberSaveable { mutableFloatStateOf(1000f) }
    var rb by rememberSaveable { mutableFloatStateOf(47000f) }
    var cUf by rememberSaveable { mutableFloatStateOf(10f) }
    val res = EngineeringCalculators.solveNe555Astable(ra.toDouble(), rb.toDouble(), cUf.toDouble())

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("RA = ${EngineeringCalculators.formatOhms(ra.toDouble())} | RB = ${EngineeringCalculators.formatOhms(rb.toDouble())} | C = ${cUf.roundToInt()} µF", style = MaterialTheme.typography.labelMedium)
        Slider(value = ra, onValueChange = { ra = it }, valueRange = 1000f..47000f)
        Slider(value = rb, onValueChange = { rb = it }, valueRange = 1000f..100000f)
        Slider(value = cUf, onValueChange = { cUf = it }, valueRange = 1f..100f)
        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("f = ${EngineeringCalculators.formatFreq(res.frequencyHz)} | Duty = ${String.format("%.1f", res.dutyCyclePercent)}%", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text("HIGH = ${String.format("%.1f", res.highTimeMs)} ms | LOW = ${String.format("%.1f", res.lowTimeMs)} ms", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun BuckCalculatorBody(language: AppLanguage) {
    var vIn by rememberSaveable { mutableFloatStateOf(12f) }
    var duty by rememberSaveable { mutableFloatStateOf(42f) }
    val (vOut, _, eff) = EngineeringCalculators.solveBuckConverter(vIn.toDouble(), duty.toDouble())

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("V_in = ${vIn.roundToInt()} V | Duty Cycle D = ${duty.roundToInt()}%", style = MaterialTheme.typography.labelLarge)
        Slider(value = vIn, onValueChange = { vIn = it }, valueRange = 5f..36f)
        Slider(value = duty, onValueChange = { duty = it }, valueRange = 10f..90f)
        Surface(
            shape = MaterialTheme.shapes.small,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("V_out = D × V_in = ${String.format("%.2f", vOut)} V (~${eff.roundToInt()}% eff.)", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text(if (language == AppLanguage.BANGLA) "সুইচিং লস কম হওয়ায় তাপ প্রায় তৈরিই হয় না।" else "Cool switching regulation without wasting excess volts as heat.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ResistorColorCalculatorBody(language: AppLanguage) {
    val bands = EngineeringCalculators.resistorBands
    val digitBands = remember { bands.filter { it.digit != null } }
    val tolBands = remember { bands.filter { it.tolerancePct != null } }

    var b1Idx by rememberSaveable { mutableIntStateOf(1) } // Brown 1
    var b2Idx by rememberSaveable { mutableIntStateOf(0) } // Black 0
    var multIdx by rememberSaveable { mutableIntStateOf(2) } // Red x100 -> 1k
    var tolIdx by rememberSaveable { mutableIntStateOf(4) } // Gold 5%

    val b1 = digitBands.getOrElse(b1Idx) { digitBands.first() }
    val b2 = digitBands.getOrElse(b2Idx) { digitBands.first() }
    val mult = bands.getOrElse(multIdx) { bands[2] }
    val tol = tolBands.getOrElse(tolIdx) { tolBands.last() }

    val (ohms, tolPct) = EngineeringCalculators.decodeFourBandResistor(b1, b2, mult, tol)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Live visual resistor band preview
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            listOf(b1, b2, mult, tol).forEach { band ->
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .height(38.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(band.colorHex))
                )
            }
            Text(
                text = "${EngineeringCalculators.formatOhms(ohms)} ±$tolPct%",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }

        BandSelectorRow(
            label = if (language == AppLanguage.BANGLA) "১ম ব্যান্ড" else "Band 1",
            items = digitBands.mapIndexed { idx, c -> idx to (if (language == AppLanguage.BANGLA) c.nameBn else c.nameEn) to c.colorHex },
            selectedIdx = b1Idx,
            onSelect = { b1Idx = it }
        )
        BandSelectorRow(
            label = if (language == AppLanguage.BANGLA) "২য় ব্যান্ড" else "Band 2",
            items = digitBands.mapIndexed { idx, c -> idx to (if (language == AppLanguage.BANGLA) c.nameBn else c.nameEn) to c.colorHex },
            selectedIdx = b2Idx,
            onSelect = { b2Idx = it }
        )
        BandSelectorRow(
            label = if (language == AppLanguage.BANGLA) "গুণক" else "Multiplier",
            items = bands.take(8).mapIndexed { idx, c -> idx to (if (language == AppLanguage.BANGLA) c.nameBn else c.nameEn) to c.colorHex },
            selectedIdx = multIdx,
            onSelect = { multIdx = it }
        )
    }
}

@Composable
private fun BandSelectorRow(
    label: String,
    items: List<Pair<Pair<Int, String>, Long>>,
    selectedIdx: Int,
    onSelect: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items.forEach { (idxText, colorHex) ->
                val (idx, text) = idxText
                val selected = idx == selectedIdx
                Surface(
                    onClick = { onSelect(idx) },
                    shape = RoundedCornerShape(8.dp),
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                    modifier = Modifier.heightIn(min = 36.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Color(colorHex))
                        )
                        Text(text, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun InlineKnowledgeCheckCard(
    question: QuizQuestionPayload,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var selectedIdx by rememberSaveable(question.id) { mutableIntStateOf(-1) }
    val answered = selectedIdx >= 0
    val isCorrect = selectedIdx == question.correctIndex

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = question.prompt(language),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            question.options(language).forEachIndexed { idx, opt ->
                val isSelected = selectedIdx == idx
                val borderCol = when {
                    answered && idx == question.correctIndex -> MaterialTheme.colorScheme.tertiary
                    answered && isSelected && idx != question.correctIndex -> MaterialTheme.colorScheme.error
                    isSelected -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.outline
                }
                val bgCol = when {
                    answered && idx == question.correctIndex -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.14f)
                    answered && isSelected -> MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                }
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = bgCol,
                    border = BorderStroke(1.5.dp, borderCol),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clip(MaterialTheme.shapes.small)
                        .clickable { selectedIdx = idx }
                        .testTag("inline_option_${question.id}_$idx")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${('A' + idx)}. $opt",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        if (answered && idx == question.correctIndex) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Correct option",
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
            if (answered) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = if (isCorrect) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = question.explanation(language),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun VirtualLabPreviewSheet(
    circuitId: String,
    lessonTitle: String,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    var vSupply by rememberSaveable(circuitId) {
        mutableFloatStateOf(
            when (circuitId) {
                "lab_buck_pwm" -> 12f
                "lab_ohm_law" -> 9f
                else -> 5f
            }
        )
    }
    var paramVal by rememberSaveable(circuitId) {
        mutableFloatStateOf(
            when (circuitId) {
                "lab_buck_pwm" -> 42f
                "lab_rc_charge" -> 100f
                else -> 330f
            }
        )
    }

    val symbol = when {
        circuitId.contains("buck") -> "BUCK_CONVERTER"
        circuitId.contains("rc") -> "CAPACITOR_POLAR"
        circuitId.contains("diode") -> "DIODE_PN"
        circuitId.contains("transistor") -> "BJT_NPN"
        circuitId.contains("555") -> "IC_555"
        circuitId.contains("logic") -> "LOGIC_NAND"
        circuitId.contains("led") -> "LED"
        else -> "RESISTOR"
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("virtual_lab_preview_dialog")
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.Science, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(
                                text = AcademyStrings.virtualLabPreviewBadge(language),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = lessonTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(48.dp).testTag("close_virtual_lab_button")
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close lab bench")
                    }
                }

                // Visual Bench Area
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.size(84.dp)) {
                        CircuitSymbolCanvas(symbolType = symbol)
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Bench Preset: $circuitId",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        val liveReadout = when {
                            circuitId.contains("buck") -> {
                                val (vOut, _, eff) = EngineeringCalculators.solveBuckConverter(vSupply.toDouble(), paramVal.toDouble().coerceIn(10.0, 90.0))
                                "V_out = ${String.format("%.2f", vOut)} V @ ${eff.roundToInt()}% eff."
                            }
                            circuitId.contains("rc") -> {
                                val rc = EngineeringCalculators.solveRcCircuit(10_000.0, paramVal.toDouble().coerceAtLeast(1.0))
                                "τ = ${String.format("%.1f", rc.tauMs)} ms (Full 5τ = ${String.format("%.1f", rc.fullChargeMs)} ms)"
                            }
                            circuitId.contains("led") -> {
                                val ledRes = EngineeringCalculators.solveLedSeriesResistor(vSupply.toDouble(), 2.0, 15.0)
                                "Rec Resistor ≈ ${EngineeringCalculators.formatOhms(ledRes.resistanceOhm)} | I ≈ ${String.format("%.1f", (vSupply - 2.0).coerceAtLeast(0.0) / paramVal.coerceAtLeast(10f) * 1000.0)} mA"
                            }
                            else -> {
                                val ohm = EngineeringCalculators.solveOhmsLawFromVR(vSupply.toDouble(), paramVal.toDouble().coerceAtLeast(10.0))
                                "Live Meter: ${String.format("%.2f", ohm.currentMa)} mA | ${String.format("%.1f", ohm.powerMw)} mW"
                            }
                        }
                        Text(
                            text = liveReadout,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.tertiary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Live Interactive Bench Controls
                Text("Source Rail Voltage: ${String.format("%.1f", vSupply)} V", style = MaterialTheme.typography.labelLarge)
                Slider(value = vSupply, onValueChange = { vSupply = it }, valueRange = 3.3f..24f)

                val pLabel = when {
                    circuitId.contains("buck") -> "Switching Duty Cycle: ${paramVal.roundToInt().coerceIn(10, 90)}%"
                    circuitId.contains("rc") -> "Capacitor C: ${paramVal.roundToInt()} µF (with 10 kΩ)"
                    else -> "Circuit Load / Series R: ${EngineeringCalculators.formatOhms(paramVal.toDouble())}"
                }
                Text(pLabel, style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = paramVal,
                    onValueChange = { paramVal = it },
                    valueRange = when {
                        circuitId.contains("buck") -> 10f..90f
                        circuitId.contains("rc") -> 1f..470f
                        else -> 47f..2200f
                    }
                )

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Text(if (language == AppLanguage.BANGLA) "পাঠে ফিরে যান" else "Return to Lesson")
                }
            }
        }
    }
}
