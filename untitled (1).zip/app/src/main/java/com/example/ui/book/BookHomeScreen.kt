package com.example.ui.book

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.OfflinePin
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.localization.AppLanguage
import com.example.core.localization.BookStrings
import com.example.domain.model.ComponentCategory
import com.example.domain.model.ElectronicComponent
import com.example.ui.components.CategoryChapterCard
import com.example.ui.components.CircuitSymbolCanvas
import com.example.ui.components.ComponentBookCard
import com.example.ui.components.SearchBookBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.categoryAccentColor

@Composable
fun BookHomeScreen(
    uiState: BookUiState,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenCategory: (ComponentCategory) -> Unit,
    onBrowseAll: () -> Unit,
    onOpenSaved: () -> Unit,
    onOpenComponent: (String) -> Unit,
    onToggleBookmark: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        val columns = if (maxWidth >= 700.dp) 3 else 2

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 960.dp)
                .testTag("book_home_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item(key = "hero_cover") {
                TextbookHeroCover(
                    language = lang,
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = onToggleTheme,
                    onToggleLanguage = onToggleLanguage
                )
            }

            item(key = "home_search") {
                SearchBookBar(
                    query = uiState.searchQuery,
                    onQueryChange = onSearchQueryChange,
                    language = lang,
                    testTag = "home_search_input"
                )
            }

            if (uiState.searchQuery.isNotBlank()) {
                item(key = "instant_results_header") {
                    SectionHeader(
                        title = if (lang == AppLanguage.BANGLA) {
                            "অনুসন্ধানের ফলাফল (${uiState.filteredComponents.size})"
                        } else {
                            "Search Results (${uiState.filteredComponents.size})"
                        },
                        actionLabel = BookStrings.viewAll(lang),
                        onActionClick = onBrowseAll,
                        actionTag = "home_search_view_all"
                    )
                }
                if (uiState.filteredComponents.isEmpty()) {
                    item(key = "instant_empty") {
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Text(
                                text = BookStrings.noSearchResults(lang),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth().padding(20.dp)
                            )
                        }
                    }
                } else {
                    items(
                        items = uiState.filteredComponents.take(8),
                        key = { "home_search_${it.id}" }
                    ) { comp ->
                        ComponentBookCard(
                            component = comp,
                            language = lang,
                            onOpenDetail = { onOpenComponent(comp.id) },
                            onToggleBookmark = { onToggleBookmark(comp.id) }
                        )
                    }
                }
            } else {
                // Learning Progress + Continue Learning
                item(key = "progress_and_continue") {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        LearningProgressCard(
                            studied = uiState.studiedCount,
                            total = uiState.totalCount,
                            fraction = uiState.progressFraction,
                            language = lang
                        )
                        uiState.continueLearningComponent?.let { nextComp ->
                            ContinueLearningCard(
                                component = nextComp,
                                language = lang,
                                onContinue = { onOpenComponent(nextComp.id) }
                            )
                        }
                    }
                }

                // 11 Component Chapters (A-K)
                item(key = "chapters_header") {
                    SectionHeader(
                        title = BookStrings.componentCategories(lang),
                        actionLabel = BookStrings.viewAll(lang),
                        onActionClick = onBrowseAll,
                        actionTag = "home_browse_all_button"
                    )
                }

                val rows = uiState.categoryProgress.chunked(columns)
                items(
                    items = rows,
                    key = { row -> "cat_row_${row.joinToString("_") { it.category.id }}" }
                ) { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { stats ->
                            CategoryChapterCard(
                                category = stats.category,
                                componentCount = stats.totalCount,
                                studiedCount = stats.studiedCount,
                                language = lang,
                                onClick = { onOpenCategory(stats.category) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(columns - rowItems.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }

                // Featured Components
                if (uiState.featuredComponents.isNotEmpty()) {
                    item(key = "featured_header") {
                        SectionHeader(title = BookStrings.featuredComponents(lang))
                    }
                    item(key = "featured_row") {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.testTag("featured_components_row")
                        ) {
                            items(
                                items = uiState.featuredComponents.take(12),
                                key = { "feat_${it.id}" }
                            ) { comp ->
                                CompactComponentTile(
                                    component = comp,
                                    language = lang,
                                    onClick = { onOpenComponent(comp.id) }
                                )
                            }
                        }
                    }
                }

                // Recently Viewed
                item(key = "recent_header") {
                    SectionHeader(
                        title = BookStrings.recentlyViewed(lang),
                        actionLabel = if (uiState.recentlyViewed.isNotEmpty()) BookStrings.viewAll(lang) else null,
                        onActionClick = if (uiState.recentlyViewed.isNotEmpty()) onOpenSaved else null,
                        actionTag = "home_recent_view_all"
                    )
                }
                if (uiState.recentlyViewed.isEmpty()) {
                    item(key = "recent_empty") {
                        EmptyHintStrip(
                            icon = Icons.Rounded.History,
                            text = BookStrings.noRecentYet(lang)
                        )
                    }
                } else {
                    item(key = "recent_row") {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.testTag("recently_viewed_row")
                        ) {
                            items(
                                items = uiState.recentlyViewed,
                                key = { "rec_${it.id}" }
                            ) { comp ->
                                CompactComponentTile(
                                    component = comp,
                                    language = lang,
                                    onClick = { onOpenComponent(comp.id) }
                                )
                            }
                        }
                    }
                }

                // Bookmarks Preview
                item(key = "bookmarks_header") {
                    SectionHeader(
                        title = BookStrings.bookmarksTitle(lang),
                        actionLabel = if (uiState.bookmarkedComponents.isNotEmpty()) BookStrings.viewAll(lang) else null,
                        onActionClick = if (uiState.bookmarkedComponents.isNotEmpty()) onOpenSaved else null,
                        actionTag = "home_bookmarks_view_all"
                    )
                }
                if (uiState.bookmarkedComponents.isEmpty()) {
                    item(key = "bookmarks_empty") {
                        EmptyHintStrip(
                            icon = Icons.Rounded.Bookmark,
                            text = BookStrings.noBookmarksYet(lang)
                        )
                    }
                } else {
                    items(
                        items = uiState.bookmarkedComponents.take(4),
                        key = { "bm_${it.id}" }
                    ) { comp ->
                        ComponentBookCard(
                            component = comp,
                            language = lang,
                            onOpenDetail = { onOpenComponent(comp.id) },
                            onToggleBookmark = { onToggleBookmark(comp.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TextbookHeroCover(
    language: AppLanguage,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val gradient = Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primaryContainer,
            MaterialTheme.colorScheme.surface
        )
    )
    Surface(
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("textbook_hero_card")
    ) {
        Column(
            modifier = Modifier
                .background(gradient)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Bolt,
                                contentDescription = BookStrings.appTitle(language),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = BookStrings.appTitle(language),
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = BookStrings.editionBadge(language),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("home_language_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Translate,
                            contentDescription = "Switch language",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("home_theme_toggle")
                    ) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                            contentDescription = "Toggle theme",
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = BookStrings.welcomeHeadline(language),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = BookStrings.welcomeSubtitle(language),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Surface(
                shape = RoundedCornerShape(99.dp),
                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.85f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.OfflinePin,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = BookStrings.offlineReadyBadge(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun LearningProgressCard(
    studied: Int,
    total: Int,
    fraction: Float,
    language: AppLanguage
) {
    val pct = (fraction * 100).toInt()
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth().testTag("learning_progress_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = BookStrings.learningProgress(language),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "$studied / $total ($pct%)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.tertiary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { fraction },
                color = MaterialTheme.colorScheme.tertiary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(99.dp))
            )
        }
    }
}

@Composable
private fun ContinueLearningCard(
    component: ElectronicComponent,
    language: AppLanguage,
    onContinue: () -> Unit
) {
    val accent = categoryAccentColor(component.category)
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().testTag("continue_learning_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(MaterialTheme.shapes.small)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(6.dp)
            ) {
                CircuitSymbolCanvas(
                    symbolType = component.payload.symbolType,
                    strokeColor = accent,
                    accentColor = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.MenuBook,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = if (component.lastViewedAt > 0L) {
                            BookStrings.continueLearning(language)
                        } else {
                            BookStrings.startReading(language)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = accent,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    text = component.name(language),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = component.summary(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onContinue,
                colors = ButtonDefaults.buttonColors(containerColor = accent),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("continue_learning_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = BookStrings.continueLearning(language)
                )
            }
        }
    }
}

@Composable
private fun CompactComponentTile(
    component: ElectronicComponent,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val accent = categoryAccentColor(component.category)
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier
            .width(166.dp)
            .testTag("compact_tile_${component.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = component.category.chapterCode,
                    style = MaterialTheme.typography.labelSmall,
                    color = accent,
                    fontWeight = FontWeight.Bold
                )
                if (component.featured) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .clip(MaterialTheme.shapes.small)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(6.dp)
            ) {
                CircuitSymbolCanvas(
                    symbolType = component.payload.symbolType,
                    strokeColor = accent,
                    accentColor = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = component.name(language),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.height(40.dp)
            )
        }
    }
}

@Composable
private fun EmptyHintStrip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
