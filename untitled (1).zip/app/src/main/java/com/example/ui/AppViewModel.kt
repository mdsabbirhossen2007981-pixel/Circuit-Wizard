package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.di.AppContainer
import com.example.core.localization.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(
    private val container: AppContainer
) : ViewModel() {

    val isDarkTheme: StateFlow<Boolean> = container.userPrefsStore.isDarkTheme
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    val language: StateFlow<AppLanguage> = container.userPrefsStore.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppLanguage.ENGLISH)

    private val _isCatalogReady = MutableStateFlow(false)
    val isCatalogReady: StateFlow<Boolean> = _isCatalogReady.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { container.componentRepository.initializeCatalog() }
            _isCatalogReady.value = true
        }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            container.userPrefsStore.setDarkTheme(enabled)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            container.userPrefsStore.setLanguage(language)
        }
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AppViewModel(container) as T
        }
    }
}
