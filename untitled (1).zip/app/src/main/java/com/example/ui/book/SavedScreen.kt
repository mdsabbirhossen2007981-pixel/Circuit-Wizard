package com.example.ui.book

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.localization.BookStrings
import com.example.ui.components.ComponentBookCard
import com.example.ui.components.SectionHeader

@Composable
fun SavedScreen(
    uiState: BookUiState,
    onOpenComponent: (String) -> Unit,
    onToggleBookmark: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 800.dp)
                .testTag("saved_screen_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "saved_header") {
                SectionHeader(title = BookStrings.bookmarksTitle(lang))
            }

            if (uiState.bookmarkedComponents.isEmpty()) {
                item(key = "saved_bm_empty") {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = BookStrings.noBookmarksYet(lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth().padding(18.dp)
                        )
                    }
                }
            } else {
                items(
                    items = uiState.bookmarkedComponents,
                    key = { "saved_bm_${it.id}" }
                ) { comp ->
                    ComponentBookCard(
                        component = comp,
                        language = lang,
                        onOpenDetail = { onOpenComponent(comp.id) },
                        onToggleBookmark = { onToggleBookmark(comp.id) }
                    )
                }
            }

            item(key = "saved_recent_header") {
                SectionHeader(
                    title = BookStrings.recentlyViewed(lang),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (uiState.recentlyViewed.isEmpty()) {
                item(key = "saved_rec_empty") {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = BookStrings.noRecentYet(lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth().padding(18.dp)
                        )
                    }
                }
            } else {
                items(
                    items = uiState.recentlyViewed,
                    key = { "saved_rec_${it.id}" }
                ) { comp ->
                    ComponentBookCard(
                        component = comp,
                        language = lang,
                        onOpenDetail = { onOpenComponent(comp.id) },
                        onToggleBookmark = { onToggleBookmark(comp.id) }
                    )
                }
            }
        }
    }
}
