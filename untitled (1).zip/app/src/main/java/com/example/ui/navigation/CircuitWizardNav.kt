package com.example.ui.navigation

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.core.di.AppContainer
import com.example.core.localization.AcademyStrings
import com.example.core.localization.AppLanguage
import com.example.core.localization.BookStrings
import com.example.core.localization.LabStrings
import com.example.domain.model.AcademyCourse
import com.example.ui.AppViewModel
import com.example.ui.academy.AcademyHomeScreen
import com.example.ui.academy.AcademyViewModel
import com.example.ui.academy.CourseDetailScreen
import com.example.ui.academy.LessonDetailScreen
import com.example.ui.academy.LessonDetailViewModel
import com.example.ui.book.BookHomeScreen
import com.example.ui.book.BookViewModel
import com.example.ui.book.ComponentDetailScreen
import com.example.ui.book.ComponentDetailViewModel
import com.example.ui.book.LibraryScreen
import com.example.ui.book.SavedScreen
import com.example.ui.lab.LabWorkspaceViewModel
import com.example.ui.lab.VirtualLabScreen
import com.example.ui.profile.SettingsScreen
import com.example.ui.profile.SettingsViewModel
import com.example.ui.quiz.QuizHubScreen
import com.example.ui.quiz.QuizHubViewModel
import com.example.ui.quiz.QuizRunnerScreen
import com.example.ui.quiz.QuizRunnerViewModel

const val ROUTE_BOOK = "book"
const val ROUTE_ACADEMY = "academy"
const val ROUTE_LAB = "lab"
const val ROUTE_LIBRARY = "library"
const val ROUTE_QUIZ = "quiz"
const val ROUTE_SAVED = "saved"
const val ROUTE_SETTINGS = "settings"
const val ROUTE_COMPONENT_DETAIL = "component/{componentId}"
const val ROUTE_COURSE = "course/{courseId}"
const val ROUTE_LESSON = "lesson/{lessonId}"
const val ROUTE_QUIZ_RUN = "quiz_run/{courseId}/{timed}"

private data class TopDestination(
    val route: String,
    val icon: ImageVector,
    val label: (AppLanguage) -> String,
    val testTag: String
)

private val topDestinations = listOf(
    TopDestination(ROUTE_BOOK, Icons.AutoMirrored.Rounded.MenuBook, BookStrings::navBook, "nav_book"),
    TopDestination(ROUTE_ACADEMY, Icons.Rounded.School, AcademyStrings::navAcademy, "nav_academy"),
    TopDestination(ROUTE_LAB, Icons.Rounded.Science, LabStrings::navLab, "nav_lab"),
    TopDestination(ROUTE_QUIZ, Icons.Rounded.Quiz, AcademyStrings::navQuiz, "nav_quiz"),
    TopDestination(ROUTE_SETTINGS, Icons.Rounded.Settings, BookStrings::navSettings, "nav_settings")
)

@Composable
fun CircuitWizardAppShell(
    appViewModel: AppViewModel,
    container: AppContainer,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_BOOK
    val isDetailRoute = currentRoute.startsWith("component/") ||
        currentRoute.startsWith("course/") ||
        currentRoute.startsWith("lesson/") ||
        currentRoute.startsWith("quiz_run/")

    val isDarkTheme by appViewModel.isDarkTheme.collectAsStateWithLifecycle()
    val language by appViewModel.language.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        container.academyRepository.initializeAcademy()
    }

    val bookViewModel: BookViewModel = viewModel(
        factory = BookViewModel.Factory(container.componentRepository, container.userPrefsStore)
    )
    val bookUiState by bookViewModel.uiState.collectAsStateWithLifecycle()

    val academyViewModel: AcademyViewModel = viewModel(
        factory = AcademyViewModel.Factory(
            container.academyRepository,
            container.quizRepository,
            container.userPrefsStore
        )
    )
    val academyUiState by academyViewModel.uiState.collectAsStateWithLifecycle()

    val quizHubViewModel: QuizHubViewModel = viewModel(
        factory = QuizHubViewModel.Factory(container.quizRepository, container.userPrefsStore)
    )
    val quizHubUiState by quizHubViewModel.uiState.collectAsStateWithLifecycle()

    val settingsViewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.Factory(
            container.userPrefsStore,
            container.componentRepository,
            container.academyRepository,
            container.quizRepository
        )
    )
    val settingsUiState by settingsViewModel.uiState.collectAsStateWithLifecycle()

    val labViewModel: LabWorkspaceViewModel = viewModel(
        factory = LabWorkspaceViewModel.Factory(
            container.labProjectRepository,
            container.userPrefsStore
        )
    )
    val labUiState by labViewModel.uiState.collectAsStateWithLifecycle()
    val hideChrome = isDetailRoute || (currentRoute == ROUTE_LAB && labUiState.isFullScreen)

    fun navigateTop(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun openComponent(id: String) {
        navController.navigate("component/$id") {
            launchSingleTop = true
        }
    }

    fun openCourse(course: AcademyCourse) {
        navController.navigate("course/${course.id}") {
            launchSingleTop = true
        }
    }

    fun openLesson(lessonId: String) {
        navController.navigate("lesson/$lessonId") {
            launchSingleTop = true
        }
    }

    fun startQuizSession(courseId: String, timedExam: Boolean) {
        navController.navigate("quiz_run/$courseId/$timedExam") {
            launchSingleTop = true
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = if (hideChrome) WindowInsets(0, 0, 0, 0) else WindowInsets.statusBars,
            bottomBar = {
                if (!hideChrome && !useRail) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        topDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTop(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = dest.icon,
                                        contentDescription = dest.label(language)
                                    )
                                },
                                label = { Text(dest.label(language), maxLines = 1) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!hideChrome && useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        topDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTop(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = dest.icon,
                                        contentDescription = dest.label(language)
                                    )
                                },
                                label = { Text(dest.label(language), maxLines = 1) },
                                modifier = Modifier.testTag("${dest.testTag}_rail")
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_BOOK,
                    modifier = Modifier.weight(1f).fillMaxSize()
                ) {
                    composable(ROUTE_BOOK) {
                        BookHomeScreen(
                            uiState = bookUiState,
                            isDarkTheme = isDarkTheme,
                            onToggleTheme = { appViewModel.setDarkTheme(!isDarkTheme) },
                            onToggleLanguage = {
                                val next = if (language == AppLanguage.ENGLISH) AppLanguage.BANGLA else AppLanguage.ENGLISH
                                appViewModel.setLanguage(next)
                            },
                            onSearchQueryChange = bookViewModel::updateSearchQuery,
                            onOpenCategory = { category ->
                                bookViewModel.selectCategory(category)
                                navigateTop(ROUTE_LIBRARY)
                            },
                            onBrowseAll = {
                                bookViewModel.selectCategory(null)
                                navigateTop(ROUTE_LIBRARY)
                            },
                            onOpenSaved = { navigateTop(ROUTE_SAVED) },
                            onOpenComponent = ::openComponent,
                            onToggleBookmark = bookViewModel::toggleBookmark
                        )
                    }

                    composable(ROUTE_ACADEMY) {
                        AcademyHomeScreen(
                            uiState = academyUiState,
                            onSearchQueryChange = academyViewModel::updateSearchQuery,
                            onOpenCourse = ::openCourse,
                            onOpenLesson = ::openLesson,
                            onStartMasterExam = { startQuizSession("ALL", true) },
                            onOpenCourseQuiz = { course -> startQuizSession(course.id, false) }
                        )
                    }

                    composable(ROUTE_LAB) {
                        VirtualLabScreen(
                            uiState = labUiState,
                            isDarkTheme = isDarkTheme,
                            viewModel = labViewModel
                        )
                    }

                    composable(ROUTE_LIBRARY) {
                        LibraryScreen(
                            uiState = bookUiState,
                            onSearchQueryChange = bookViewModel::updateSearchQuery,
                            onSelectCategory = bookViewModel::selectCategory,
                            onUpdateSortOrder = bookViewModel::updateSortOrder,
                            onOpenComponent = ::openComponent,
                            onToggleBookmark = bookViewModel::toggleBookmark
                        )
                    }

                    composable(ROUTE_QUIZ) {
                        QuizHubScreen(
                            uiState = quizHubUiState,
                            onStartQuiz = ::startQuizSession
                        )
                    }

                    composable(ROUTE_SAVED) {
                        SavedScreen(
                            uiState = bookUiState,
                            onOpenComponent = ::openComponent,
                            onToggleBookmark = bookViewModel::toggleBookmark
                        )
                    }

                    composable(ROUTE_SETTINGS) {
                        SettingsScreen(
                            uiState = settingsUiState,
                            onSetDarkTheme = appViewModel::setDarkTheme,
                            onSetLanguage = appViewModel::setLanguage
                        )
                    }

                    composable(
                        route = ROUTE_COMPONENT_DETAIL,
                        arguments = listOf(navArgument("componentId") { type = NavType.StringType })
                    ) { entry ->
                        val componentId = entry.arguments?.getString("componentId").orEmpty()
                        val detailVm: ComponentDetailViewModel = viewModel(
                            key = "detail_$componentId",
                            factory = ComponentDetailViewModel.Factory(
                                componentId = componentId,
                                repository = container.componentRepository,
                                prefsStore = container.userPrefsStore
                            )
                        )
                        val detailState by detailVm.uiState.collectAsStateWithLifecycle()
                        ComponentDetailScreen(
                            uiState = detailState,
                            onBack = { navController.popBackStack() },
                            onToggleBookmark = detailVm::toggleBookmark,
                            onToggleStudied = detailVm::toggleStudied,
                            onSetAdvancedMode = detailVm::setAdvancedMode,
                            onOpenRelated = ::openComponent
                        )
                    }

                    composable(
                        route = ROUTE_COURSE,
                        arguments = listOf(navArgument("courseId") { type = NavType.StringType })
                    ) { entry ->
                        val courseId = entry.arguments?.getString("courseId").orEmpty()
                        val course = AcademyCourse.fromId(courseId)
                        CourseDetailScreen(
                            course = course,
                            uiState = academyUiState,
                            onBack = { navController.popBackStack() },
                            onOpenLesson = ::openLesson,
                            onToggleBookmark = academyViewModel::toggleBookmark,
                            onStartQuiz = { timed -> startQuizSession(course.id, timed) }
                        )
                    }

                    composable(
                        route = ROUTE_LESSON,
                        arguments = listOf(navArgument("lessonId") { type = NavType.StringType })
                    ) { entry ->
                        val lessonId = entry.arguments?.getString("lessonId").orEmpty()
                        val lessonVm: LessonDetailViewModel = viewModel(
                            key = "lesson_$lessonId",
                            factory = LessonDetailViewModel.Factory(
                                lessonId = lessonId,
                                academyRepository = container.academyRepository,
                                componentRepository = container.componentRepository,
                                prefsStore = container.userPrefsStore
                            )
                        )
                        val lessonState by lessonVm.uiState.collectAsStateWithLifecycle()
                        LessonDetailScreen(
                            uiState = lessonState,
                            onBack = { navController.popBackStack() },
                            onSelectLevel = lessonVm::selectLevel,
                            onToggleBookmark = lessonVm::toggleBookmark,
                            onToggleCompleted = lessonVm::toggleCompleted,
                            onSaveNote = lessonVm::saveNote,
                            onClearNoteFeedback = lessonVm::clearNoteFeedback,
                            onOpenRelatedComponent = ::openComponent,
                            onOpenNextLesson = { nextId ->
                                navController.navigate("lesson/$nextId") {
                                    popUpTo("lesson/$lessonId") { inclusive = true }
                                    launchSingleTop = true
                                }
                            }
                        )
                    }

                    composable(
                        route = ROUTE_QUIZ_RUN,
                        arguments = listOf(
                            navArgument("courseId") { type = NavType.StringType },
                            navArgument("timed") { type = NavType.BoolType }
                        )
                    ) { entry ->
                        val courseId = entry.arguments?.getString("courseId") ?: "ALL"
                        val timed = entry.arguments?.getBoolean("timed") ?: false
                        val runnerVm: QuizRunnerViewModel = viewModel(
                            key = "quiz_${courseId}_$timed",
                            factory = QuizRunnerViewModel.Factory(
                                courseId = courseId,
                                isTimedExam = timed,
                                quizRepository = container.quizRepository,
                                prefsStore = container.userPrefsStore
                            )
                        )
                        val runnerState by runnerVm.uiState.collectAsStateWithLifecycle()
                        QuizRunnerScreen(
                            uiState = runnerState,
                            onBack = { navController.popBackStack() },
                            onSelectAnswer = runnerVm::selectAnswer,
                            onNextQuestion = runnerVm::nextQuestion,
                            onPrevQuestion = runnerVm::prevQuestion,
                            onSubmitQuiz = runnerVm::submitQuiz,
                            onToggleReviewIncorrect = runnerVm::toggleReviewIncorrectOnly,
                            onRetakeQuiz = runnerVm::retakeQuiz
                        )
                    }
                }
            }
        }
    }
}
