package com.example.ui.academy

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.localization.AcademyStrings
import com.example.core.localization.AppLanguage
import com.example.domain.model.ExplanationLevel
import com.example.ui.components.CircuitSymbolCanvas
import com.example.ui.components.ComponentIllustrationCanvas
import com.example.ui.components.ConnectionDiagramCanvas

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonDetailScreen(
    uiState: LessonDetailUiState,
    onBack: () -> Unit,
    onSelectLevel: (ExplanationLevel) -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleCompleted: () -> Unit,
    onSaveNote: (String) -> Unit,
    onClearNoteFeedback: () -> Unit,
    onOpenRelatedComponent: (String) -> Unit,
    onOpenNextLesson: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val lesson = uiState.lesson
    val lang = uiState.language
    var visualTab by rememberSaveable(lesson?.id ?: "") { mutableIntStateOf(0) }
    var showVirtualLabModal by rememberSaveable { mutableStateOf(false) }
    var noteDraft by rememberSaveable(lesson?.id ?: "") { mutableStateOf(uiState.noteText) }

    LaunchedEffect(uiState.noteText) {
        if (noteDraft.isEmpty() && uiState.noteText.isNotEmpty()) {
            noteDraft = uiState.noteText
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = lesson?.title(lang) ?: "",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(48.dp).testTag("lesson_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to course")
                    }
                },
                actions = {
                    if (lesson != null) {
                        IconButton(
                            onClick = onToggleBookmark,
                            modifier = Modifier.size(48.dp).testTag("lesson_bookmark_button")
                        ) {
                            Icon(
                                imageVector = if (lesson.isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                contentDescription = "Toggle bookmark",
                                tint = if (lesson.isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        IconButton(
                            onClick = onToggleCompleted,
                            modifier = Modifier.size(48.dp).testTag("lesson_complete_top_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = AcademyStrings.markLessonComplete(lang, lesson.isCompleted),
                                tint = if (lesson.isCompleted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        if (lesson == null) {
            Box(
                modifier = Modifier.fillMaxSize().padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text(if (uiState.isLoading) "Loading lesson..." else "Lesson not found.")
            }
            return@Scaffold
        }

        val payload = lesson.payload

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 860.dp)
                    .testTag("lesson_detail_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Badge & Title
                item(key = "header") {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "${lesson.course.courseNumber}. ${lesson.course.title(lang)} • #${payload.orderIndex}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = lesson.title(lang),
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) payload.titleBn else payload.titleEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // 3 Explanation Level Selector
                item(key = "level_selector") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val levels = listOf(
                            Triple(ExplanationLevel.BEGINNER, AcademyStrings.levelBeginner(lang), "level_beginner_button"),
                            Triple(ExplanationLevel.INTERMEDIATE, AcademyStrings.levelIntermediate(lang), "level_intermediate_button"),
                            Triple(ExplanationLevel.ADVANCED, AcademyStrings.levelAdvanced(lang), "level_advanced_button")
                        )
                        levels.forEach { (lvl, label, tag) ->
                            val selected = uiState.selectedLevel == lvl
                            Surface(
                                onClick = { onSelectLevel(lvl) },
                                shape = MaterialTheme.shapes.small,
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(
                                    1.5.dp,
                                    if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag(tag)
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 8.dp)) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                // 3-Tab Visual Plate (Illustration / Schematic Symbol / Circuit Diagram)
                item(key = "visual_plate") {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column {
                            TabRow(selectedTabIndex = visualTab) {
                                val tabTitles = listOf(
                                    if (lang == AppLanguage.BANGLA) "চিত্র" else "Visual",
                                    if (lang == AppLanguage.BANGLA) "প্রতীক" else "Symbol",
                                    if (lang == AppLanguage.BANGLA) "সার্কিট" else "Circuit"
                                )
                                tabTitles.forEachIndexed { idx, t ->
                                    Tab(
                                        selected = visualTab == idx,
                                        onClick = { visualTab = idx },
                                        text = { Text(t, maxLines = 1) },
                                        modifier = Modifier.testTag("lesson_visual_tab_$idx")
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .padding(14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                when (visualTab) {
                                    0 -> ComponentIllustrationCanvas(illustrationType = payload.illustrationType)
                                    1 -> CircuitSymbolCanvas(symbolType = payload.symbolType)
                                    else -> ConnectionDiagramCanvas(diagramType = payload.circuitDiagramType, language = lang)
                                }
                            }
                        }
                    }
                }

                // Virtual Lab Interactive Preview Launch Button (only when preset exists)
                if (payload.virtualLabCircuitId != null) {
                    item(key = "virtual_lab_cta") {
                        FilledTonalButton(
                            onClick = { showVirtualLabModal = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("open_virtual_lab_button")
                        ) {
                            Icon(Icons.Rounded.Science, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(AcademyStrings.openVirtualLab(lang))
                        }
                    }
                }

                // 1. Introduction & Level Explanation
                item(key = "intro_and_level_explanation") {
                    LessonSectionCard(
                        title = if (lang == AppLanguage.BANGLA) "পাঠ পরিচিতি ও বিশ্লেষণ" else "Introduction & Core Concept"
                    ) {
                        Text(lesson.introduction(lang), style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = when (uiState.selectedLevel) {
                                        ExplanationLevel.BEGINNER -> AcademyStrings.levelBeginner(lang)
                                        ExplanationLevel.INTERMEDIATE -> AcademyStrings.levelIntermediate(lang)
                                        ExplanationLevel.ADVANCED -> AcademyStrings.levelAdvanced(lang)
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = lesson.explanation(uiState.selectedLevel, lang),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = lesson.simpleExplanation(lang),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // 2. Bilingual Technical Terms (EN ↔ BN)
                if (payload.englishBanglaTerms.isNotEmpty()) {
                    item(key = "terms_section") {
                        LessonSectionCard(
                            title = if (lang == AppLanguage.BANGLA) "প্রযুক্তিগত শব্দ ও বাংলা অর্থ" else "Key Technical Terms (EN ↔ BN)"
                        ) {
                            payload.englishBanglaTerms.forEach { term ->
                                Surface(
                                    shape = MaterialTheme.shapes.small,
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            text = "${term.termEn} — ${term.meaningBn}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(term.definition(lang), style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Real-Life Analogies & Working Principle
                item(key = "analogies_and_working") {
                    LessonSectionCard(
                        title = if (lang == AppLanguage.BANGLA) "বাস্তব উদাহরণ ও কার্যপ্রণালী" else "Real-Life Analogies & Working Principle",
                        icon = Icons.Rounded.Lightbulb
                    ) {
                        lesson.analogies(lang).forEach { line ->
                            Text("• $line", style = MaterialTheme.typography.bodyMedium)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = if (lang == AppLanguage.BANGLA) "কার্যপ্রণালী:" else "Working Principle:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(lesson.workingPrinciple(lang), style = MaterialTheme.typography.bodyMedium)
                    }
                }

                // 4. Interactive Visual Animation
                item(key = "interactive_anim") {
                    InteractiveAnimationCard(animationType = payload.animationType, language = lang)
                }

                // 5. Embedded Live Calculator
                if (payload.calculatorType != null) {
                    item(key = "interactive_calc") {
                        InteractiveCalculatorCard(calculatorType = payload.calculatorType, language = lang)
                    }
                }

                // 6. Specifications, Formulas & Step-by-Step Worked Examples
                item(key = "specs_formulas_calc") {
                    LessonSectionCard(
                        title = if (lang == AppLanguage.BANGLA) "সূত্র ও ধাপে ধাপে গাণিতিক সমাধান" else "Specifications, Formulas & Worked Math",
                        icon = Icons.Rounded.Functions
                    ) {
                        payload.technicalSpecs.forEach { spec ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(spec.label(lang), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(spec.value, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        payload.importantFormulas.forEach { f ->
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(f.formula, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.secondary)
                                    Text(f.meaning(lang), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        payload.stepByStepCalculations.forEach { ex ->
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(ex.problem(lang), style = MaterialTheme.typography.titleSmall)
                                    ex.steps(lang).forEach { s ->
                                        Text(s, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(
                                        text = if (lang == AppLanguage.BANGLA) "উত্তর: ${ex.answer}" else "Answer: ${ex.answer}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.tertiary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 7. Practical Experiments
                if (payload.practicalExperiments.isNotEmpty()) {
                    item(key = "practical_experiments") {
                        LessonSectionCard(
                            title = if (lang == AppLanguage.BANGLA) "হাতে-কলমে প্র্যাকটিক্যাল পরীক্ষা" else "Practical Hands-On Experiments"
                        ) {
                            payload.practicalExperiments.forEach { exp ->
                                Text(exp.title(lang), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = exp.parts(lang).joinToString(" • "),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                exp.steps(lang).forEach { st ->
                                    Text(st, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }

                // 8. Common Mistakes, Troubleshooting & Summary
                item(key = "mistakes_troubleshooting_summary") {
                    LessonSectionCard(
                        title = if (lang == AppLanguage.BANGLA) "সাধারণ ভুল, সমাধান ও সারসংক্ষেপ" else "Mistakes, Troubleshooting & Summary",
                        icon = Icons.Rounded.WarningAmber
                    ) {
                        lesson.commonMistakes(lang).forEach { m ->
                            Text("✕ $m", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                        lesson.troubleshooting(lang).forEach { t ->
                            Text("✓ $t", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                        }
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = lesson.summary(lang),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }

                // 9. Inline Knowledge Checks
                if (payload.inlineChecks.isNotEmpty()) {
                    item(key = "inline_checks_header") {
                        Text(
                            text = if (lang == AppLanguage.BANGLA) "পাঠ যাচাই (Self-Check)" else "Quick Knowledge Check",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(payload.inlineChecks, key = { "chk_${it.id}" }) { q ->
                        InlineKnowledgeCheckCard(question = q, language = lang)
                    }
                }

                // 10. Related Components from Book Encyclopedia (safely resolved)
                if (uiState.relatedComponents.isNotEmpty()) {
                    item(key = "related_components") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = if (lang == AppLanguage.BANGLA) "সম্পর্কিত কম্পোনেন্টসমূহ" else "Related Components in Textbook",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                uiState.relatedComponents.forEach { comp ->
                                    OutlinedButton(
                                        onClick = { onOpenRelatedComponent(comp.id) },
                                        modifier = Modifier.heightIn(min = 48.dp).testTag("related_comp_${comp.id}")
                                    ) {
                                        Text(comp.name(lang))
                                    }
                                }
                            }
                        }
                    }
                }

                // 11. Personal Study Notes
                item(key = "personal_notes") {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.EditNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(AcademyStrings.personalNotesTitle(lang), style = MaterialTheme.typography.titleMedium)
                            }
                            OutlinedTextField(
                                value = noteDraft,
                                onValueChange = {
                                    noteDraft = it
                                    if (uiState.noteSavedFeedback) onClearNoteFeedback()
                                },
                                placeholder = {
                                    Text(if (lang == AppLanguage.BANGLA) "আপনার ব্যক্তিগত নোট বা সূত্র লিখুন..." else "Write formulas, lab measurements, or key reminders...")
                                },
                                minLines = 3,
                                modifier = Modifier.fillMaxWidth().testTag("lesson_note_input")
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (uiState.noteSavedFeedback) {
                                    Text(
                                        text = if (lang == AppLanguage.BANGLA) "নোট সংরক্ষিত হয়েছে" else "Saved offline",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                } else {
                                    Spacer(Modifier.width(4.dp))
                                }
                                Button(
                                    onClick = { onSaveNote(noteDraft) },
                                    modifier = Modifier.heightIn(min = 48.dp).testTag("save_note_button")
                                ) {
                                    Text(AcademyStrings.saveNote(lang))
                                }
                            }
                        }
                    }
                }

                // 12. Lesson Completion & Next Lesson Navigation
                item(key = "completion_footer") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onToggleCompleted,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (lesson.isCompleted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("lesson_complete_button")
                        ) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(AcademyStrings.markLessonComplete(lang, lesson.isCompleted), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }

                        uiState.nextLesson?.let { nxt ->
                            FilledTonalButton(
                                onClick = { onOpenNextLesson(nxt.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("next_lesson_button")
                            ) {
                                Text(AcademyStrings.nextLesson(lang), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.width(6.dp))
                                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    val labCircuitId = lesson?.payload?.virtualLabCircuitId
    if (showVirtualLabModal && lesson != null && labCircuitId != null) {
        VirtualLabPreviewSheet(
            circuitId = labCircuitId,
            lessonTitle = lesson.title(lang),
            language = lang,
            onDismiss = { showVirtualLabModal = false }
        )
    }
}

@Composable
private fun LessonSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    content: @Composable () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            content()
        }
    }
}
