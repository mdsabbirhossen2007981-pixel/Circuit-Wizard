package com.example.ui.lab

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.RotateRight
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.localization.AppLanguage
import com.example.core.localization.LabStrings
import com.example.data.repository.SavedLabProjectSummary
import com.example.domain.lab.LabComponentCatalog
import com.example.domain.model.LabCategory
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabInstrumentState
import com.example.domain.model.LabInstrumentType
import com.example.domain.model.LabWire
import com.example.domain.model.LabWireColor
import com.example.domain.model.PlacedComponent
import com.example.domain.model.WireRouteStyle
import com.example.simulation.CircuitMnaSolver
import com.example.simulation.ComponentSupportLevel
import com.example.simulation.NetlistExtractor
import com.example.simulation.OscilloscopeSample
import com.example.simulation.SafetySeverity
import com.example.simulation.SimulationResult
import com.example.simulation.SimulationStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun LabComponentLibraryPanel(
    searchQuery: String,
    selectedCategory: LabCategory?,
    language: AppLanguage,
    onSearchChange: (String) -> Unit,
    onSelectCategory: (LabCategory?) -> Unit,
    onPlaceComponent: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val filtered = remember(searchQuery, selectedCategory) {
        LabComponentCatalog.all.filter { def ->
            val catMatch = selectedCategory == null || def.category == selectedCategory
            val q = searchQuery.trim().lowercase()
            val textMatch = q.isEmpty() ||
                def.nameEn.lowercase().contains(q) ||
                def.nameBn.lowercase().contains(q) ||
                def.category.titleEn.lowercase().contains(q) ||
                def.typeId.lowercase().contains(q)
            catMatch && textMatch
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("lab_library_panel"),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (language == AppLanguage.BANGLA) "কম্পোনেন্ট লাইব্রেরি (${filtered.size})" else "Component Library (${filtered.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onClose, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close library")
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text(LabStrings.searchPartsHint(language), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("lab_part_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                item(key = "cat_all") {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { onSelectCategory(null) },
                        label = { Text(if (language == AppLanguage.BANGLA) "সব (${LabCategory.entries.size})" else "All (${LabCategory.entries.size})") },
                        modifier = Modifier.testTag("lab_cat_all")
                    )
                }
                items(LabCategory.entries, key = { it.id }) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { onSelectCategory(if (selectedCategory == cat) null else cat) },
                        label = { Text(cat.title(language)) },
                        modifier = Modifier.testTag("lab_cat_${cat.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 280.dp)
                    .testTag("lab_catalog_list"),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filtered, key = { it.typeId }) { def ->
                    Surface(
                        onClick = { onPlaceComponent(def.typeId) },
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("lab_catalog_item_${def.typeId}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = def.name(language),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${def.category.title(language)} • ${def.pins.size} pins • ${if (def.snapToBreadboard) "Breadboard" else "Benchtop"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Rounded.Add,
                                        contentDescription = "Place ${def.nameEn}",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (language == AppLanguage.BANGLA) "রাখুন" else "Place",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LabPropertyInspectorPanel(
    selectedComponents: List<PlacedComponent>,
    selectedWire: LabWire?,
    activeWireColor: LabWireColor,
    activeWireStyle: WireRouteStyle,
    language: AppLanguage,
    simulationResult: SimulationResult = SimulationResult(),
    simulationStatus: SimulationStatus = SimulationStatus.STOPPED,
    onUpdateComponentProps: (String, Map<String, String>) -> Unit,
    onRotateSelected: () -> Unit,
    onDuplicateSelected: () -> Unit,
    onDeleteSelected: () -> Unit,
    onSelectWireColor: (LabWireColor) -> Unit,
    onSelectWireStyle: (WireRouteStyle) -> Unit,
    onUpdateWireBend: (String, Float) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("lab_properties_panel"),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .heightIn(max = 360.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LabStrings.properties(language),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onClose, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close properties")
                }
            }

            if (selectedComponents.size == 1) {
                val comp = selectedComponents.first()
                val def = LabComponentCatalog.find(comp.typeId)
                Text(
                    text = "${def?.name(language) ?: comp.typeId} (${comp.rotationDeg}°)",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )

                // Quick Component Actions
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRotateSelected, modifier = Modifier.weight(1f)) {
                        Icon(Icons.AutoMirrored.Rounded.RotateRight, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(LabStrings.rotate(language))
                    }
                    OutlinedButton(onClick = onDuplicateSelected, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(LabStrings.duplicate(language))
                    }
                    Button(
                        onClick = onDeleteSelected,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(LabStrings.toolDelete(language))
                    }
                }

                HorizontalDivider()

                if (simulationStatus != SimulationStatus.STOPPED) {
                    val reading = simulationResult.componentReadings[comp.instanceId]
                    if (reading != null) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("prop_live_telemetry")
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "Calculated Operating Point",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "Voltage Drop: ${"%.3f".format(reading.voltageDropV)} V  |  Current: ${"%.2f".format(reading.currentMa)} mA",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "Power: ${"%.2f".format(reading.powerMw)} mW" +
                                        (if (reading.motorRpm > 0f) "  |  RPM: ${reading.motorRpm.roundToInt()}" else "") +
                                        (if (reading.isFloating) "  |  FLOATING" else ""),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }

                ComponentPropertyFields(
                    comp = comp,
                    onUpdate = { newProps -> onUpdateComponentProps(comp.instanceId, newProps) }
                )
            } else if (selectedComponents.size > 1) {
                Text(
                    text = "${selectedComponents.size} components selected (Multi-Select)",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRotateSelected, modifier = Modifier.weight(1f)) {
                        Text(LabStrings.rotate(language))
                    }
                    OutlinedButton(onClick = onDuplicateSelected, modifier = Modifier.weight(1f)) {
                        Text(LabStrings.duplicate(language))
                    }
                    Button(
                        onClick = onDeleteSelected,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(LabStrings.toolDelete(language))
                    }
                }
            } else if (selectedWire != null) {
                val activeColor = LabWireColor.entries.firstOrNull { it.key == selectedWire.colorKey } ?: activeWireColor
                val activeStyle = runCatching { WireRouteStyle.valueOf(selectedWire.routeStyle) }.getOrDefault(activeWireStyle)
                Text(
                    text = "Wire (${selectedWire.id.takeLast(6)})",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                WireStyleControls(
                    currentColor = activeColor,
                    currentStyle = activeStyle,
                    bendOffset = selectedWire.bendOffset,
                    language = language,
                    onSelectColor = onSelectWireColor,
                    onSelectStyle = onSelectWireStyle,
                    onChangeBend = { onUpdateWireBend(selectedWire.id, it) }
                )
                Button(
                    onClick = onDeleteSelected,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Delete Wire")
                }
            } else {
                Text(
                    text = if (language == AppLanguage.BANGLA) {
                        "বিস্তারিত সম্পাদনা করতে একটি কম্পোনেন্ট বা তার নির্বাচন করুন। নিচে নতুন তারের ডিফল্ট সেটিং:"
                    } else {
                        "Select a component or wire on the workbench to inspect & edit its properties. Default Wire Style:"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                WireStyleControls(
                    currentColor = activeWireColor,
                    currentStyle = activeWireStyle,
                    bendOffset = null,
                    language = language,
                    onSelectColor = onSelectWireColor,
                    onSelectStyle = onSelectWireStyle,
                    onChangeBend = {}
                )
            }
        }
    }
}

@Composable
private fun ComponentPropertyFields(
    comp: PlacedComponent,
    onUpdate: (Map<String, String>) -> Unit
) {
    val props = comp.properties
    when (comp.typeId) {
        "resistor" -> {
            val value = props["value"] ?: "330"
            val unit = props["unit"] ?: "Ω"
            val bands = computeFourBandColors(value, unit)
            OutlinedTextField(
                value = value,
                onValueChange = { onUpdate(props + ("value" to it.filter { ch -> ch.isDigit() || ch == '.' })) },
                label = { Text("Resistance Value") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("prop_resistor_value_input")
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Ω", "kΩ", "MΩ").forEach { u ->
                    FilterChip(
                        selected = unit == u,
                        onClick = { onUpdate(props + ("unit" to u)) },
                        label = { Text(u) },
                        modifier = Modifier.testTag("prop_unit_$u")
                    )
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("4-Band Code:", style = MaterialTheme.typography.labelMedium)
                bands.forEach { c ->
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                    )
                }
            }
        }
        "potentiometer" -> {
            val value = props["value"] ?: "10"
            val unit = props["unit"] ?: "kΩ"
            val wiper = (props["wiperPct"]?.toFloatOrNull() ?: 50f).coerceIn(0f, 100f)
            OutlinedTextField(
                value = value,
                onValueChange = { onUpdate(props + ("value" to it.filter { ch -> ch.isDigit() || ch == '.' })) },
                label = { Text("Total Resistance ($unit)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Wiper Position: ${wiper.roundToInt()}%", style = MaterialTheme.typography.labelMedium)
            Slider(
                value = wiper,
                onValueChange = { onUpdate(props + ("wiperPct" to it.roundToInt().toString())) },
                valueRange = 0f..100f
            )
        }
        "cap_ceramic", "cap_electrolytic" -> {
            val capVal = props["capacitance"] ?: "100"
            val unit = props["unit"] ?: "µF"
            val vRating = props["voltageRating"] ?: "25V"
            val capType = props["capType"] ?: "Electrolytic"
            OutlinedTextField(
                value = capVal,
                onValueChange = { onUpdate(props + ("capacitance" to it.filter { ch -> ch.isDigit() || ch == '.' })) },
                label = { Text("Capacitance") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("pF", "nF", "µF").forEach { u ->
                    FilterChip(selected = unit == u, onClick = { onUpdate(props + ("unit" to u)) }, label = { Text(u) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("10V", "25V", "50V").forEach { vr ->
                    FilterChip(selected = vRating == vr, onClick = { onUpdate(props + ("voltageRating" to vr)) }, label = { Text(vr) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Ceramic", "Electrolytic", "Film").forEach { t ->
                    FilterChip(selected = capType == t, onClick = { onUpdate(props + ("capType" to t)) }, label = { Text(t) })
                }
            }
        }
        "battery_9v", "battery_aa" -> {
            val volts = props["voltage"] ?: "9.0"
            val pol = props["polarity"] ?: "Normal"
            OutlinedTextField(
                value = volts,
                onValueChange = { onUpdate(props + ("voltage" to it.filter { ch -> ch.isDigit() || ch == '.' })) },
                label = { Text("Battery Voltage (V)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Normal", "Reversed").forEach { p ->
                    FilterChip(selected = pol == p, onClick = { onUpdate(props + ("polarity" to p)) }, label = { Text("Polarity: $p") })
                }
            }
        }
        "led_5mm" -> {
            val color = props["color"] ?: "Red"
            val vf = props["vf"] ?: "2.0"
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                listOf("Red" to "2.0", "Green" to "2.2", "Yellow" to "2.1", "Blue" to "3.1", "White" to "3.2").forEach { (c, defaultVf) ->
                    FilterChip(
                        selected = color == c,
                        onClick = { onUpdate(props + ("color" to c) + ("vf" to defaultVf)) },
                        label = { Text(c) },
                        modifier = Modifier.testTag("prop_led_color_$c")
                    )
                }
            }
            OutlinedTextField(
                value = vf,
                onValueChange = { onUpdate(props + ("vf" to it.filter { ch -> ch.isDigit() || ch == '.' })) },
                label = { Text("Forward Voltage Vf (V)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        "slide_switch", "pushbutton" -> {
            val isOn = props["state"] == "ON"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Switch State: ${if (isOn) "ON (Closed)" else "OFF (Open)"}", style = MaterialTheme.typography.titleSmall)
                Switch(
                    checked = isOn,
                    onCheckedChange = { checked -> onUpdate(props + ("state" to if (checked) "ON" else "OFF")) },
                    modifier = Modifier.testTag("prop_switch_toggle")
                )
            }
        }
        "dc_psu" -> {
            val v = props["voltage"] ?: "5.0"
            val curr = props["currentLimit"] ?: "1.5"
            OutlinedTextField(
                value = v,
                onValueChange = { onUpdate(props + ("voltage" to it.filter { ch -> ch.isDigit() || ch == '.' })) },
                label = { Text("Output Voltage (V)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = curr,
                onValueChange = { onUpdate(props + ("currentLimit" to it.filter { ch -> ch.isDigit() || ch == '.' })) },
                label = { Text("Current Limit (A)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        else -> {
            props.forEach { (k, v) ->
                OutlinedTextField(
                    value = v,
                    onValueChange = { newVal -> onUpdate(props + (k to newVal)) },
                    label = { Text(k.replaceFirstChar { it.uppercase() }) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun WireStyleControls(
    currentColor: LabWireColor,
    currentStyle: WireRouteStyle,
    bendOffset: Float?,
    language: AppLanguage,
    onSelectColor: (LabWireColor) -> Unit,
    onSelectStyle: (WireRouteStyle) -> Unit,
    onChangeBend: (Float) -> Unit
) {
    Text("Wire Color", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
    ) {
        LabWireColor.entries.forEach { wc ->
            val selected = wc == currentColor
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(wc.argb))
                    .border(
                        width = if (selected) 3.dp else 1.dp,
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        shape = CircleShape
                    )
                    .clickable { onSelectColor(wc) }
                    .testTag("wire_color_${wc.key}")
            )
        }
    }

    Text("Wire Routing Geometry", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        WireRouteStyle.entries.forEach { st ->
            FilterChip(
                selected = st == currentStyle,
                onClick = { onSelectStyle(st) },
                label = { Text(if (language == AppLanguage.BANGLA) st.labelBn else st.labelEn) },
                modifier = Modifier.testTag("wire_style_${st.name}")
            )
        }
    }

    if (bendOffset != null) {
        Text("Wire Arch Height: ${(bendOffset * 100).roundToInt()}%", style = MaterialTheme.typography.labelMedium)
        Slider(
            value = bendOffset,
            onValueChange = onChangeBend,
            valueRange = 0.2f..2.2f
        )
    }
}

@Composable
fun LabInstrumentsPanel(
    snapshot: LabCircuitSnapshot,
    simulationResult: SimulationResult,
    simulationStatus: SimulationStatus,
    oscilloscopeSamples: List<OscilloscopeSample>,
    language: AppLanguage,
    onUpdateInstrument: (LabInstrumentState) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val probeOptions = remember(snapshot) { CircuitMnaSolver.buildProbeOptions(snapshot) }
    val labelForKey = remember(probeOptions) { probeOptions.associate { it.key to it.label } }
    val isSimActive = simulationStatus != SimulationStatus.STOPPED

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("lab_instruments_panel"),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .heightIn(max = 400.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (language == AppLanguage.BANGLA) "পরিমাপ যন্ত্র ও প্রোব" else "Measurement Instruments",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isSimActive) "Live MNA Calculated Values • t=${"%.2f".format(simulationResult.simTimeSec)}s"
                        else LabStrings.phase4Pending(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(onClick = onClose, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close instruments")
                }
            }

            LabInstrumentType.entries.forEach { type ->
                val state = snapshot.instruments.firstOrNull { it.type == type.name }
                    ?: LabInstrumentState(type = type.name, mode = if (type == LabInstrumentType.DIGITAL_MULTIMETER) "VDC" else type.name)

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("instrument_card_${type.name}")
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = type.title(language),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Switch(
                                checked = state.isEnabled,
                                onCheckedChange = { onUpdateInstrument(state.copy(isEnabled = it)) },
                                modifier = Modifier.testTag("instrument_enable_${type.name}")
                            )
                        }

                        if (type == LabInstrumentType.DIGITAL_MULTIMETER) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.horizontalScroll(rememberScrollState())
                            ) {
                                listOf("VDC", "mA", "Ω", "Cont").forEach { m ->
                                    FilterChip(
                                        selected = state.mode == m,
                                        onClick = { onUpdateInstrument(state.copy(mode = m)) },
                                        label = { Text(m) },
                                        modifier = Modifier.testTag("dmm_mode_$m")
                                    )
                                }
                            }
                        }

                        if (type == LabInstrumentType.DC_POWER_SUPPLY) {
                            Text(
                                text = "Output Monitor: ${"%.1f".format(state.voltageSetting)} V  |  Limit: ${"%.1f".format(state.currentLimit)} A",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Slider(
                                value = state.voltageSetting,
                                onValueChange = { onUpdateInstrument(state.copy(voltageSetting = (it * 10f).roundToInt() / 10f)) },
                                valueRange = 0f..30f
                            )
                        }

                        if (type == LabInstrumentType.OSCILLOSCOPE) {
                            val vPerDiv = state.voltsPerDiv.coerceAtLeast(0.5f)
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(84.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF061A24))
                                    .testTag("oscilloscope_canvas")
                            ) {
                                val stepX = size.width / 8f
                                val stepY = size.height / 4f
                                for (i in 1..7) {
                                    drawLine(Color(0xFF164E63), Offset(i * stepX, 0f), Offset(i * stepX, size.height), 1f)
                                }
                                for (j in 1..3) {
                                    drawLine(Color(0xFF164E63), Offset(0f, j * stepY), Offset(size.width, j * stepY), 1f)
                                }
                                val zeroY = size.height * 0.75f
                                drawLine(Color(0xFF0E7490), Offset(0f, zeroY), Offset(size.width, zeroY), 1.5f)

                                if (oscilloscopeSamples.size >= 2) {
                                    val path = Path()
                                    val maxIdx = (oscilloscopeSamples.size - 1).coerceAtLeast(1)
                                    val pxPerVolt = stepY / vPerDiv
                                    oscilloscopeSamples.forEachIndexed { idx, sample ->
                                        val x = (idx / maxIdx.toFloat()) * size.width
                                        val y = (zeroY - (sample.voltageV.toFloat() * pxPerVolt)).coerceIn(3f, size.height - 3f)
                                        if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                                    }
                                    drawPath(
                                        path = path,
                                        color = Color(0xFF22D3EE),
                                        style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                    )
                                } else if (oscilloscopeSamples.size == 1) {
                                    val pxPerVolt = stepY / vPerDiv
                                    val y = (zeroY - (oscilloscopeSamples[0].voltageV.toFloat() * pxPerVolt)).coerceIn(3f, size.height - 3f)
                                    drawLine(Color(0xFF22D3EE), Offset(0f, y), Offset(size.width, y), strokeWidth = 3f)
                                }
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.horizontalScroll(rememberScrollState())
                            ) {
                                listOf(1f, 2f, 5f).forEach { vDiv ->
                                    FilterChip(
                                        selected = kotlin.math.abs(state.voltsPerDiv - vDiv) < 0.05f,
                                        onClick = { onUpdateInstrument(state.copy(voltsPerDiv = vDiv)) },
                                        label = { Text("${vDiv.roundToInt()}V/div") }
                                    )
                                }
                                listOf(5f, 10f, 25f).forEach { msDiv ->
                                    FilterChip(
                                        selected = kotlin.math.abs(state.timebaseMs - msDiv) < 0.1f,
                                        onClick = { onUpdateInstrument(state.copy(timebaseMs = msDiv)) },
                                        label = { Text("${msDiv.roundToInt()}ms") }
                                    )
                                }
                            }
                            val scopeSummary = if (oscilloscopeSamples.isNotEmpty()) {
                                val vMin = oscilloscopeSamples.minOf { it.voltageV }
                                val vMax = oscilloscopeSamples.maxOf { it.voltageV }
                                val vNow = oscilloscopeSamples.last().voltageV
                                "CH1: ${"%.3f".format(vNow)} V (Min ${"%.2f".format(vMin)}V / Max ${"%.2f".format(vMax)}V)"
                            } else if (isSimActive) {
                                CircuitMnaSolver.evaluateInstrument(state, simulationResult, snapshot)
                            } else {
                                "Run simulation to sample real CH1 waveform"
                            }
                            Text(
                                text = scopeSummary,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else if (type != LabInstrumentType.DC_POWER_SUPPLY) {
                            val posLabel = state.positiveProbeKey?.let { labelForKey[it] ?: it } ?: "Unassigned"
                            val negLabel = state.negativeProbeKey?.let { labelForKey[it] ?: it } ?: "0V Ref"
                            Text("Probes: (+) $posLabel  (−) $negLabel", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            val readingText = when {
                                isSimActive -> CircuitMnaSolver.evaluateInstrument(state, simulationResult, snapshot)
                                type == LabInstrumentType.DIGITAL_MULTIMETER && state.mode == "Cont" -> {
                                    val staged = NetlistExtractor.stageNetlist(snapshot)
                                    val p = state.positiveProbeKey
                                    val n = state.negativeProbeKey
                                    if (p == null || n == null) "Attach (+) & (−) probes"
                                    else {
                                        val netP = staged.nets.firstOrNull { p in it.memberKeys }?.netId
                                        val netN = staged.nets.firstOrNull { n in it.memberKeys }?.netId
                                        if (netP != null && netP == netN) "BEEP • Continuous (0 Ω)" else "OL • Open Circuit"
                                    }
                                }
                                else -> "Tap Run to measure real circuit value"
                            }
                            Text(
                                text = "Reading: $readingText",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.testTag("instrument_reading_${type.name}")
                            )
                        }

                        if (probeOptions.isNotEmpty() && type != LabInstrumentType.DC_POWER_SUPPLY) {
                            Text("Assign (+) Probe:", style = MaterialTheme.typography.labelSmall)
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.horizontalScroll(rememberScrollState())
                            ) {
                                probeOptions.forEach { opt ->
                                    FilterChip(
                                        selected = state.positiveProbeKey == opt.key,
                                        onClick = { onUpdateInstrument(state.copy(positiveProbeKey = opt.key, isEnabled = true)) },
                                        label = { Text("+ ${opt.label}", maxLines = 1) }
                                    )
                                }
                            }
                            if (type != LabInstrumentType.AMMETER) {
                                Text("Assign (−) Ref Probe:", style = MaterialTheme.typography.labelSmall)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                ) {
                                    probeOptions.forEach { opt ->
                                        FilterChip(
                                            selected = state.negativeProbeKey == opt.key,
                                            onClick = { onUpdateInstrument(state.copy(negativeProbeKey = opt.key, isEnabled = true)) },
                                            label = { Text("− ${opt.label}", maxLines = 1) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LabSimulationReportDialog(
    simulationStatus: SimulationStatus,
    simulationResult: SimulationResult,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("lab_report_dialog"),
        title = { Text(if (language == AppLanguage.BANGLA) "সিমুলেশন রিপোর্ট ও মডেল সাপোর্ট" else "Simulation Report & Model Support") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "Solver: Modified Nodal Analysis (MNA + Newton-Raphson + Backward-Euler)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (simulationStatus == SimulationStatus.STOPPED) {
                                "Status: Stopped — Start Run to evaluate live operating point & warnings."
                            } else {
                                "t = ${"%.2f".format(simulationResult.simTimeSec)} s  •  Converged: ${simulationResult.converged} (${simulationResult.iterationsUsed} iter)"
                            },
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (simulationStatus != SimulationStatus.STOPPED && simulationResult.warnings.isNotEmpty()) {
                    Text("Circuit Diagnostics & Safety (${simulationResult.warnings.size})", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    simulationResult.warnings.forEach { w ->
                        val bg = when (w.severity) {
                            SafetySeverity.CRITICAL -> MaterialTheme.colorScheme.errorContainer
                            SafetySeverity.WARNING -> MaterialTheme.colorScheme.tertiaryContainer
                            SafetySeverity.INFO -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        val fg = when (w.severity) {
                            SafetySeverity.CRITICAL -> MaterialTheme.colorScheme.onErrorContainer
                            SafetySeverity.WARNING -> MaterialTheme.colorScheme.onTertiaryContainer
                            SafetySeverity.INFO -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = bg,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "[${w.category.name}] ${w.messageEn}",
                                style = MaterialTheme.typography.bodySmall,
                                color = fg,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                HorizontalDivider()

                Text("Offline Component Simulation Matrix", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                NetlistExtractor.componentSupportCatalog.forEach { info ->
                    val badgeColor = when (info.supportLevel) {
                        ComponentSupportLevel.FULLY_SIMULATED -> Color(0xFF065F46)
                        ComponentSupportLevel.PARTIALLY_SIMULATED -> Color(0xFF92400E)
                        ComponentSupportLevel.VISUAL_ONLY -> Color(0xFF334155)
                        ComponentSupportLevel.NOT_SUPPORTED -> Color(0xFF991B1B)
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(info.nameEn, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                Surface(shape = RoundedCornerShape(6.dp), color = badgeColor) {
                                    Text(
                                        text = info.supportLevel.labelEn,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(info.notesEn, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == AppLanguage.BANGLA) "বন্ধ" else "Close")
            }
        }
    )
}

@Composable
fun LabSaveProjectDialog(
    initialName: String,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onConfirmSave: (String) -> Unit
) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("lab_save_dialog"),
        title = { Text(if (language == AppLanguage.BANGLA) "সার্কিট প্রজেক্ট সংরক্ষণ" else "Save Lab Project") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(if (language == AppLanguage.BANGLA) "প্রজেক্টের নাম" else "Project Name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("lab_save_name_input")
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirmSave(name) },
                modifier = Modifier.testTag("lab_save_confirm_button")
            ) {
                Text(LabStrings.saveProject(language))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == AppLanguage.BANGLA) "বাতিল" else "Cancel")
            }
        }
    )
}

@Composable
fun LabLoadProjectDialog(
    savedProjects: List<SavedLabProjectSummary>,
    language: AppLanguage,
    onLoadProject: (Long) -> Unit,
    onDeleteProject: (Long) -> Unit,
    onLoadStarter: () -> Unit,
    onCreateBlank: () -> Unit,
    onDismiss: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("lab_load_dialog"),
        title = { Text(if (language == AppLanguage.BANGLA) "সার্কিট প্রজেক্ট লোড করুন" else "Load Lab Project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            onLoadStarter()
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("lab_load_starter_button")
                    ) {
                        Text("Starter LED", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = {
                            onCreateBlank()
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("lab_load_blank_button")
                    ) {
                        Text("Blank Board", maxLines = 1)
                    }
                }
                HorizontalDivider()
                if (savedProjects.isEmpty()) {
                    Text(
                        text = if (language == AppLanguage.BANGLA) "এখনও কোনো সংরক্ষিত সার্কিট নেই।" else "No saved circuits yet. Tap Save to store this workbench locally.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(savedProjects, key = { it.id }) { item ->
                            Surface(
                                onClick = { onLoadProject(item.id) },
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("lab_saved_item_${item.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${item.componentCount} parts • ${item.wireCount} wires • ${formatter.format(Date(item.updatedAt))}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { onDeleteProject(item.id) }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Delete saved project", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == AppLanguage.BANGLA) "বন্ধ" else "Close")
            }
        }
    )
}
