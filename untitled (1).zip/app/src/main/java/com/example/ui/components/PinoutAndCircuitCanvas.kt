package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import com.example.core.localization.AppLanguage
import com.example.domain.model.PinInfo

@Composable
fun PinoutDiagramCanvas(
    pinoutType: String,
    pins: List<PinInfo>,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val isPackageDependent = pinoutType == "PART_NUMBER_DEPENDENT" ||
        pinoutType == "TO92_VERIFY_DATASHEET" ||
        pins.any { it.isPackageDependent }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (isPackageDependent) {
            Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WarningAmber,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = if (language == AppLanguage.BANGLA) {
                            "পার্ট নম্বর / প্যাকেজ ভেদে পিনআউট ভিন্ন হয় — সংযোগের আগে অবশ্যই আসল বোর্ডের লেখা বা ডেটাশিট মিলিয়ে নিন।"
                        } else {
                            "Package / Part-Number Dependent Pinout — always check your exact part datasheet or PCB silkscreen before powering."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }

        val textMeasurer = rememberTextMeasurer()
        val primary = MaterialTheme.colorScheme.primary
        val amber = MaterialTheme.colorScheme.secondary
        val emerald = MaterialTheme.colorScheme.tertiary
        val onSurface = MaterialTheme.colorScheme.onSurface
        val surfaceVar = MaterialTheme.colorScheme.surfaceVariant
        val outline = MaterialTheme.colorScheme.outline

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f

            when (pinoutType) {
                "IC_NE555_DIP8", "IC_LM358_DIP8", "IC_LM741_DIP8" -> {
                    val leftPins = when (pinoutType) {
                        "IC_NE555_DIP8" -> listOf("1 GND", "2 TRIG", "3 OUT", "4 RST")
                        "IC_LM358_DIP8" -> listOf("1 OUT1", "2 IN1-", "3 IN1+", "4 GND")
                        else -> listOf("1 NULL", "2 IN-", "3 IN+", "4 V-")
                    }
                    val rightPins = when (pinoutType) {
                        "IC_NE555_DIP8" -> listOf("8 VCC", "7 DIS", "6 THR", "5 CTRL")
                        "IC_LM358_DIP8" -> listOf("8 VCC", "7 OUT2", "6 IN2-", "5 IN2+")
                        else -> listOf("8 NC", "7 V+", "6 OUT", "5 NULL")
                    }
                    drawDipDiagram(w, h, cx, leftPins, rightPins, textMeasurer, primary, amber, onSurface, surfaceVar)
                }
                "IC_LM324_DIP14" -> {
                    drawDipDiagram(
                        w, h, cx,
                        listOf("1 OUT1", "2 IN1-", "3 IN1+", "4 VCC", "5 IN2+", "6 IN2-", "7 OUT2"),
                        listOf("14 OUT4", "13 IN4-", "12 IN4+", "11 GND", "10 IN3+", "9 IN3-", "8 OUT3"),
                        textMeasurer, primary, amber, onSurface, surfaceVar
                    )
                }
                "MOSFET_TO220_GDS", "REGULATOR_78XX_TO220", "IGBT_GCE", "SCR_KAG", "TRIAC_MT1_MT2_G" -> {
                    val labels = when (pinoutType) {
                        "MOSFET_TO220_GDS" -> listOf("1: G", "2: D (Tab)", "3: S")
                        "REGULATOR_78XX_TO220" -> listOf("1: IN", "2: GND (Tab)", "3: OUT")
                        "IGBT_GCE" -> listOf("1: G", "2: C (Tab)", "3: E")
                        "SCR_KAG" -> listOf("1: K", "2: A (Tab)", "3: G")
                        else -> listOf("1: MT1", "2: MT2 (Tab)", "3: G")
                    }
                    drawTo220Pinout(w, h, cx, labels, textMeasurer, primary, amber, onSurface)
                }
                "DIODE_AK", "LED_AK", "BUZZER_PN", "TWO_TERMINAL_POLARIZED", "MIC_2PIN" -> {
                    val leftLbl = if (pinoutType == "TWO_TERMINAL_POLARIZED") "+ Long" else "A (+)"
                    val rightLbl = if (pinoutType == "TWO_TERMINAL_POLARIZED") "- Stripe" else "K (- / Flat)"
                    drawRoundRect(surfaceVar, Offset(cx - w * 0.16f, h * 0.18f), Size(w * 0.32f, h * 0.32f), CornerRadius(12f, 12f))
                    drawLine(emerald, Offset(cx - w * 0.08f, h * 0.50f), Offset(cx - w * 0.08f, h * 0.86f), 6f)
                    drawLine(amber, Offset(cx + w * 0.08f, h * 0.50f), Offset(cx + w * 0.08f, h * 0.76f), 6f)
                    drawCanvasLabel(textMeasurer, leftLbl, Offset(cx - w * 0.28f, h * 0.74f), emerald)
                    drawCanvasLabel(textMeasurer, rightLbl, Offset(cx + w * 0.13f, h * 0.70f), amber)
                }
                "TWO_TERMINAL_NON_POLARIZED", "TACTILE_4PIN", "MOTOR_2WIRE", "TWO_TERMINAL_POLARITY_PHASE" -> {
                    drawRoundRect(surfaceVar, Offset(w * 0.25f, h * 0.24f), Size(w * 0.50f, h * 0.36f), CornerRadius(10f, 10f))
                    drawLine(primary, Offset(w * 0.10f, h * 0.42f), Offset(w * 0.25f, h * 0.42f), 5f)
                    drawLine(primary, Offset(w * 0.75f, h * 0.42f), Offset(w * 0.90f, h * 0.42f), 5f)
                    val note = when (pinoutType) {
                        "TACTILE_4PIN" -> "Paired legs: (1-2) & (3-4)"
                        "MOTOR_2WIRE" -> "Swap wires -> reverses spin"
                        "TWO_TERMINAL_POLARITY_PHASE" -> "In-line Phase / DC Polarity"
                        else -> "Non-Polarized (Either Direction)"
                    }
                    drawCanvasLabel(textMeasurer, note, Offset(w * 0.24f, h * 0.68f), onSurface)
                }
                "RELAY_SPDT_5PIN" -> {
                    drawRoundRect(surfaceVar, Offset(w * 0.22f, h * 0.14f), Size(w * 0.56f, h * 0.72f), CornerRadius(10f, 10f))
                    drawCircle(amber, 9f, Offset(w * 0.32f, h * 0.30f))
                    drawCircle(amber, 9f, Offset(w * 0.32f, h * 0.70f))
                    drawCircle(primary, 9f, Offset(w * 0.28f, h * 0.50f))
                    drawCircle(emerald, 9f, Offset(w * 0.68f, h * 0.32f))
                    drawCircle(Color(0xFFEF4444), 9f, Offset(w * 0.68f, h * 0.68f))
                    drawCanvasLabel(textMeasurer, "COIL", Offset(w * 0.36f, h * 0.24f), amber)
                    drawCanvasLabel(textMeasurer, "COM", Offset(w * 0.33f, h * 0.45f), primary)
                    drawCanvasLabel(textMeasurer, "COIL", Offset(w * 0.36f, h * 0.64f), amber)
                    drawCanvasLabel(textMeasurer, "NC", Offset(w * 0.58f, h * 0.26f), emerald)
                    drawCanvasLabel(textMeasurer, "NO", Offset(w * 0.58f, h * 0.62f), Color(0xFFEF4444))
                }
                "BREADBOARD_BUS_MAP" -> {
                    drawRoundRect(surfaceVar, Offset(w * 0.08f, h * 0.14f), Size(w * 0.84f, h * 0.72f), CornerRadius(10f, 10f))
                    drawLine(Color(0xFFEF4444), Offset(w * 0.12f, h * 0.24f), Offset(w * 0.88f, h * 0.24f), 4f)
                    drawLine(primary, Offset(w * 0.12f, h * 0.76f), Offset(w * 0.88f, h * 0.76f), 4f)
                    for (c in 0..7) {
                        val x = w * 0.18f + c * w * 0.09f
                        drawLine(emerald, Offset(x, h * 0.32f), Offset(x, h * 0.46f), 4f)
                        drawLine(amber, Offset(x, h * 0.54f), Offset(x, h * 0.68f), 4f)
                    }
                    drawCanvasLabel(textMeasurer, "+/- Horizontal | a-e & f-j Vertical", Offset(w * 0.20f, h * 0.44f), onSurface)
                }
                else -> {
                    // Clean dynamic pinout strip from the verified PinInfo list
                    drawRoundRect(surfaceVar, Offset(w * 0.08f, h * 0.16f), Size(w * 0.84f, h * 0.68f), CornerRadius(12f, 12f))
                    drawRoundRect(outline, Offset(w * 0.08f, h * 0.16f), Size(w * 0.84f, h * 0.68f), CornerRadius(12f, 12f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
                    val displayPins = pins.take(5)
                    if (displayPins.isNotEmpty()) {
                        val step = (w * 0.74f) / displayPins.size
                        displayPins.forEachIndexed { i, pin ->
                            val px = w * 0.15f + i * step + step * 0.35f
                            val col = if (i % 2 == 0) primary else amber
                            drawCircle(col, 8f, Offset(px, h * 0.40f))
                            drawLine(col, Offset(px, h * 0.44f), Offset(px, h * 0.76f), 4f)
                            drawCanvasLabel(textMeasurer, pin.pinLabel.take(8), Offset(px - w * 0.05f, h * 0.22f), onSurface, fontSizeSp = 10f)
                        }
                    } else {
                        drawCanvasLabel(textMeasurer, pinoutType, Offset(w * 0.22f, cy - 10f), onSurface)
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawDipDiagram(
    w: Float, h: Float, cx: Float,
    leftPins: List<String>, rightPins: List<String>,
    measurer: androidx.compose.ui.text.TextMeasurer,
    primary: Color, amber: Color, onSurface: Color, bodyColor: Color
) {
    val bodyW = w * 0.26f
    val bodyLeft = cx - bodyW / 2f
    drawRoundRect(bodyColor, Offset(bodyLeft, h * 0.12f), Size(bodyW, h * 0.76f), CornerRadius(8f, 8f))
    drawArc(amber, 0f, 180f, true, Offset(cx - w * 0.04f, h * 0.09f), Size(w * 0.08f, h * 0.08f))
    val rows = leftPins.size.coerceAtLeast(1)
    val rowH = (h * 0.66f) / rows
    for (i in 0 until rows) {
        val py = h * 0.19f + i * rowH
        drawRect(primary, Offset(bodyLeft - w * 0.04f, py), Size(w * 0.04f, 6f))
        drawCanvasLabel(measurer, leftPins[i], Offset(w * 0.06f, py - 8f), onSurface, fontSizeSp = 10f)
        if (i < rightPins.size) {
            drawRect(amber, Offset(bodyLeft + bodyW, py), Size(w * 0.04f, 6f))
            drawCanvasLabel(measurer, rightPins[i], Offset(bodyLeft + bodyW + w * 0.06f, py - 8f), onSurface, fontSizeSp = 10f)
        }
    }
}

private fun DrawScope.drawTo220Pinout(
    w: Float, h: Float, cx: Float, labels: List<String>,
    measurer: androidx.compose.ui.text.TextMeasurer,
    primary: Color, amber: Color, onSurface: Color
) {
    drawRect(Color(0xFF94A3B8), Offset(cx - w * 0.12f, h * 0.08f), Size(w * 0.24f, h * 0.16f))
    drawRoundRect(Color(0xFF1E293B), Offset(cx - w * 0.13f, h * 0.22f), Size(w * 0.26f, h * 0.30f), CornerRadius(6f, 6f))
    val xs = listOf(cx - w * 0.09f, cx, cx + w * 0.09f)
    xs.forEachIndexed { idx, x ->
        drawLine(if (idx == 1) amber else primary, Offset(x, h * 0.52f), Offset(x, h * 0.78f), 6f)
        val lbl = labels.getOrNull(idx) ?: "${idx + 1}"
        drawCanvasLabel(measurer, lbl, Offset(x - w * 0.06f, h * 0.80f), onSurface, fontSizeSp = 10f)
    }
}

@Composable
fun ConnectionDiagramCanvas(
    diagramType: String,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    val primary = MaterialTheme.colorScheme.primary
    val amber = MaterialTheme.colorScheme.secondary
    val emerald = MaterialTheme.colorScheme.tertiary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val boxColor = MaterialTheme.colorScheme.surfaceVariant

    val labels = when (diagramType) {
        "LED_RESISTOR" -> Triple("+5V / GPIO", "R (330 Ω)", "LED → GND")
        "VOLTAGE_DIVIDER" -> Triple("V_in", "R1 ── V_out", "R2 → GND")
        "RC_FILTER" -> Triple("Signal In", "Series R", "Cap → GND")
        "FUSE_MOV" -> Triple("AC / +DC In", "Series Fuse", "MOV / Load")
        "RELAY_DRIVER" -> Triple("GPIO → 1kΩ", "NPN + Flyback", "Relay Coil")
        "ZENER_REGULATOR" -> Triple("V_in > V_z", "Series R_s", "Zener ── V_out")
        "MOSFET_SWITCH" -> Triple("PWM + 220Ω", "N-MOSFET (10k PD)", "Load + Flyback")
        "BUCK_CONVERTER" -> Triple("High DC In", "Switch + L + Diode", "Low V_out + Cap")
        "AC_DIMMER" -> Triple("Zero-Cross", "Opto-TRIAC", "TRIAC → AC Load")
        "NE555_ASTABLE" -> Triple("VCC + RA/RB", "NE555 (2-6-7)", "Cap → Pin 3 Out")
        "OPAMP_NON_INV" -> Triple("V_in → (+)", "Op-Amp Out", "Rf / Rg → (-)")
        "REGULATOR_7805" -> Triple("7–12V + 0.33µF", "7805 (GND)", "5V Out + 0.1µF")
        "PULL_DOWN_INPUT" -> Triple("5V ─ Button", "GPIO Sense", "10kΩ → GND")
        "SERVO_HOOKUP" -> Triple("Ext 5V PSU", "Signal (PWM)", "Common GND!")
        "MOTOR_STEPPER" -> Triple("MCU STEP/DIR", "Driver (A4988)", "Motor 1A/1B/2A/2B")
        "I2C_BUS" -> Triple("3.3/5V Pull-ups", "SDA ↔ SDA", "SCL ↔ SCL")
        "BRIDGE_RECTIFIER" -> Triple("AC ~ In", "4-Diode Bridge", "+ Smooth Cap −")
        "BMS_3S" -> Triple("B- / B1 / B2 / B+", "3S BMS Board", "P+ / P- Load/Chg")
        "DISPLAY_HOOKUP" -> Triple("VCC + GND", "I2C / SPI Bus", "Driver + Screen")
        else -> Triple("Regulated VCC", "0.1µF Decoupling", "MCU + Reset Pull-up")
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(110.dp)
    ) {
        val w = size.width
        val h = size.height
        val cy = h / 2f
        val boxW = w * 0.26f
        val boxH = h * 0.56f
        val xs = listOf(w * 0.04f, w * 0.37f, w * 0.70f)
        val cols = listOf(primary, amber, emerald)

        drawLine(onSurface.copy(alpha = 0.7f), Offset(xs[0] + boxW, cy), Offset(xs[1], cy), 4f)
        drawArrowHead(Offset(xs[1], cy), 0f, 10f, primary, 4f)
        drawLine(onSurface.copy(alpha = 0.7f), Offset(xs[1] + boxW, cy), Offset(xs[2], cy), 4f)
        drawArrowHead(Offset(xs[2], cy), 0f, 10f, emerald, 4f)

        val texts = listOf(labels.first, labels.second, labels.third)
        xs.forEachIndexed { idx, x ->
            drawRoundRect(boxColor, Offset(x, cy - boxH / 2f), Size(boxW, boxH), CornerRadius(10f, 10f))
            drawRoundRect(cols[idx], Offset(x, cy - boxH / 2f), Size(boxW, boxH), CornerRadius(10f, 10f), style = androidx.compose.ui.graphics.drawscope.Stroke(2.5f))
            drawCanvasLabel(textMeasurer, texts[idx], Offset(x + 8f, cy - 10f), onSurface, fontSizeSp = 10f)
        }
    }
}

@Composable
fun ComparisonDiagramCanvas(
    comparisonType: String,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val rows: List<Triple<String, String, String>> = when (comparisonType) {
        "PASSIVE_RESISTIVE_TYPES" -> listOf(
            Triple("Fixed Resistor", "Constant Ω", "Current limit / dividers"),
            Triple("Potentiometer", "3-pin knob", "Adjustable voltage"),
            Triple("Thermistor / LDR", "°C or Lux", "Environmental sensing")
        )
        "CAPACITOR_FAMILIES" -> listOf(
            Triple("Ceramic (MLCC)", "pF–10µF, No Pol", "Decoupling & RF"),
            Triple("Electrolytic", "1–10,000µF, Pol", "Bulk power filter"),
            Triple("Film (Poly/PP)", "nF–µF, Low Loss", "AC & audio tone")
        )
        "DIODE_FAMILIES" -> listOf(
            Triple("PN (1N4007)", "V_f ~0.7 V", "50/60 Hz AC rectifier"),
            Triple("Schottky (1N5819)", "V_f ~0.2–0.4 V", "Fast SMPS & solar"),
            Triple("Zener / TVS", "Reverse Clamp", "Ref & ESD guard")
        )
        "SWITCHING_TRANSISTORS" -> listOf(
            Triple("BJT (NPN/PNP)", "Current-driven I_b", "Small signals / amps"),
            Triple("MOSFET", "Voltage-driven V_gs", "High-eff DC PWM"),
            Triple("IGBT / TRIAC", "HV / AC Phase", "Inverters & AC loads")
        )
        "REGULATOR_VS_BUCK" -> listOf(
            Triple("Linear (7805)", "Burns excess as heat", "~40% eff (12V→5V)"),
            Triple("Buck (LM2596)", "Switches inductor", "85–95% eff step-down"),
            Triple("Boost (MT3608)", "Steps UP voltage", "3.7V → 5V / 12V")
        )
        "RECTIFIER_TOPOLOGIES" -> listOf(
            Triple("Half-Wave (1D)", "50% cycle wasted", "High ripple"),
            Triple("Bridge (4D)", "Full cycle +/−", "2× V_f diode drop"),
            Triple("Synchronous FET", "Ultra-low R_ds(on)", "High-amp SMPS")
        )
        "DISPLAY_TECH_COMPARE" -> listOf(
            Triple("7-Seg / DotMatrix", "Bright LEDs", "Digits & signage"),
            Triple("16×2 LCD", "Daylight readable", "Simple text + menus"),
            Triple("OLED / TFT", "Pixel graphics", "Charts & touch UIs")
        )
        "BOARD_VOLTAGE_COMPARE" -> listOf(
            Triple("Arduino UNO/Mega", "5 V Logic | 16 MHz", "Rugged beginner I/O"),
            Triple("ESP32 / ESP8266", "3.3 V | Wi-Fi/BLE", "IoT & web dashboards"),
            Triple("Pico / STM32", "3.3 V | PIO / DMA", "Real-time & robotics")
        )
        else -> listOf(
            Triple("TVS Diode", "< 1 ns speed", "Chip ESD & spikes"),
            Triple("MOV / SPD", "~15 ns, High kA", "Mains lightning surge"),
            Triple("Fuse / MCB / RCCB", "ms response", "Overcurrent & human shock")
        )
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { (item, metric, role) ->
            Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1.1f)
                    )
                    Text(
                        text = metric,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = role,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1.2f)
                    )
                }
            }
        }
    }
}
