package com.example.ui.book

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.repository.ComponentRepository
import com.example.domain.model.ElectronicComponent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ComponentDetailUiState {
    data object Loading : ComponentDetailUiState
    data class Ready(
        val component: ElectronicComponent,
        val relatedComponents: List<ElectronicComponent>,
        val language: AppLanguage,
        val isAdvancedMode: Boolean
    ) : ComponentDetailUiState
    data object NotFound : ComponentDetailUiState
}

class ComponentDetailViewModel(
    private val componentId: String,
    private val repository: ComponentRepository,
    prefsStore: UserPrefsStore
) : ViewModel() {

    private val _isAdvancedMode = MutableStateFlow(false)
    private var viewRecorded = false

    init {
        viewModelScope.launch {
            if (!viewRecorded) {
                viewRecorded = true
                repository.recordComponentView(componentId)
            }
        }
    }

    val uiState: StateFlow<ComponentDetailUiState> = combine(
        repository.observeComponentById(componentId),
        repository.observeAllComponents(),
        prefsStore.language,
        _isAdvancedMode
    ) { component, allComponents, language, advanced ->
        if (component == null) {
            if (allComponents.isEmpty()) ComponentDetailUiState.Loading else ComponentDetailUiState.NotFound
        } else {
            val lookup = allComponents.associateBy { it.id }
            val related = component.payload.relatedComponentIds.mapNotNull { lookup[it] }
            ComponentDetailUiState.Ready(
                component = component,
                relatedComponents = related,
                language = language,
                isAdvancedMode = advanced
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ComponentDetailUiState.Loading
    )

    fun toggleBookmark() {
        viewModelScope.launch {
            repository.toggleBookmark(componentId)
        }
    }

    fun toggleStudied() {
        viewModelScope.launch {
            repository.toggleStudied(componentId)
        }
    }

    fun setAdvancedMode(advanced: Boolean) {
        _isAdvancedMode.value = advanced
    }

    class Factory(
        private val componentId: String,
        private val repository: ComponentRepository,
        private val prefsStore: UserPrefsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ComponentDetailViewModel(componentId, repository, prefsStore) as T
        }
    }
}
