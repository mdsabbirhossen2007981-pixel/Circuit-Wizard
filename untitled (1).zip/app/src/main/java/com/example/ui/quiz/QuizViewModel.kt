package com.example.ui.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.data.local.datastore.StreakInfo
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.repository.QuizRepository
import com.example.domain.model.AcademyCourse
import com.example.domain.model.LearningAchievement
import com.example.domain.model.QuizAttemptRecord
import com.example.domain.model.QuizQuestionPayload
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CourseQuizMeta(
    val course: AcademyCourse,
    val questionCount: Int,
    val bestPercent: Int?
)

data class QuizHubUiState(
    val isLoading: Boolean = true,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val totalQuestions: Int = 0,
    val courseQuizzes: List<CourseQuizMeta> = emptyList(),
    val recentAttempts: List<QuizAttemptRecord> = emptyList(),
    val achievements: List<LearningAchievement> = emptyList(),
    val streak: StreakInfo = StreakInfo()
)

class QuizHubViewModel(
    private val quizRepository: QuizRepository,
    prefsStore: UserPrefsStore
) : ViewModel() {

    init {
        viewModelScope.launch {
            quizRepository.initializeQuizzes()
        }
    }

    val uiState: StateFlow<QuizHubUiState> = combine(
        quizRepository.observeAllQuestions(),
        quizRepository.observeAttempts(),
        quizRepository.observeAchievements(),
        prefsStore.streakInfo,
        prefsStore.language
    ) { questions, attempts, achievements, streak, language ->
        val courseList = AcademyCourse.entries.map { course ->
            val qCount = questions.count { it.courseId == course.id }
            val best = attempts.filter { it.courseId == course.id }.maxOfOrNull { it.percentage }
            CourseQuizMeta(course = course, questionCount = qCount, bestPercent = best)
        }
        QuizHubUiState(
            isLoading = false,
            language = language,
            totalQuestions = questions.size,
            courseQuizzes = courseList,
            recentAttempts = attempts.take(12),
            achievements = achievements,
            streak = streak
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = QuizHubUiState()
    )

    class Factory(
        private val quizRepository: QuizRepository,
        private val prefsStore: UserPrefsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return QuizHubViewModel(quizRepository, prefsStore) as T
        }
    }
}

data class QuizRunnerUiState(
    val isLoading: Boolean = true,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val courseId: String = "ALL",
    val isTimedExam: Boolean = false,
    val questions: List<QuizQuestionPayload> = emptyList(),
    val currentIndex: Int = 0,
    val selectedAnswers: Map<String, Int> = emptyMap(),
    val isSubmitted: Boolean = false,
    val score: Int = 0,
    val wrongQuestionIds: List<String> = emptyList(),
    val reviewIncorrectOnly: Boolean = false,
    val remainingSeconds: Int = 0,
    val elapsedSeconds: Int = 0
) {
    val currentQuestion: QuizQuestionPayload?
        get() = questions.getOrNull(currentIndex)
}

class QuizRunnerViewModel(
    private val courseId: String,
    private val isTimedExam: Boolean,
    private val quizRepository: QuizRepository,
    private val prefsStore: UserPrefsStore
) : ViewModel() {

    private val internalState = MutableStateFlow(
        QuizRunnerUiState(courseId = courseId, isTimedExam = isTimedExam)
    )
    private var timerJob: Job? = null

    val uiState: StateFlow<QuizRunnerUiState> = combine(
        internalState,
        prefsStore.language
    ) { state, lang ->
        state.copy(language = lang)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = QuizRunnerUiState(courseId = courseId, isTimedExam = isTimedExam)
    )

    init {
        loadQuestions()
    }

    private fun loadQuestions() {
        viewModelScope.launch {
            val lang = prefsStore.language.first()
            val questions = quizRepository.getQuestionsForSession(courseId, isTimedExam)
            val limitSeconds = if (isTimedExam) (questions.size * 45).coerceAtLeast(180) else 0
            internalState.update {
                it.copy(
                    isLoading = false,
                    language = lang,
                    questions = questions,
                    currentIndex = 0,
                    selectedAnswers = emptyMap(),
                    isSubmitted = false,
                    remainingSeconds = limitSeconds,
                    elapsedSeconds = 0
                )
            }
            startTimer()
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1_000)
                val snapshot = internalState.value
                if (snapshot.isSubmitted || snapshot.questions.isEmpty()) break
                if (snapshot.isTimedExam) {
                    val nextRem = (snapshot.remainingSeconds - 1).coerceAtLeast(0)
                    internalState.update {
                        it.copy(remainingSeconds = nextRem, elapsedSeconds = it.elapsedSeconds + 1)
                    }
                    if (nextRem == 0) {
                        submitQuiz()
                        break
                    }
                } else {
                    internalState.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1) }
                }
            }
        }
    }

    fun selectAnswer(questionId: String, optionIndex: Int) {
        if (internalState.value.isSubmitted) return
        internalState.update { state ->
            state.copy(selectedAnswers = state.selectedAnswers + (questionId to optionIndex))
        }
    }

    fun nextQuestion() {
        internalState.update { state ->
            val maxIdx = (state.questions.size - 1).coerceAtLeast(0)
            state.copy(currentIndex = (state.currentIndex + 1).coerceAtMost(maxIdx))
        }
    }

    fun prevQuestion() {
        internalState.update { state ->
            state.copy(currentIndex = (state.currentIndex - 1).coerceAtLeast(0))
        }
    }

    fun toggleReviewIncorrectOnly() {
        internalState.update { it.copy(reviewIncorrectOnly = !it.reviewIncorrectOnly) }
    }

    fun retakeQuiz() {
        loadQuestions()
    }

    fun submitQuiz() {
        val state = internalState.value
        if (state.isSubmitted || state.questions.isEmpty()) return
        timerJob?.cancel()

        var correct = 0
        val wrongIds = mutableListOf<String>()
        for (q in state.questions) {
            val chosen = state.selectedAnswers[q.id]
            if (chosen == q.correctIndex) {
                correct++
            } else {
                wrongIds += q.id
            }
        }

        internalState.update {
            it.copy(
                isSubmitted = true,
                score = correct,
                wrongQuestionIds = wrongIds,
                reviewIncorrectOnly = wrongIds.isNotEmpty()
            )
        }

        val lang = state.language
        val title = if (courseId == "ALL") {
            if (lang == AppLanguage.BANGLA) "পূর্ণ ইলেকট্রনিক্স পরীক্ষা" else "Full Electronics Exam"
        } else {
            AcademyCourse.fromId(courseId).title(lang)
        }

        viewModelScope.launch {
            quizRepository.saveAttempt(
                courseId = courseId,
                quizTitle = title,
                isTimedExam = isTimedExam,
                score = correct,
                totalQuestions = state.questions.size,
                durationSeconds = state.elapsedSeconds,
                wrongQuestionIds = wrongIds
            )
        }
    }

    override fun onCleared() {
        timerJob?.cancel()
        super.onCleared()
    }

    class Factory(
        private val courseId: String,
        private val isTimedExam: Boolean,
        private val quizRepository: QuizRepository,
        private val prefsStore: UserPrefsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return QuizRunnerViewModel(courseId, isTimedExam, quizRepository, prefsStore) as T
        }
    }
}
