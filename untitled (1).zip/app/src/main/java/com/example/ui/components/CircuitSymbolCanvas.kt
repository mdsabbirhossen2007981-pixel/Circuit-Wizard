package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CircuitSymbolCanvas(
    symbolType: String,
    modifier: Modifier = Modifier,
    strokeColor: Color = MaterialTheme.colorScheme.primary,
    accentColor: Color = MaterialTheme.colorScheme.secondary,
    labelColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val textMeasurer = rememberTextMeasurer()
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val stroke = Stroke(width = (w.coerceAtMost(h) * 0.045f).coerceIn(2.2f, 5.5f), cap = StrokeCap.Round, join = StrokeJoin.Round)
        val thinStroke = Stroke(width = (w.coerceAtMost(h) * 0.03f).coerceIn(1.5f, 3.5f), cap = StrokeCap.Round, join = StrokeJoin.Round)

        when (symbolType) {
            "RESISTOR" -> drawResistorSymbol(cx, cy, w, h, strokeColor, stroke)
            "VARIABLE_RESISTOR" -> {
                drawResistorSymbol(cx, cy, w, h, strokeColor, stroke)
                drawLine(accentColor, Offset(cx - w * 0.22f, cy + h * 0.25f), Offset(cx + w * 0.22f, cy - h * 0.25f), stroke.width)
                drawArrowHead(Offset(cx + w * 0.22f, cy - h * 0.25f), -45f, w * 0.09f, accentColor, stroke.width)
            }
            "POTENTIOMETER" -> {
                drawResistorSymbol(cx, cy + h * 0.06f, w, h, strokeColor, stroke)
                drawLine(accentColor, Offset(cx, cy - h * 0.28f), Offset(cx, cy - h * 0.02f), stroke.width)
                drawArrowHead(Offset(cx, cy - h * 0.02f), 90f, w * 0.08f, accentColor, stroke.width)
            }
            "THERMISTOR" -> {
                drawResistorSymbol(cx, cy, w, h, strokeColor, stroke)
                val p = Path().apply {
                    moveTo(cx - w * 0.24f, cy + h * 0.22f)
                    lineTo(cx - w * 0.14f, cy + h * 0.22f)
                    lineTo(cx + w * 0.20f, cy - h * 0.24f)
                }
                drawPath(p, accentColor, style = thinStroke)
                drawCanvasLabel(textMeasurer, "°t", Offset(cx + w * 0.22f, cy - h * 0.34f), accentColor)
            }
            "LDR" -> {
                drawCircle(strokeColor.copy(alpha = 0.45f), radius = w.coerceAtMost(h) * 0.30f, center = Offset(cx, cy + h * 0.04f), style = thinStroke)
                drawResistorSymbol(cx, cy + h * 0.04f, w * 0.85f, h * 0.85f, strokeColor, stroke)
                drawPhotonArrows(Offset(cx - w * 0.25f, cy - h * 0.34f), Offset(cx - w * 0.08f, cy - h * 0.18f), accentColor, thinStroke.width)
            }
            "VARISTOR" -> {
                drawResistorSymbol(cx, cy, w, h, strokeColor, stroke)
                val p = Path().apply {
                    moveTo(cx - w * 0.22f, cy + h * 0.24f)
                    lineTo(cx - w * 0.10f, cy + h * 0.24f)
                    lineTo(cx + w * 0.16f, cy - h * 0.24f)
                    lineTo(cx + w * 0.26f, cy - h * 0.24f)
                }
                drawPath(p, accentColor, style = thinStroke)
                drawCanvasLabel(textMeasurer, "U", Offset(cx + w * 0.20f, cy - h * 0.38f), accentColor)
            }
            "CAPACITOR_NON_POLAR" -> {
                val gap = w * 0.07f
                drawLine(strokeColor, Offset(w * 0.12f, cy), Offset(cx - gap, cy), stroke.width)
                drawLine(strokeColor, Offset(cx + gap, cy), Offset(w * 0.88f, cy), stroke.width)
                drawLine(strokeColor, Offset(cx - gap, cy - h * 0.26f), Offset(cx - gap, cy + h * 0.26f), stroke.width * 1.2f)
                drawLine(strokeColor, Offset(cx + gap, cy - h * 0.26f), Offset(cx + gap, cy + h * 0.26f), stroke.width * 1.2f)
            }
            "CAPACITOR_POLAR" -> {
                val gap = w * 0.07f
                drawLine(strokeColor, Offset(w * 0.12f, cy), Offset(cx - gap, cy), stroke.width)
                drawLine(strokeColor, Offset(cx + gap, cy), Offset(w * 0.88f, cy), stroke.width)
                drawLine(strokeColor, Offset(cx - gap, cy - h * 0.26f), Offset(cx - gap, cy + h * 0.26f), stroke.width * 1.2f)
                drawArc(
                    color = accentColor,
                    startAngle = 125f,
                    sweepAngle = 110f,
                    useCenter = false,
                    topLeft = Offset(cx + gap * 0.3f, cy - h * 0.30f),
                    size = Size(w * 0.22f, h * 0.60f),
                    style = stroke
                )
                drawCanvasLabel(textMeasurer, "+", Offset(cx - w * 0.22f, cy - h * 0.34f), accentColor)
            }
            "INDUCTOR" -> {
                drawLine(strokeColor, Offset(w * 0.08f, cy), Offset(w * 0.20f, cy), stroke.width)
                val loops = 4
                val loopW = (w * 0.60f) / loops
                for (i in 0 until loops) {
                    val left = w * 0.20f + i * loopW
                    drawArc(
                        color = strokeColor,
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(left, cy - h * 0.18f),
                        size = Size(loopW, h * 0.36f),
                        style = stroke
                    )
                }
                drawLine(strokeColor, Offset(w * 0.80f, cy), Offset(w * 0.92f, cy), stroke.width)
            }
            "TRANSFORMER" -> {
                // Primary coils left, core center, secondary coils right
                for (i in 0 until 3) {
                    val top = cy - h * 0.28f + i * h * 0.18f
                    drawArc(strokeColor, 270f, 180f, false, Offset(w * 0.22f, top), Size(w * 0.18f, h * 0.18f), style = stroke)
                    drawArc(strokeColor, 90f, 180f, false, Offset(w * 0.60f, top), Size(w * 0.18f, h * 0.18f), style = stroke)
                }
                drawLine(strokeColor, Offset(w * 0.12f, cy - h * 0.28f), Offset(w * 0.31f, cy - h * 0.28f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.12f, cy + h * 0.26f), Offset(w * 0.31f, cy + h * 0.26f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.69f, cy - h * 0.28f), Offset(w * 0.88f, cy - h * 0.28f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.69f, cy + h * 0.26f), Offset(w * 0.88f, cy + h * 0.26f), stroke.width)
                drawLine(accentColor, Offset(cx - w * 0.03f, cy - h * 0.30f), Offset(cx - w * 0.03f, cy + h * 0.30f), stroke.width)
                drawLine(accentColor, Offset(cx + w * 0.03f, cy - h * 0.30f), Offset(cx + w * 0.03f, cy + h * 0.30f), stroke.width)
            }
            "DIODE_PN", "DIODE_ZENER", "DIODE_SCHOTTKY", "LED", "PHOTODIODE", "DIODE_TVS" -> {
                drawDiodeBase(cx, cy, w, h, strokeColor, stroke)
                val barX = cx + w * 0.11f
                val barTop = cy - h * 0.20f
                val barBot = cy + h * 0.20f
                when (symbolType) {
                    "DIODE_ZENER" -> {
                        drawLine(accentColor, Offset(barX, barTop), Offset(barX + w * 0.07f, barTop - h * 0.06f), stroke.width)
                        drawLine(accentColor, Offset(barX, barBot), Offset(barX - w * 0.07f, barBot + h * 0.06f), stroke.width)
                    }
                    "DIODE_SCHOTTKY" -> {
                        val sPath = Path().apply {
                            moveTo(barX - w * 0.06f, barTop - h * 0.05f)
                            lineTo(barX, barTop - h * 0.05f)
                            lineTo(barX, barBot + h * 0.05f)
                            lineTo(barX + w * 0.06f, barBot + h * 0.05f)
                        }
                        drawPath(sPath, accentColor, style = stroke)
                    }
                    "LED" -> {
                        drawPhotonArrows(Offset(cx + w * 0.02f, cy - h * 0.20f), Offset(cx + w * 0.20f, cy - h * 0.38f), accentColor, thinStroke.width)
                    }
                    "PHOTODIODE" -> {
                        drawPhotonArrows(Offset(cx - w * 0.16f, cy - h * 0.38f), Offset(cx + w * 0.02f, cy - h * 0.20f), accentColor, thinStroke.width)
                    }
                    "DIODE_TVS" -> {
                        // Bidirectional back-to-back triangles
                        val leftX = cx - w * 0.16f
                        val rightX = cx + w * 0.16f
                        val t1 = Path().apply {
                            moveTo(leftX, cy - h * 0.16f)
                            lineTo(leftX, cy + h * 0.16f)
                            lineTo(cx, cy)
                            close()
                        }
                        val t2 = Path().apply {
                            moveTo(rightX, cy - h * 0.16f)
                            lineTo(rightX, cy + h * 0.16f)
                            lineTo(cx, cy)
                            close()
                        }
                        drawPath(t1, accentColor, style = stroke)
                        drawPath(t2, accentColor, style = stroke)
                        drawLine(accentColor, Offset(cx, cy - h * 0.18f), Offset(cx, cy + h * 0.18f), stroke.width)
                    }
                }
            }
            "BRIDGE_RECTIFIER" -> {
                val r = w.coerceAtMost(h) * 0.28f
                val dPath = Path().apply {
                    moveTo(cx, cy - r)
                    lineTo(cx + r, cy)
                    lineTo(cx, cy + r)
                    lineTo(cx - r, cy)
                    close()
                }
                drawPath(dPath, strokeColor, style = stroke)
                drawCanvasLabel(textMeasurer, "~", Offset(cx - r - w * 0.12f, cy - h * 0.10f), accentColor)
                drawCanvasLabel(textMeasurer, "~", Offset(cx + r + w * 0.04f, cy - h * 0.10f), accentColor)
                drawCanvasLabel(textMeasurer, "+", Offset(cx - w * 0.03f, cy - r - h * 0.18f), accentColor)
                drawCanvasLabel(textMeasurer, "-", Offset(cx - w * 0.02f, cy + r + h * 0.02f), accentColor)
            }
            "BJT_NPN", "BJT_PNP" -> {
                val r = w.coerceAtMost(h) * 0.30f
                drawCircle(strokeColor.copy(alpha = 0.45f), radius = r, center = Offset(cx, cy), style = thinStroke)
                val barX = cx - r * 0.25f
                drawLine(strokeColor, Offset(w * 0.12f, cy), Offset(barX, cy), stroke.width)
                drawLine(strokeColor, Offset(barX, cy - r * 0.55f), Offset(barX, cy + r * 0.55f), stroke.width * 1.3f)
                val colEnd = Offset(cx + r * 0.55f, cy - r * 0.85f)
                val emEnd = Offset(cx + r * 0.55f, cy + r * 0.85f)
                drawLine(strokeColor, Offset(barX, cy - r * 0.25f), colEnd, stroke.width)
                drawLine(strokeColor, colEnd, Offset(colEnd.x, h * 0.10f), stroke.width)
                drawLine(strokeColor, Offset(barX, cy + r * 0.25f), emEnd, stroke.width)
                drawLine(strokeColor, emEnd, Offset(emEnd.x, h * 0.90f), stroke.width)
                if (symbolType == "BJT_NPN") {
                    drawArrowHead(emEnd, 48f, r * 0.30f, accentColor, stroke.width)
                } else {
                    drawArrowHead(Offset(barX + r * 0.15f, cy + r * 0.35f), 228f, r * 0.30f, accentColor, stroke.width)
                }
            }
            "MOSFET_N", "IGBT" -> {
                val r = w.coerceAtMost(h) * 0.30f
                drawCircle(strokeColor.copy(alpha = 0.45f), radius = r, center = Offset(cx, cy), style = thinStroke)
                val gateX = cx - r * 0.35f
                val chanX = cx - r * 0.12f
                drawLine(strokeColor, Offset(w * 0.12f, cy + r * 0.35f), Offset(gateX, cy + r * 0.35f), stroke.width)
                drawLine(strokeColor, Offset(gateX, cy - r * 0.45f), Offset(gateX, cy + r * 0.45f), stroke.width)
                // Broken channel bars
                for (k in -1..1) {
                    val yOff = cy + k * r * 0.35f
                    drawLine(strokeColor, Offset(chanX, yOff - r * 0.10f), Offset(chanX, yOff + r * 0.10f), stroke.width * 1.2f)
                }
                drawLine(strokeColor, Offset(chanX, cy - r * 0.35f), Offset(cx + r * 0.55f, cy - r * 0.35f), stroke.width)
                drawLine(strokeColor, Offset(cx + r * 0.55f, cy - r * 0.35f), Offset(cx + r * 0.55f, h * 0.12f), stroke.width)
                drawLine(strokeColor, Offset(chanX, cy + r * 0.35f), Offset(cx + r * 0.55f, cy + r * 0.35f), stroke.width)
                drawLine(strokeColor, Offset(cx + r * 0.55f, cy + r * 0.35f), Offset(cx + r * 0.55f, h * 0.88f), stroke.width)
                drawArrowHead(Offset(chanX, cy), 180f, r * 0.25f, accentColor, stroke.width)
                if (symbolType == "IGBT") {
                    drawCanvasLabel(textMeasurer, "IGBT", Offset(w * 0.06f, h * 0.06f), accentColor)
                }
            }
            "JFET_N" -> {
                val r = w.coerceAtMost(h) * 0.30f
                drawCircle(strokeColor.copy(alpha = 0.45f), radius = r, center = Offset(cx, cy), style = thinStroke)
                val chanX = cx - r * 0.15f
                drawLine(strokeColor, Offset(w * 0.12f, cy), Offset(chanX, cy), stroke.width)
                drawArrowHead(Offset(chanX, cy), 0f, r * 0.24f, accentColor, stroke.width)
                drawLine(strokeColor, Offset(chanX, cy - r * 0.55f), Offset(chanX, cy + r * 0.55f), stroke.width * 1.3f)
                drawLine(strokeColor, Offset(chanX, cy - r * 0.40f), Offset(cx + r * 0.50f, cy - r * 0.40f), stroke.width)
                drawLine(strokeColor, Offset(cx + r * 0.50f, cy - r * 0.40f), Offset(cx + r * 0.50f, h * 0.12f), stroke.width)
                drawLine(strokeColor, Offset(chanX, cy + r * 0.40f), Offset(cx + r * 0.50f, cy + r * 0.40f), stroke.width)
                drawLine(strokeColor, Offset(cx + r * 0.50f, cy + r * 0.40f), Offset(cx + r * 0.50f, h * 0.88f), stroke.width)
            }
            "SCR" -> {
                drawDiodeBase(cx, cy, w, h, strokeColor, stroke)
                drawLine(accentColor, Offset(cx + w * 0.11f, cy + h * 0.10f), Offset(cx + w * 0.26f, cy + h * 0.34f), stroke.width)
                drawCanvasLabel(textMeasurer, "G", Offset(cx + w * 0.26f, cy + h * 0.26f), accentColor)
            }
            "TRIAC", "DIAC" -> {
                val leftX = cx - w * 0.14f
                val rightX = cx + w * 0.14f
                drawLine(strokeColor, Offset(w * 0.10f, cy), Offset(leftX, cy), stroke.width)
                drawLine(strokeColor, Offset(rightX, cy), Offset(w * 0.90f, cy), stroke.width)
                val topTri = Path().apply {
                    moveTo(leftX, cy - h * 0.18f)
                    lineTo(leftX, cy - h * 0.02f)
                    lineTo(rightX, cy - h * 0.10f)
                    close()
                }
                val botTri = Path().apply {
                    moveTo(rightX, cy + h * 0.02f)
                    lineTo(rightX, cy + h * 0.18f)
                    lineTo(leftX, cy + h * 0.10f)
                    close()
                }
                drawPath(topTri, strokeColor, style = stroke)
                drawPath(botTri, strokeColor, style = stroke)
                drawLine(strokeColor, Offset(leftX, cy - h * 0.20f), Offset(leftX, cy + h * 0.20f), stroke.width)
                drawLine(strokeColor, Offset(rightX, cy - h * 0.20f), Offset(rightX, cy + h * 0.20f), stroke.width)
                if (symbolType == "TRIAC") {
                    drawLine(accentColor, Offset(rightX, cy + h * 0.16f), Offset(rightX + w * 0.12f, cy + h * 0.36f), stroke.width)
                    drawCanvasLabel(textMeasurer, "G", Offset(rightX + w * 0.12f, cy + h * 0.28f), accentColor)
                }
            }
            "OPAMP" -> {
                val tri = Path().apply {
                    moveTo(w * 0.24f, h * 0.18f)
                    lineTo(w * 0.24f, h * 0.82f)
                    lineTo(w * 0.78f, cy)
                    close()
                }
                drawPath(tri, strokeColor, style = stroke)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.36f), Offset(w * 0.24f, h * 0.36f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.64f), Offset(w * 0.24f, h * 0.64f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.78f, cy), Offset(w * 0.92f, cy), stroke.width)
                drawCanvasLabel(textMeasurer, "+", Offset(w * 0.28f, h * 0.28f), accentColor)
                drawCanvasLabel(textMeasurer, "−", Offset(w * 0.28f, h * 0.56f), accentColor)
            }
            "LOGIC_NAND" -> {
                val body = Path().apply {
                    moveTo(w * 0.24f, h * 0.22f)
                    lineTo(w * 0.48f, h * 0.22f)
                    lineTo(w * 0.48f, h * 0.22f)
                }
                drawPath(body, strokeColor, style = stroke)
                drawLine(strokeColor, Offset(w * 0.24f, h * 0.22f), Offset(w * 0.24f, h * 0.78f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.24f, h * 0.78f), Offset(w * 0.48f, h * 0.78f), stroke.width)
                drawArc(strokeColor, -90f, 180f, false, Offset(w * 0.26f, h * 0.22f), Size(w * 0.44f, h * 0.56f), style = stroke)
                drawCircle(accentColor, radius = w * 0.045f, center = Offset(w * 0.745f, cy), style = stroke)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.36f), Offset(w * 0.24f, h * 0.36f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.64f), Offset(w * 0.24f, h * 0.64f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.79f, cy), Offset(w * 0.92f, cy), stroke.width)
            }
            "IC_555", "IC_GENERIC", "IC_REGULATOR", "IC_HBRIDGE", "MCU_BOARD", "MODULE_WIRELESS", "SENSOR_GENERIC" -> {
                val tag = when (symbolType) {
                    "IC_555" -> "555"
                    "IC_REGULATOR" -> "REG"
                    "IC_HBRIDGE" -> "H-BR"
                    "MCU_BOARD" -> "MCU"
                    "MODULE_WIRELESS" -> "RF"
                    "SENSOR_GENERIC" -> "SENS"
                    else -> "IC"
                }
                drawIcBoxSymbol(w, h, cx, cy, tag, textMeasurer, strokeColor, accentColor, labelColor, stroke)
            }
            "RELAY" -> {
                drawRoundRect(strokeColor, Offset(w * 0.16f, h * 0.18f), Size(w * 0.68f, h * 0.64f), CornerRadius(8f, 8f), style = thinStroke)
                drawRect(accentColor, Offset(w * 0.24f, h * 0.34f), Size(w * 0.14f, h * 0.32f), style = stroke)
                drawLine(strokeColor, Offset(w * 0.50f, h * 0.66f), Offset(w * 0.72f, h * 0.36f), stroke.width)
                drawCircle(accentColor, 4f, Offset(w * 0.50f, h * 0.66f))
                drawCircle(accentColor, 4f, Offset(w * 0.72f, h * 0.34f))
            }
            "SWITCH_SPST" -> {
                drawLine(strokeColor, Offset(w * 0.12f, cy), Offset(w * 0.34f, cy), stroke.width)
                drawLine(strokeColor, Offset(w * 0.66f, cy), Offset(w * 0.88f, cy), stroke.width)
                drawLine(accentColor, Offset(w * 0.34f, cy), Offset(w * 0.64f, cy - h * 0.24f), stroke.width)
                drawCircle(strokeColor, w * 0.04f, Offset(w * 0.34f, cy))
                drawCircle(strokeColor, w * 0.04f, Offset(w * 0.66f, cy))
            }
            "MOTOR_DC", "MOTOR_SERVO", "MOTOR_STEPPER" -> {
                val r = w.coerceAtMost(h) * 0.28f
                drawCircle(strokeColor, radius = r, center = Offset(cx, cy), style = stroke)
                drawLine(strokeColor, Offset(w * 0.10f, cy), Offset(cx - r, cy), stroke.width)
                drawLine(strokeColor, Offset(cx + r, cy), Offset(w * 0.90f, cy), stroke.width)
                val code = when (symbolType) {
                    "MOTOR_SERVO" -> "SRV"
                    "MOTOR_STEPPER" -> "STP"
                    else -> "M"
                }
                drawCanvasLabel(textMeasurer, code, Offset(cx - r * 0.38f, cy - r * 0.36f), accentColor)
            }
            "BUZZER", "SPEAKER", "MICROPHONE" -> {
                val sym = Path().apply {
                    moveTo(w * 0.28f, h * 0.35f)
                    lineTo(w * 0.48f, h * 0.35f)
                    lineTo(w * 0.70f, h * 0.18f)
                    lineTo(w * 0.70f, h * 0.82f)
                    lineTo(w * 0.48f, h * 0.65f)
                    lineTo(w * 0.28f, h * 0.65f)
                    close()
                }
                drawPath(sym, strokeColor, style = stroke)
                if (symbolType == "MICROPHONE") {
                    drawLine(accentColor, Offset(w * 0.78f, h * 0.22f), Offset(w * 0.78f, h * 0.78f), stroke.width)
                } else {
                    drawArc(accentColor, -40f, 80f, false, Offset(w * 0.68f, h * 0.30f), Size(w * 0.18f, h * 0.40f), style = thinStroke)
                }
            }
            "FUSE", "PTC_FUSE" -> {
                drawLine(strokeColor, Offset(w * 0.08f, cy), Offset(w * 0.28f, cy), stroke.width)
                drawLine(strokeColor, Offset(w * 0.72f, cy), Offset(w * 0.92f, cy), stroke.width)
                drawRect(strokeColor, Offset(w * 0.28f, cy - h * 0.15f), Size(w * 0.44f, h * 0.30f), style = stroke)
                drawLine(accentColor, Offset(w * 0.28f, cy), Offset(w * 0.72f, cy), stroke.width)
                if (symbolType == "PTC_FUSE") {
                    drawCanvasLabel(textMeasurer, "PTC", Offset(cx - w * 0.10f, h * 0.08f), accentColor)
                }
            }
            "CIRCUIT_BREAKER" -> {
                drawLine(strokeColor, Offset(w * 0.12f, cy), Offset(w * 0.34f, cy), stroke.width)
                drawLine(strokeColor, Offset(w * 0.66f, cy), Offset(w * 0.88f, cy), stroke.width)
                drawArc(accentColor, 195f, 150f, false, Offset(w * 0.34f, cy - h * 0.24f), Size(w * 0.32f, h * 0.36f), style = stroke)
                drawCanvasLabel(textMeasurer, "CB", Offset(cx - w * 0.07f, h * 0.64f), labelColor)
            }
            "DISPLAY_7SEG", "DISPLAY_SCREEN", "DISPLAY_MATRIX" -> {
                drawRoundRect(strokeColor, Offset(w * 0.18f, h * 0.18f), Size(w * 0.64f, h * 0.64f), CornerRadius(8f, 8f), style = stroke)
                val tag = when (symbolType) {
                    "DISPLAY_7SEG" -> "8.8"
                    "DISPLAY_MATRIX" -> ":::"
                    else -> "LCD"
                }
                drawCanvasLabel(textMeasurer, tag, Offset(cx - w * 0.10f, cy - h * 0.10f), accentColor)
            }
            "CONNECTOR_USB", "CONNECTOR_HEADER", "WIRE_JUMPER" -> {
                drawLine(strokeColor, Offset(w * 0.10f, h * 0.38f), Offset(w * 0.42f, h * 0.38f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.10f, h * 0.62f), Offset(w * 0.42f, h * 0.62f), stroke.width)
                drawArc(accentColor, -90f, 180f, false, Offset(w * 0.38f, h * 0.28f), Size(w * 0.16f, h * 0.20f), style = stroke)
                drawArc(accentColor, -90f, 180f, false, Offset(w * 0.38f, h * 0.52f), Size(w * 0.16f, h * 0.20f), style = stroke)
                drawLine(strokeColor, Offset(w * 0.54f, h * 0.38f), Offset(w * 0.88f, h * 0.38f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.54f, h * 0.62f), Offset(w * 0.88f, h * 0.62f), stroke.width)
            }
            "BATTERY_DC" -> {
                drawLine(strokeColor, Offset(w * 0.12f, cy), Offset(w * 0.42f, cy), stroke.width)
                drawLine(strokeColor, Offset(w * 0.58f, cy), Offset(w * 0.88f, cy), stroke.width)
                drawLine(accentColor, Offset(w * 0.42f, cy - h * 0.28f), Offset(w * 0.42f, cy + h * 0.28f), stroke.width * 1.2f)
                drawLine(strokeColor, Offset(w * 0.58f, cy - h * 0.14f), Offset(w * 0.58f, cy + h * 0.14f), stroke.width * 1.4f)
                drawCanvasLabel(textMeasurer, "+", Offset(w * 0.30f, cy - h * 0.34f), accentColor)
                drawCanvasLabel(textMeasurer, "−", Offset(w * 0.64f, cy - h * 0.34f), labelColor)
            }
            "AC_SOURCE" -> {
                val r = w.coerceAtMost(h) * 0.26f
                drawCircle(strokeColor, radius = r, center = Offset(cx, cy), style = stroke)
                drawLine(strokeColor, Offset(w * 0.08f, cy), Offset(cx - r, cy), stroke.width)
                drawLine(strokeColor, Offset(cx + r, cy), Offset(w * 0.92f, cy), stroke.width)
                val wave = Path().apply {
                    moveTo(cx - r * 0.55f, cy)
                    cubicTo(cx - r * 0.25f, cy - r * 0.7f, cx, cy - r * 0.7f, cx, cy)
                    cubicTo(cx, cy + r * 0.7f, cx + r * 0.25f, cy + r * 0.7f, cx + r * 0.55f, cy)
                }
                drawPath(wave, accentColor, style = stroke)
            }
            "VOLTMETER", "AMMETER", "MULTIMETER" -> {
                val r = w.coerceAtMost(h) * 0.28f
                drawCircle(strokeColor, radius = r, center = Offset(cx, cy), style = stroke)
                drawLine(strokeColor, Offset(w * 0.10f, cy), Offset(cx - r, cy), stroke.width)
                drawLine(strokeColor, Offset(cx + r, cy), Offset(w * 0.90f, cy), stroke.width)
                val code = when (symbolType) {
                    "VOLTMETER" -> "V"
                    "AMMETER" -> "A"
                    else -> "DMM"
                }
                drawCanvasLabel(textMeasurer, code, Offset(cx - w * 0.07f, cy - h * 0.10f), accentColor)
            }
            "LOGIC_AND" -> {
                drawLine(strokeColor, Offset(w * 0.26f, h * 0.22f), Offset(w * 0.26f, h * 0.78f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.26f, h * 0.22f), Offset(w * 0.48f, h * 0.22f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.26f, h * 0.78f), Offset(w * 0.48f, h * 0.78f), stroke.width)
                drawArc(strokeColor, -90f, 180f, false, Offset(w * 0.28f, h * 0.22f), Size(w * 0.44f, h * 0.56f), style = stroke)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.36f), Offset(w * 0.26f, h * 0.36f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.64f), Offset(w * 0.26f, h * 0.64f), stroke.width)
                drawLine(accentColor, Offset(w * 0.72f, cy), Offset(w * 0.92f, cy), stroke.width)
            }
            "LOGIC_OR", "LOGIC_XOR" -> {
                if (symbolType == "LOGIC_XOR") {
                    drawArc(accentColor, -65f, 130f, false, Offset(w * 0.12f, h * 0.20f), Size(w * 0.14f, h * 0.60f), style = stroke)
                }
                drawArc(strokeColor, -65f, 130f, false, Offset(w * 0.20f, h * 0.20f), Size(w * 0.16f, h * 0.60f), style = stroke)
                val orPath = Path().apply {
                    moveTo(w * 0.26f, h * 0.22f)
                    quadraticTo(w * 0.58f, h * 0.22f, w * 0.76f, cy)
                    quadraticTo(w * 0.58f, h * 0.78f, w * 0.26f, h * 0.78f)
                }
                drawPath(orPath, strokeColor, style = stroke)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.36f), Offset(w * 0.28f, h * 0.36f), stroke.width)
                drawLine(strokeColor, Offset(w * 0.08f, h * 0.64f), Offset(w * 0.28f, h * 0.64f), stroke.width)
                drawLine(accentColor, Offset(w * 0.76f, cy), Offset(w * 0.92f, cy), stroke.width)
            }
            "LOGIC_NOT" -> {
                val tri = Path().apply {
                    moveTo(w * 0.26f, h * 0.22f)
                    lineTo(w * 0.26f, h * 0.78f)
                    lineTo(w * 0.68f, cy)
                    close()
                }
                drawPath(tri, strokeColor, style = stroke)
                drawCircle(accentColor, radius = w * 0.045f, center = Offset(w * 0.73f, cy), style = stroke)
                drawLine(strokeColor, Offset(w * 0.08f, cy), Offset(w * 0.26f, cy), stroke.width)
                drawLine(accentColor, Offset(w * 0.78f, cy), Offset(w * 0.92f, cy), stroke.width)
            }
            "FLIP_FLOP", "COUNTER_IC", "SHIFT_REGISTER", "ADC_DAC" -> {
                val tag = when (symbolType) {
                    "FLIP_FLOP" -> "D-FF"
                    "COUNTER_IC" -> "CNT"
                    "SHIFT_REGISTER" -> "REG"
                    else -> "ADC"
                }
                drawRoundRect(strokeColor, Offset(w * 0.24f, h * 0.20f), Size(w * 0.52f, h * 0.60f), CornerRadius(8f, 8f), style = stroke)
                drawLine(accentColor, Offset(w * 0.10f, h * 0.36f), Offset(w * 0.24f, h * 0.36f), stroke.width)
                drawLine(accentColor, Offset(w * 0.10f, h * 0.64f), Offset(w * 0.24f, h * 0.64f), stroke.width)
                drawLine(accentColor, Offset(w * 0.76f, h * 0.36f), Offset(w * 0.90f, h * 0.36f), stroke.width)
                drawLine(accentColor, Offset(w * 0.76f, h * 0.64f), Offset(w * 0.90f, h * 0.64f), stroke.width)
                drawCanvasLabel(textMeasurer, tag, Offset(cx - w * 0.12f, cy - h * 0.10f), labelColor)
            }
            "BUCK_CONVERTER", "BOOST_CONVERTER", "INVERTER_AC" -> {
                val tag = when (symbolType) {
                    "BUCK_CONVERTER" -> "BUCK"
                    "BOOST_CONVERTER" -> "BOOST"
                    else -> "DC→AC"
                }
                drawRoundRect(strokeColor, Offset(w * 0.18f, h * 0.22f), Size(w * 0.64f, h * 0.56f), CornerRadius(10f, 10f), style = stroke)
                drawCanvasLabel(textMeasurer, tag, Offset(cx - w * 0.16f, cy - h * 0.10f), accentColor)
            }
            else -> {
                drawIcBoxSymbol(w, h, cx, cy, "COMP", textMeasurer, strokeColor, accentColor, labelColor, stroke)
            }
        }
    }
}

private fun DrawScope.drawResistorSymbol(cx: Float, cy: Float, w: Float, h: Float, color: Color, stroke: Stroke) {
    val leftLead = w * 0.12f
    val rightLead = w * 0.88f
    val zigStart = w * 0.26f
    val zigEnd = w * 0.74f
    val peaks = 6
    val step = (zigEnd - zigStart) / peaks
    val amp = h * 0.17f
    val p = Path().apply {
        moveTo(leftLead, cy)
        lineTo(zigStart, cy)
        for (i in 0 until peaks) {
            val x = zigStart + (i + 0.5f) * step
            val y = if (i % 2 == 0) cy - amp else cy + amp
            lineTo(x, y)
        }
        lineTo(zigEnd, cy)
        lineTo(rightLead, cy)
    }
    drawPath(p, color, style = stroke)
}

private fun DrawScope.drawDiodeBase(cx: Float, cy: Float, w: Float, h: Float, color: Color, stroke: Stroke) {
    val triLeft = cx - w * 0.13f
    val barX = cx + w * 0.11f
    drawLine(color, Offset(w * 0.10f, cy), Offset(triLeft, cy), stroke.width)
    drawLine(color, Offset(barX, cy), Offset(w * 0.90f, cy), stroke.width)
    val tri = Path().apply {
        moveTo(triLeft, cy - h * 0.20f)
        lineTo(triLeft, cy + h * 0.20f)
        lineTo(barX, cy)
        close()
    }
    drawPath(tri, color, style = stroke)
    drawLine(color, Offset(barX, cy - h * 0.20f), Offset(barX, cy + h * 0.20f), stroke.width * 1.2f)
}

private fun DrawScope.drawIcBoxSymbol(
    w: Float, h: Float, cx: Float, cy: Float, tag: String,
    measurer: TextMeasurer, strokeColor: Color, accentColor: Color, labelColor: Color, stroke: Stroke
) {
    drawRoundRect(strokeColor, Offset(w * 0.26f, h * 0.20f), Size(w * 0.48f, h * 0.60f), CornerRadius(6f, 6f), style = stroke)
    for (i in 0..2) {
        val y = h * 0.30f + i * h * 0.20f
        drawLine(accentColor, Offset(w * 0.12f, y), Offset(w * 0.26f, y), stroke.width)
        drawLine(accentColor, Offset(w * 0.74f, y), Offset(w * 0.88f, y), stroke.width)
    }
    drawCanvasLabel(measurer, tag, Offset(cx - w * 0.12f, cy - h * 0.10f), labelColor)
}

private fun DrawScope.drawPhotonArrows(start: Offset, end: Offset, color: Color, width: Float) {
    val dx = end.x - start.x
    val dy = end.y - start.y
    val angle = kotlin.math.atan2(dy, dx) * 180f / PI.toFloat()
    drawLine(color, start, end, width)
    drawArrowHead(end, angle, 10f, color, width)
    val shift = Offset(width * 3.5f, width * 2.5f)
    drawLine(color, start + shift, end + shift, width)
    drawArrowHead(end + shift, angle, 10f, color, width)
}

internal fun DrawScope.drawArrowHead(tip: Offset, angleDeg: Float, len: Float, color: Color, width: Float) {
    val rad = angleDeg * PI.toFloat() / 180f
    val a1 = rad + 2.55f
    val a2 = rad - 2.55f
    drawLine(color, tip, Offset(tip.x + cos(a1) * len, tip.y + sin(a1) * len), width)
    drawLine(color, tip, Offset(tip.x + cos(a2) * len, tip.y + sin(a2) * len), width)
}

internal fun DrawScope.drawCanvasLabel(
    measurer: TextMeasurer,
    text: String,
    topLeft: Offset,
    color: Color,
    fontSizeSp: Float = 11f
) {
    val measured = measurer.measure(
        text = text,
        style = TextStyle(color = color, fontSize = fontSizeSp.sp, fontWeight = FontWeight.Bold)
    )
    drawText(measured, topLeft = topLeft)
}
