package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LabDarkColorScheme = darkColorScheme(
    primary = OscilloscopeCyan,
    onPrimary = LabBgDark,
    primaryContainer = OscilloscopeCyanContainer,
    onPrimaryContainer = OscilloscopeCyan,
    secondary = CopperAmber,
    onSecondary = LabBgDark,
    secondaryContainer = CopperAmberContainer,
    onSecondaryContainer = CopperAmber,
    tertiary = LogicEmerald,
    onTertiary = LabBgDark,
    tertiaryContainer = LogicEmeraldContainer,
    onTertiaryContainer = LogicEmerald,
    error = FaultCrimson,
    onError = TextPrimaryDark,
    errorContainer = FaultCrimsonContainer,
    onErrorContainer = FaultCrimson,
    background = LabBgDark,
    onBackground = TextPrimaryDark,
    surface = LabSurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = LabSurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerLow = LabSurfaceDark,
    surfaceContainer = LabSurfaceVariantDark,
    surfaceContainerHigh = LabSurfaceElevatedDark,
    outline = LabOutlineDark,
    outlineVariant = LabSurfaceElevatedDark
)

private val LabLightColorScheme = lightColorScheme(
    primary = OscilloscopeTealLight,
    onPrimary = LabSurfaceLight,
    primaryContainer = OscilloscopeTealContainerLight,
    onPrimaryContainer = OscilloscopeTealLight,
    secondary = CopperAmberLight,
    onSecondary = LabSurfaceLight,
    secondaryContainer = CopperAmberContainerLight,
    onSecondaryContainer = CopperAmberLight,
    tertiary = LogicEmeraldLight,
    onTertiary = LabSurfaceLight,
    tertiaryContainer = LogicEmeraldContainerLight,
    onTertiaryContainer = LogicEmeraldLight,
    error = FaultCrimsonLight,
    onError = LabSurfaceLight,
    errorContainer = FaultCrimsonContainerLight,
    onErrorContainer = FaultCrimsonLight,
    background = LabBgLight,
    onBackground = TextPrimaryLight,
    surface = LabSurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = LabSurfaceVariantLight,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerLow = LabBgLight,
    surfaceContainer = LabSurfaceVariantLight,
    surfaceContainerHigh = LabSurfaceElevatedLight,
    outline = LabOutlineLight,
    outlineVariant = LabSurfaceElevatedLight
)

val LabShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun CircuitWizardTheme(
    darkTheme: Boolean = true,
    isBangla: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) LabDarkColorScheme else LabLightColorScheme
    val typography = buildAppTypography(isBangla = isBangla)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = LabShapes,
        content = content
    )
}
