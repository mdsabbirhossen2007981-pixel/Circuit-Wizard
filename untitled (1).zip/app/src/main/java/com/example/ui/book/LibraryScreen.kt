package com.example.ui.book

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.localization.AppLanguage
import com.example.core.localization.BookStrings
import com.example.core.localization.SortOrder
import com.example.domain.model.ComponentCategory
import com.example.ui.components.ComponentBookCard
import com.example.ui.components.SearchBookBar

@Composable
fun LibraryScreen(
    uiState: BookUiState,
    onSearchQueryChange: (String) -> Unit,
    onSelectCategory: (ComponentCategory?) -> Unit,
    onUpdateSortOrder: (SortOrder) -> Unit,
    onOpenComponent: (String) -> Unit,
    onToggleBookmark: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = uiState.language

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        val isTwoCol = maxWidth >= 700.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 960.dp)
                .padding(top = 12.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = BookStrings.navLibrary(lang),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(10.dp))
                SearchBookBar(
                    query = uiState.searchQuery,
                    onQueryChange = onSearchQueryChange,
                    language = lang,
                    testTag = "library_search_input"
                )
            }

            Spacer(Modifier.height(10.dp))

            // Category filter row (All + A..K)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.testTag("library_category_chips")
            ) {
                item(key = "chip_all") {
                    FilterChip(
                        selected = uiState.selectedCategory == null,
                        onClick = { onSelectCategory(null) },
                        label = { Text(BookStrings.allCategories(lang)) },
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("filter_chip_all")
                    )
                }
                items(ComponentCategory.entries, key = { "chip_${it.id}" }) { category ->
                    FilterChip(
                        selected = uiState.selectedCategory == category,
                        onClick = { onSelectCategory(category) },
                        label = { Text("${category.id}. ${category.title(lang)}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("filter_chip_${category.id.lowercase()}")
                    )
                }
            }

            // Sort row + result count
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (lang == AppLanguage.BANGLA) {
                        "${uiState.filteredComponents.size}টি কম্পোনেন্ট"
                    } else {
                        "${uiState.filteredComponents.size} components"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SortPill(
                        label = BookStrings.sortCurated(lang),
                        selected = uiState.sortOrder == SortOrder.CURATED,
                        onClick = { onUpdateSortOrder(SortOrder.CURATED) },
                        tag = "sort_curated"
                    )
                    SortPill(
                        label = BookStrings.sortAZ(lang),
                        selected = uiState.sortOrder == SortOrder.ALPHABETICAL_AZ,
                        onClick = { onUpdateSortOrder(SortOrder.ALPHABETICAL_AZ) },
                        tag = "sort_az"
                    )
                    SortPill(
                        label = BookStrings.sortZA(lang),
                        selected = uiState.sortOrder == SortOrder.ALPHABETICAL_ZA,
                        onClick = { onUpdateSortOrder(SortOrder.ALPHABETICAL_ZA) },
                        tag = "sort_za"
                    )
                }
            }

            if (uiState.filteredComponents.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = BookStrings.noSearchResults(lang),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("library_components_list"),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (isTwoCol) {
                        val rows = uiState.filteredComponents.chunked(2)
                        items(
                            items = rows,
                            key = { r -> "lib_row_${r.joinToString("_") { it.id }}" }
                        ) { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                rowItems.forEach { comp ->
                                    ComponentBookCard(
                                        component = comp,
                                        language = lang,
                                        onOpenDetail = { onOpenComponent(comp.id) },
                                        onToggleBookmark = { onToggleBookmark(comp.id) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (rowItems.size == 1) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    } else {
                        items(
                            items = uiState.filteredComponents,
                            key = { "lib_${it.id}" }
                        ) { comp ->
                            ComponentBookCard(
                                component = comp,
                                language = lang,
                                onOpenDetail = { onOpenComponent(comp.id) },
                                onToggleBookmark = { onToggleBookmark(comp.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SortPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.small,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier
            .height(36.dp)
            .testTag(tag)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 10.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
