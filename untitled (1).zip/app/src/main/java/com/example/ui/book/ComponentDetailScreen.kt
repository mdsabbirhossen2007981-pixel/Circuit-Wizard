package com.example.ui.book

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.localization.AppLanguage
import com.example.core.localization.BookStrings
import com.example.domain.model.ElectronicComponent
import com.example.ui.components.CircuitSymbolCanvas
import com.example.ui.components.ComparisonDiagramCanvas
import com.example.ui.components.ComponentIllustrationCanvas
import com.example.ui.components.ConnectionDiagramCanvas
import com.example.ui.components.PinoutDiagramCanvas
import com.example.ui.components.categoryAccentColor

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ComponentDetailScreen(
    uiState: ComponentDetailUiState,
    onBack: () -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleStudied: () -> Unit,
    onSetAdvancedMode: (Boolean) -> Unit,
    onOpenRelated: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    when (uiState) {
        ComponentDetailUiState.Loading -> {
            Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        ComponentDetailUiState.NotFound -> {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Component") },
                        navigationIcon = {
                            IconButton(onClick = onBack, modifier = Modifier.size(48.dp).testTag("detail_back_button")) {
                                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                            }
                        }
                    )
                }
            ) { inner ->
                Box(modifier = Modifier.fillMaxSize().padding(inner), contentAlignment = Alignment.Center) {
                    Text("Component not found", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        is ComponentDetailUiState.Ready -> {
            val comp = uiState.component
            val p = comp.payload
            val lang = uiState.language
            val bn = lang == AppLanguage.BANGLA
            val accent = categoryAccentColor(comp.category)

            Scaffold(
                modifier = modifier.fillMaxSize(),
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        navigationIcon = {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.size(48.dp).testTag("detail_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = BookStrings.back(lang)
                                )
                            }
                        },
                        title = {
                            Column {
                                Text(
                                    text = comp.name(lang),
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${comp.category.chapterCode} • ${comp.category.title(lang)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accent,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = onToggleBookmark,
                                modifier = Modifier.size(48.dp).testTag("detail_bookmark_button")
                            ) {
                                Icon(
                                    imageVector = if (comp.isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                    contentDescription = if (comp.isBookmarked) "Remove bookmark" else "Bookmark",
                                    tint = if (comp.isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background),
                    contentAlignment = Alignment.TopCenter
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 860.dp)
                            .testTag("component_detail_list"),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Bilingual Header + Studied Button
                        item(key = "header") {
                            DetailHeaderCard(
                                component = comp,
                                language = lang,
                                accent = accent,
                                onToggleStudied = onToggleStudied
                            )
                        }

                        // Visual Learning Studio (Illustration / Symbol / Pinout)
                        item(key = "visual_studio") {
                            VisualLearningCard(component = comp, language = lang)
                        }

                        // Beginner / Advanced Level Switcher
                        item(key = "level_card") {
                            LevelExplanationCard(
                                component = comp,
                                language = lang,
                                isAdvanced = uiState.isAdvancedMode,
                                onSelectLevel = onSetAdvancedMode
                            )
                        }

                        // Introduction, What it does, How it works, Working Principle, Structure
                        item(key = "theory_core") {
                            TextbookSectionCard(
                                title = if (bn) "১. পরিচিতি ও মূল কাজ" else "1. Introduction & Core Function"
                            ) {
                                SubEntry(if (bn) "পরিচিতি (Introduction)" else "Introduction", comp.introduction(lang))
                                SubEntry(if (bn) "কী কাজ করে (What It Does)" else "What It Does", comp.whatItDoes(lang))
                                SubEntry(if (bn) "কীভাবে কাজ করে (How It Works)" else "How It Works", comp.howItWorks(lang))
                                SubEntry(if (bn) "কার্যনীতি (Working Principle)" else "Working Principle", comp.workingPrinciple(lang))
                                SubEntry(if (bn) "গঠন (Component Structure)" else "Component Structure", comp.structure(lang))
                            }
                        }

                        // Types & Variations
                        if (p.typesAndVariations.isNotEmpty()) {
                            item(key = "types") {
                                TextbookSectionCard(
                                    title = if (bn) "২. প্রকারভেদ ও ধরন" else "2. Types & Variations"
                                ) {
                                    p.typesAndVariations.forEach { v ->
                                        Surface(
                                            shape = MaterialTheme.shapes.small,
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(v.name(lang), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                                Spacer(Modifier.height(2.dp))
                                                Text(v.summary(lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Pin Configuration
                        if (p.pinConfiguration.isNotEmpty()) {
                            item(key = "pins") {
                                TextbookSectionCard(
                                    title = if (bn) "৩. পিন পরিচিতি (Pin Configuration)" else "3. Pin Configuration"
                                ) {
                                    p.pinConfiguration.forEach { pin ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.primaryContainer
                                            ) {
                                                Text(
                                                    text = pin.pinLabel,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                            Spacer(Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(pin.name(lang), style = MaterialTheme.typography.titleSmall)
                                                Text(pin.role(lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Technical Specs + Unit & Measurement
                        item(key = "specs_unit") {
                            TextbookSectionCard(
                                title = if (bn) "৪. টেকনিক্যাল স্পেসিফিকেশন ও পরিমাপ" else "4. Specifications & Measurement"
                            ) {
                                p.technicalSpecs.forEach { spec ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(spec.label(lang), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1.2f)) {
                                            Text(spec.value, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                                            if (spec.note(lang).isNotBlank()) {
                                                Text(spec.note(lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Surface(
                                    shape = MaterialTheme.shapes.small,
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        val u = p.unitAndMeasurement
                                        Text(
                                            text = "${u.unitName(lang)} (${u.unitSymbol})",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.tertiary
                                        )
                                        Text(
                                            text = (if (bn) "যন্ত্র: " else "Tool: ") + u.measurementTool(lang),
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                        Text(
                                            text = u.howToMeasure(lang),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        // Practical Circuits + Connection Diagrams
                        if (p.practicalCircuits.isNotEmpty()) {
                            item(key = "circuits") {
                                TextbookSectionCard(
                                    title = if (bn) "৫. ব্যবহারিক সার্কিট ও সংযোগ" else "5. Practical Circuits & Connections"
                                ) {
                                    p.practicalCircuits.forEach { circuit ->
                                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(circuit.title(lang), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                            ConnectionDiagramCanvas(diagramType = circuit.diagramType, language = lang)
                                            Text(circuit.description(lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }

                        // Comparison Visual (when available)
                        if (!p.comparisonType.isNullOrBlank()) {
                            item(key = "comparison") {
                                TextbookSectionCard(
                                    title = if (bn) "৬. তুলনামূলক চার্ট" else "6. Engineering Comparison"
                                ) {
                                    ComparisonDiagramCanvas(comparisonType = p.comparisonType, language = lang)
                                }
                            }
                        }

                        // Applications, Real-Life Examples, Advantages & Limitations
                        item(key = "apps_pros_cons") {
                            TextbookSectionCard(
                                title = if (bn) "৭. ব্যবহার, সুবিধা ও সীমাবদ্ধতা" else "7. Applications, Pros & Limits"
                            ) {
                                BulletGroup(if (bn) "সাধারণ প্রয়োগ" else "Common Applications", comp.commonApplications(lang))
                                BulletGroup(if (bn) "বাস্তব উদাহরণ" else "Real-Life Examples", comp.realLifeExamples(lang))
                                BulletGroup(if (bn) "সুবিধা" else "Advantages", comp.advantages(lang))
                                BulletGroup(if (bn) "সীমাবদ্ধতা" else "Limitations", comp.limitations(lang))
                            }
                        }

                        // Common Mistakes & Safety Warning Card
                        item(key = "safety") {
                            Surface(
                                shape = MaterialTheme.shapes.medium,
                                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
                                modifier = Modifier.fillMaxWidth().testTag("detail_safety_card")
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = if (bn) "সাধারণ ভুল ও নিরাপত্তা নির্দেশনা" else "Common Mistakes & Safety Rules",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                    BulletGroup(if (bn) "এড়িয়ে চলার ভুলসমূহ" else "Common Mistakes", comp.commonMistakes(lang))
                                    BulletGroup(if (bn) "নিরাপত্তা নির্দেশনা" else "Safety Instructions", comp.safetyInstructions(lang))
                                }
                            }
                        }

                        // Related Components
                        if (uiState.relatedComponents.isNotEmpty()) {
                            item(key = "related") {
                                TextbookSectionCard(
                                    title = if (bn) "সম্পর্কিত কম্পোনেন্ট" else "Related Components"
                                ) {
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        uiState.relatedComponents.forEach { rel ->
                                            AssistChip(
                                                onClick = { onOpenRelated(rel.id) },
                                                label = { Text(rel.name(lang)) },
                                                modifier = Modifier.testTag("related_chip_${rel.id}")
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailHeaderCard(
    component: ElectronicComponent,
    language: AppLanguage,
    accent: androidx.compose.ui.graphics.Color,
    onToggleStudied: () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(component.payload.nameEn, style = MaterialTheme.typography.headlineSmall)
            Text(
                component.payload.nameBn,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                component.summary(language),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onToggleStudied,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (component.isStudied) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("detail_studied_button")
            ) {
                Icon(
                    imageVector = if (component.isStudied) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text(BookStrings.markAsStudied(language, component.isStudied))
            }
        }
    }
}

@Composable
private fun VisualLearningCard(
    component: ElectronicComponent,
    language: AppLanguage
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val bn = language == AppLanguage.BANGLA
    val tabs = listOf(
        if (bn) "চিত্র" else "Illustration",
        if (bn) "সার্কিট সিম্বল" else "Symbol",
        if (bn) "পিনআউট" else "Pinout"
    )
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth().testTag("detail_visual_card")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { idx, label ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        modifier = Modifier.testTag("visual_tab_$idx")
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.small)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    .padding(12.dp)
            ) {
                when (selectedTab) {
                    0 -> ComponentIllustrationCanvas(
                        illustrationType = component.payload.illustrationType,
                        modifier = Modifier.fillMaxWidth().height(170.dp)
                    )
                    1 -> CircuitSymbolCanvas(
                        symbolType = component.payload.symbolType,
                        modifier = Modifier.fillMaxWidth().height(170.dp)
                    )
                    else -> PinoutDiagramCanvas(
                        pinoutType = component.payload.pinoutType,
                        pins = component.payload.pinConfiguration,
                        language = language
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LevelExplanationCard(
    component: ElectronicComponent,
    language: AppLanguage,
    isAdvanced: Boolean,
    onSelectLevel: (Boolean) -> Unit
) {
    val bn = language == AppLanguage.BANGLA
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = !isAdvanced,
                    onClick = { onSelectLevel(false) },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    modifier = Modifier.testTag("level_beginner_button")
                ) {
                    Text(if (bn) "সহজ ব্যাখ্যা (Beginner)" else "Beginner Guide")
                }
                SegmentedButton(
                    selected = isAdvanced,
                    onClick = { onSelectLevel(true) },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    modifier = Modifier.testTag("level_advanced_button")
                ) {
                    Text(if (bn) "উচ্চতর তত্ত্ব (Advanced)" else "Advanced Deep-Dive")
                }
            }
            Text(
                text = if (isAdvanced) component.advancedExplanation(language) else component.beginnerExplanation(language),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun TextbookSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            content()
        }
    }
}

@Composable
private fun SubEntry(label: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun BulletGroup(header: String, items: List<String>) {
    if (items.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(header, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        items.forEach { line ->
            Text(
                text = "• $line",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
