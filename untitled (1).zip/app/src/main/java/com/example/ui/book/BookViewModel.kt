package com.example.ui.book

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.core.localization.SortOrder
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.repository.ComponentRepository
import com.example.domain.model.ComponentCategory
import com.example.domain.model.ElectronicComponent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CategoryProgress(
    val category: ComponentCategory,
    val totalCount: Int,
    val studiedCount: Int
)

data class BookUiState(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val searchQuery: String = "",
    val selectedCategory: ComponentCategory? = null,
    val sortOrder: SortOrder = SortOrder.CURATED,
    val allComponents: List<ElectronicComponent> = emptyList(),
    val filteredComponents: List<ElectronicComponent> = emptyList(),
    val featuredComponents: List<ElectronicComponent> = emptyList(),
    val recentlyViewed: List<ElectronicComponent> = emptyList(),
    val bookmarkedComponents: List<ElectronicComponent> = emptyList(),
    val continueLearningComponent: ElectronicComponent? = null,
    val categoryProgress: List<CategoryProgress> = emptyList(),
    val totalCount: Int = 0,
    val studiedCount: Int = 0
) {
    val progressFraction: Float
        get() = if (totalCount == 0) 0f else studiedCount.toFloat() / totalCount.toFloat()
}

class BookViewModel(
    private val repository: ComponentRepository,
    private val prefsStore: UserPrefsStore
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow<ComponentCategory?>(null)

    private val baseDataFlow = combine(
        repository.observeAllComponents(),
        repository.observeRecentlyViewed(limit = 8),
        repository.observeBookmarkedComponents(),
        prefsStore.language,
        prefsStore.sortOrder
    ) { all, recent, bookmarked, lang, sort ->
        BaseBookTuple(all, recent, bookmarked, lang, sort)
    }

    val uiState: StateFlow<BookUiState> = combine(
        baseDataFlow,
        _searchQuery,
        _selectedCategory
    ) { base, query, category ->
        val trimmed = query.trim().lowercase()

        val categoryMatched = if (category == null) {
            base.all
        } else {
            base.all.filter { it.category == category }
        }

        val searchMatched = if (trimmed.isEmpty()) {
            categoryMatched
        } else {
            categoryMatched.filter { item ->
                item.payload.nameEn.lowercase().contains(trimmed) ||
                    item.payload.nameBn.lowercase().contains(trimmed) ||
                    item.payload.summaryEn.lowercase().contains(trimmed) ||
                    item.payload.summaryBn.lowercase().contains(trimmed) ||
                    item.id.lowercase().contains(trimmed) ||
                    item.category.titleEn.lowercase().contains(trimmed) ||
                    item.category.titleBn.lowercase().contains(trimmed)
            }
        }

        val sorted = when (base.sortOrder) {
            SortOrder.CURATED -> searchMatched.sortedWith(
                compareBy<ElectronicComponent> { it.category.ordinal }.thenBy { it.payload.orderIndex }
            )
            SortOrder.ALPHABETICAL_AZ -> searchMatched.sortedBy { it.name(base.language).lowercase() }
            SortOrder.ALPHABETICAL_ZA -> searchMatched.sortedByDescending { it.name(base.language).lowercase() }
        }

        val progressList = ComponentCategory.entries.map { cat ->
            val items = base.all.filter { it.category == cat }
            CategoryProgress(
                category = cat,
                totalCount = items.size,
                studiedCount = items.count { it.isStudied }
            )
        }

        val continueItem = base.recent.firstOrNull { !it.isStudied }
            ?: base.recent.firstOrNull()
            ?: base.all.firstOrNull { !it.isStudied }
            ?: base.all.firstOrNull()

        BookUiState(
            language = base.language,
            searchQuery = query,
            selectedCategory = category,
            sortOrder = base.sortOrder,
            allComponents = base.all,
            filteredComponents = sorted,
            featuredComponents = base.all.filter { it.featured },
            recentlyViewed = base.recent,
            bookmarkedComponents = base.bookmarked,
            continueLearningComponent = continueItem,
            categoryProgress = progressList,
            totalCount = base.all.size,
            studiedCount = base.all.count { it.isStudied }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = BookUiState()
    )

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: ComponentCategory?) {
        _selectedCategory.value = category
    }

    fun updateSortOrder(order: SortOrder) {
        viewModelScope.launch {
            prefsStore.setSortOrder(order)
        }
    }

    fun toggleBookmark(id: String) {
        viewModelScope.launch {
            repository.toggleBookmark(id)
        }
    }

    private data class BaseBookTuple(
        val all: List<ElectronicComponent>,
        val recent: List<ElectronicComponent>,
        val bookmarked: List<ElectronicComponent>,
        val language: AppLanguage,
        val sortOrder: SortOrder
    )

    class Factory(
        private val repository: ComponentRepository,
        private val prefsStore: UserPrefsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BookViewModel(repository, prefsStore) as T
        }
    }
}
