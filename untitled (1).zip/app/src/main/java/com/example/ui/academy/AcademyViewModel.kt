package com.example.ui.academy

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.data.local.datastore.StreakInfo
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.repository.AcademyRepository
import com.example.data.repository.QuizRepository
import com.example.domain.model.AcademyCourse
import com.example.domain.model.LearningAchievement
import com.example.domain.model.Lesson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CourseProgressSummary(
    val course: AcademyCourse,
    val totalLessons: Int,
    val completedLessons: Int,
    val lessons: List<Lesson>
) {
    val fraction: Float
        get() = if (totalLessons <= 0) 0f else completedLessons.toFloat() / totalLessons.toFloat()
}

data class AcademyUiState(
    val isLoading: Boolean = true,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val searchQuery: String = "",
    val totalLessons: Int = 0,
    val completedLessons: Int = 0,
    val bookmarkedLessons: List<Lesson> = emptyList(),
    val continueLesson: Lesson? = null,
    val courseSummaries: List<CourseProgressSummary> = emptyList(),
    val searchResults: List<Lesson> = emptyList(),
    val streak: StreakInfo = StreakInfo(),
    val achievements: List<LearningAchievement> = emptyList()
)

class AcademyViewModel(
    private val academyRepository: AcademyRepository,
    quizRepository: QuizRepository,
    prefsStore: UserPrefsStore
) : ViewModel() {

    private val searchQueryFlow = MutableStateFlow("")

    init {
        viewModelScope.launch {
            academyRepository.initializeAcademy()
        }
    }

    val uiState: StateFlow<AcademyUiState> = combine(
        academyRepository.observeAllLessons(),
        academyRepository.observeContinueLearningLesson(),
        quizRepository.observeAchievements(),
        prefsStore.streakInfo,
        prefsStore.language,
        searchQueryFlow
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val allLessons = values[0] as List<Lesson>
        val continueLesson = values[1] as Lesson?
        @Suppress("UNCHECKED_CAST")
        val achievements = values[2] as List<LearningAchievement>
        val streak = values[3] as StreakInfo
        val language = values[4] as AppLanguage
        val query = values[5] as String

        val grouped = AcademyCourse.entries.map { course ->
            val list = allLessons.filter { it.course == course }.sortedBy { it.payload.orderIndex }
            CourseProgressSummary(
                course = course,
                totalLessons = list.size,
                completedLessons = list.count { it.isCompleted },
                lessons = list
            )
        }

        val q = query.trim().lowercase()
        val matches = if (q.isEmpty()) {
            emptyList()
        } else {
            allLessons.filter { lesson ->
                lesson.payload.titleEn.lowercase().contains(q) ||
                    lesson.payload.titleBn.lowercase().contains(q) ||
                    lesson.payload.introductionEn.lowercase().contains(q) ||
                    lesson.payload.introductionBn.lowercase().contains(q) ||
                    lesson.payload.englishBanglaTerms.any {
                        it.termEn.lowercase().contains(q) || it.meaningBn.lowercase().contains(q)
                    }
            }
        }

        AcademyUiState(
            isLoading = false,
            language = language,
            searchQuery = query,
            totalLessons = allLessons.size,
            completedLessons = allLessons.count { it.isCompleted },
            bookmarkedLessons = allLessons.filter { it.isBookmarked },
            continueLesson = continueLesson ?: allLessons.firstOrNull { !it.isCompleted } ?: allLessons.firstOrNull(),
            courseSummaries = grouped,
            searchResults = matches,
            streak = streak,
            achievements = achievements
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AcademyUiState()
    )

    fun updateSearchQuery(query: String) {
        searchQueryFlow.value = query
    }

    fun toggleBookmark(lessonId: String) {
        viewModelScope.launch {
            academyRepository.toggleLessonBookmark(lessonId)
        }
    }

    class Factory(
        private val academyRepository: AcademyRepository,
        private val quizRepository: QuizRepository,
        private val prefsStore: UserPrefsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AcademyViewModel(academyRepository, quizRepository, prefsStore) as T
        }
    }
}
