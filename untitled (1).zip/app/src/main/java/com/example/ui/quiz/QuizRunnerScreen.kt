package com.example.ui.quiz

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.localization.AcademyStrings
import com.example.core.localization.AppLanguage
import com.example.domain.model.AcademyCourse
import com.example.ui.components.CircuitSymbolCanvas
import com.example.ui.components.ComponentIllustrationCanvas
import com.example.ui.components.ConnectionDiagramCanvas

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizRunnerScreen(
    uiState: QuizRunnerUiState,
    onBack: () -> Unit,
    onSelectAnswer: (questionId: String, optionIndex: Int) -> Unit,
    onNextQuestion: () -> Unit,
    onPrevQuestion: () -> Unit,
    onSubmitQuiz: () -> Unit,
    onToggleReviewIncorrect: () -> Unit,
    onRetakeQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val lang = uiState.language
    val headerTitle = if (uiState.courseId == "ALL") {
        if (lang == AppLanguage.BANGLA) "পূর্ণ ইলেকট্রনিক্স পরীক্ষা" else "Full Timed Exam"
    } else {
        AcademyCourse.fromId(uiState.courseId).title(lang)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(headerTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(48.dp).testTag("quiz_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to Quiz Center")
                    }
                },
                actions = {
                    if (!uiState.isSubmitted && uiState.questions.isNotEmpty()) {
                        val secs = if (uiState.isTimedExam) uiState.remainingSeconds else uiState.elapsedSeconds
                        val mm = secs / 60
                        val ss = secs % 60
                        Surface(
                            shape = RoundedCornerShape(99.dp),
                            color = if (uiState.isTimedExam && secs < 60) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(end = 12.dp).testTag("quiz_timer_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Rounded.Timer, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text(
                                    text = String.format("%02d:%02d", mm, ss),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.TopCenter
        ) {
            if (uiState.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (lang == AppLanguage.BANGLA) "প্রশ্ন প্রস্তুত হচ্ছে..." else "Preparing questions...")
                }
                return@Box
            }

            if (uiState.questions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (lang == AppLanguage.BANGLA) "কোনো প্রশ্ন পাওয়া যায়নি।" else "No questions available.")
                }
                return@Box
            }

            if (!uiState.isSubmitted) {
                val question = uiState.currentQuestion ?: return@Box
                val chosen = uiState.selectedAnswers[question.id]
                val progress = (uiState.currentIndex + 1).toFloat() / uiState.questions.size.toFloat()

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 860.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(5.dp)
                    )

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .testTag("quiz_question_list"),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item(key = "q_meta_${question.id}") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Q ${uiState.currentIndex + 1} / ${uiState.questions.size}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = question.questionType,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        // Graphic Plate for COMPONENT_ID / CIRCUIT_ANALYSIS / Visual MCQ
                        if (question.visualIllustrationType != null || question.visualSymbolType != null || question.circuitDiagramType != null) {
                            item(key = "q_visual_${question.id}") {
                                Surface(
                                    shape = MaterialTheme.shapes.medium,
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        question.visualSymbolType?.let { sym ->
                                            Box(modifier = Modifier.weight(1f).height(110.dp)) {
                                                CircuitSymbolCanvas(symbolType = sym)
                                            }
                                        }
                                        question.visualIllustrationType?.let { ill ->
                                            Box(modifier = Modifier.weight(1f).height(110.dp)) {
                                                ComponentIllustrationCanvas(illustrationType = ill)
                                            }
                                        }
                                        question.circuitDiagramType?.let { diag ->
                                            if (question.visualSymbolType == null && question.visualIllustrationType == null) {
                                                ConnectionDiagramCanvas(diagramType = diag, language = lang)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item(key = "q_prompt_${question.id}") {
                            Text(
                                text = question.prompt(lang),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        question.options(lang).forEachIndexed { idx, opt ->
                            item(key = "q_${question.id}_opt_$idx") {
                                val selected = chosen == idx
                                Surface(
                                    shape = MaterialTheme.shapes.medium,
                                    color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        if (selected) 2.dp else 1.dp,
                                        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 52.dp)
                                        .clip(MaterialTheme.shapes.medium)
                                        .clickable { onSelectAnswer(question.id, idx) }
                                        .testTag("quiz_option_$idx")
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${('A' + idx)}. $opt",
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Bottom Navigation Bar for Runner
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onPrevQuestion,
                                enabled = uiState.currentIndex > 0,
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("quiz_prev_button")
                            ) {
                                Text(if (lang == AppLanguage.BANGLA) "পূর্ববর্তী" else "Prev")
                            }

                            if (uiState.currentIndex < uiState.questions.lastIndex) {
                                FilledTonalButton(
                                    onClick = onNextQuestion,
                                    modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("quiz_next_button")
                                ) {
                                    Text(if (lang == AppLanguage.BANGLA) "পরবর্তী" else "Next")
                                }
                            }

                            Button(
                                onClick = onSubmitQuiz,
                                modifier = Modifier.weight(1.2f).heightIn(min = 48.dp).testTag("quiz_submit_button")
                            ) {
                                Text(AcademyStrings.submitQuiz(lang), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            } else {
                // Graded Result & Review Incorrect Answers
                val pct = if (uiState.questions.isNotEmpty()) {
                    (uiState.score * 100) / uiState.questions.size
                } else 0
                val wrongSet = uiState.wrongQuestionIds.toSet()
                val displayedQuestions = if (uiState.reviewIncorrectOnly && wrongSet.isNotEmpty()) {
                    uiState.questions.filter { it.id in wrongSet }
                } else {
                    uiState.questions
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 860.dp)
                        .testTag("quiz_results_list"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item(key = "score_summary") {
                        Surface(
                            shape = MaterialTheme.shapes.large,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.5.dp,
                                if (pct >= 70) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("quiz_score_card")
                        ) {
                            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = if (lang == AppLanguage.BANGLA) {
                                        "ফলাফল: ${uiState.score} / ${uiState.questions.size} ($pct%)"
                                    } else {
                                        "Score: ${uiState.score} / ${uiState.questions.size} ($pct%)"
                                    },
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = if (pct >= 70) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = if (lang == AppLanguage.BANGLA) {
                                        "সময়: ${uiState.elapsedSeconds} সেকেন্ড • ভুল উত্তর: ${uiState.wrongQuestionIds.size}টি"
                                    } else {
                                        "Time: ${uiState.elapsedSeconds}s • Incorrect: ${uiState.wrongQuestionIds.size}"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (wrongSet.isNotEmpty()) {
                                        FilledTonalButton(
                                            onClick = onToggleReviewIncorrect,
                                            modifier = Modifier
                                                .weight(1f)
                                                .heightIn(min = 48.dp)
                                                .testTag("review_incorrect_toggle")
                                        ) {
                                            Text(
                                                text = if (uiState.reviewIncorrectOnly) {
                                                    if (lang == AppLanguage.BANGLA) "সব প্রশ্ন দেখুন" else "Show All Qs"
                                                } else {
                                                    AcademyStrings.reviewWrongAnswers(lang)
                                                },
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = onRetakeQuiz,
                                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("quiz_retake_button")
                                    ) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (lang == AppLanguage.BANGLA) "আবার দিন" else "Retake")
                                    }
                                }

                                Button(
                                    onClick = onBack,
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("quiz_done_button")
                                ) {
                                    Text(if (lang == AppLanguage.BANGLA) "কুইজ কেন্দ্রে ফিরুন" else "Back to Quiz Center")
                                }
                            }
                        }
                    }

                    items(displayedQuestions, key = { "rev_${it.id}" }) { q ->
                        val chosenIdx = uiState.selectedAnswers[q.id]
                        val isCorrect = chosenIdx == q.correctIndex
                        val opts = q.options(lang)
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                if (isCorrect) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("review_card_${q.id}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.CheckCircle,
                                        contentDescription = null,
                                        tint = if (isCorrect) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = q.prompt(lang),
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                if (chosenIdx != null && !isCorrect) {
                                    Text(
                                        text = if (lang == AppLanguage.BANGLA) {
                                            "আপনার উত্তর: ${opts.getOrNull(chosenIdx) ?: "-"}"
                                        } else {
                                            "Your answer: ${opts.getOrNull(chosenIdx) ?: "-"}"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                Text(
                                    text = if (lang == AppLanguage.BANGLA) {
                                        "সঠিক উত্তর: ${opts.getOrNull(q.correctIndex) ?: "-"}"
                                    } else {
                                        "Correct answer: ${opts.getOrNull(q.correctIndex) ?: "-"}"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = q.explanation(lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
