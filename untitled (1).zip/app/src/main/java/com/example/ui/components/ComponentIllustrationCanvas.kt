package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.rememberTextMeasurer

@Composable
fun ComponentIllustrationCanvas(
    illustrationType: String,
    modifier: Modifier = Modifier,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    amberColor: Color = MaterialTheme.colorScheme.secondary,
    emeraldColor: Color = MaterialTheme.colorScheme.tertiary,
    onSurfaceColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val textMeasurer = rememberTextMeasurer()
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val leadColor = Color(0xFFCBD5E1)
        val pcbBlue = Color(0xFF0E4D92)
        val pcbGreen = Color(0xFF065F46)

        when (illustrationType) {
            "RESISTOR_AXIAL" -> {
                drawLine(leadColor, Offset(w * 0.06f, cy), Offset(w * 0.94f, cy), 4f, StrokeCap.Round)
                drawRoundRect(Color(0xFFD6B98C), Offset(w * 0.24f, cy - h * 0.14f), Size(w * 0.52f, h * 0.28f), CornerRadius(14f, 14f))
                // 1k Ohm 4-band Brown-Black-Red-Gold
                val bands = listOf(Color(0xFF78350F), Color(0xFF0F172A), Color(0xFFDC2626), Color(0xFFF59E0B))
                val xs = listOf(0.32f, 0.42f, 0.52f, 0.66f)
                bands.forEachIndexed { idx, col ->
                    drawRect(col, Offset(w * xs[idx], cy - h * 0.14f), Size(w * 0.045f, h * 0.28f))
                }
            }
            "TRIMMER_PRESET" -> {
                drawRoundRect(Color(0xFF2563EB), Offset(w * 0.30f, h * 0.20f), Size(w * 0.40f, h * 0.48f), CornerRadius(8f, 8f))
                drawCircle(Color(0xFFE2E8F0), w * 0.10f, Offset(cx, h * 0.44f))
                drawLine(Color(0xFF334155), Offset(cx - w * 0.06f, h * 0.44f), Offset(cx + w * 0.06f, h * 0.44f), 3f)
                for (dx in listOf(-0.12f, 0f, 0.12f)) {
                    drawLine(leadColor, Offset(cx + w * dx, h * 0.68f), Offset(cx + w * dx, h * 0.88f), 4f)
                }
            }
            "POTENTIOMETER_ROTARY" -> {
                drawCircle(Color(0xFF64748B), w.coerceAtMost(h) * 0.26f, Offset(cx, cy - h * 0.05f))
                drawCircle(Color(0xFFCBD5E1), w.coerceAtMost(h) * 0.13f, Offset(cx, cy - h * 0.05f))
                drawLine(Color(0xFF334155), Offset(cx, cy - h * 0.16f), Offset(cx, cy + h * 0.06f), 4f)
                for (dx in listOf(-0.14f, 0f, 0.14f)) {
                    drawLine(leadColor, Offset(cx + w * dx, cy + h * 0.22f), Offset(cx + w * dx, h * 0.88f), 5f)
                }
            }
            "CAPACITOR_CERAMIC", "CAPACITOR_GENERIC" -> {
                drawLine(leadColor, Offset(cx - w * 0.08f, h * 0.56f), Offset(cx - w * 0.08f, h * 0.88f), 4f)
                drawLine(leadColor, Offset(cx + w * 0.08f, h * 0.56f), Offset(cx + w * 0.08f, h * 0.88f), 4f)
                drawOval(Color(0xFFD97706), Offset(cx - w * 0.18f, h * 0.18f), Size(w * 0.36f, h * 0.42f))
                drawCanvasLabel(textMeasurer, "104", Offset(cx - w * 0.08f, h * 0.34f), Color.Black)
            }
            "CAPACITOR_ELECTROLYTIC" -> {
                drawLine(leadColor, Offset(cx - w * 0.08f, h * 0.66f), Offset(cx - w * 0.08f, h * 0.90f), 4f)
                drawLine(leadColor, Offset(cx + w * 0.08f, h * 0.66f), Offset(cx + w * 0.08f, h * 0.82f), 4f)
                drawRoundRect(Color(0xFF1E293B), Offset(cx - w * 0.16f, h * 0.16f), Size(w * 0.32f, h * 0.52f), CornerRadius(10f, 10f))
                drawRect(Color(0xFFE2E8F0), Offset(cx + w * 0.07f, h * 0.18f), Size(w * 0.07f, h * 0.48f))
                drawCanvasLabel(textMeasurer, "−", Offset(cx + w * 0.08f, h * 0.34f), Color.Black)
            }
            "CAPACITOR_FILM" -> {
                drawLine(leadColor, Offset(cx - w * 0.14f, h * 0.64f), Offset(cx - w * 0.14f, h * 0.88f), 4f)
                drawLine(leadColor, Offset(cx + w * 0.14f, h * 0.64f), Offset(cx + w * 0.14f, h * 0.88f), 4f)
                drawRoundRect(Color(0xFFDC2626), Offset(cx - w * 0.22f, h * 0.20f), Size(w * 0.44f, h * 0.46f), CornerRadius(12f, 12f))
                drawCanvasLabel(textMeasurer, "105K", Offset(cx - w * 0.12f, h * 0.38f), Color.White)
            }
            "INDUCTOR_COIL" -> {
                drawLine(leadColor, Offset(w * 0.08f, cy), Offset(w * 0.92f, cy), 4f)
                drawCircle(Color(0xFF334155), w.coerceAtMost(h) * 0.26f, Offset(cx, cy), style = Stroke(14f))
                for (i in 0..5) {
                    val x = cx - w * 0.16f + i * w * 0.06f
                    drawLine(Color(0xFFD97706), Offset(x, cy - h * 0.24f), Offset(x + w * 0.02f, cy + h * 0.24f), 4f)
                }
            }
            "TRANSFORMER_IRON" -> {
                drawRect(Color(0xFF64748B), Offset(w * 0.24f, h * 0.18f), Size(w * 0.52f, h * 0.64f))
                drawRoundRect(Color(0xFFB45309), Offset(w * 0.34f, h * 0.26f), Size(w * 0.32f, h * 0.48f), CornerRadius(6f, 6f))
                for (y in listOf(0.32f, 0.68f)) {
                    drawLine(amberColor, Offset(w * 0.10f, h * y), Offset(w * 0.24f, h * y), 4f)
                    drawLine(primaryColor, Offset(w * 0.76f, h * y), Offset(w * 0.90f, h * y), 4f)
                }
            }
            "THERMISTOR_DISC", "VARISTOR_DISC" -> {
                val discColor = if (illustrationType == "VARISTOR_DISC") Color(0xFF2563EB) else Color(0xFF1E293B)
                drawLine(leadColor, Offset(cx - w * 0.09f, h * 0.58f), Offset(cx - w * 0.09f, h * 0.88f), 4f)
                drawLine(leadColor, Offset(cx + w * 0.09f, h * 0.58f), Offset(cx + w * 0.09f, h * 0.88f), 4f)
                drawCircle(discColor, w.coerceAtMost(h) * 0.22f, Offset(cx, h * 0.40f))
            }
            "LDR_CADMIUM" -> {
                drawLine(leadColor, Offset(cx - w * 0.09f, h * 0.56f), Offset(cx - w * 0.09f, h * 0.88f), 4f)
                drawLine(leadColor, Offset(cx + w * 0.09f, h * 0.56f), Offset(cx + w * 0.09f, h * 0.88f), 4f)
                drawCircle(Color(0xFFFDE68A), w.coerceAtMost(h) * 0.22f, Offset(cx, h * 0.40f))
                drawLine(Color(0xFFB45309), Offset(cx - w * 0.13f, h * 0.36f), Offset(cx + w * 0.13f, h * 0.36f), 4f)
                drawLine(Color(0xFFB45309), Offset(cx - w * 0.13f, h * 0.44f), Offset(cx + w * 0.13f, h * 0.44f), 4f)
            }
            "DIODE_AXIAL", "DIODE_GLASS_ZENER", "DIODE_GLASS_DIAC" -> {
                drawLine(leadColor, Offset(w * 0.08f, cy), Offset(w * 0.92f, cy), 4f)
                val bodyCol = if (illustrationType == "DIODE_AXIAL") Color(0xFF1E293B) else Color(0xFFEA580C)
                drawRoundRect(bodyCol, Offset(w * 0.26f, cy - h * 0.14f), Size(w * 0.48f, h * 0.28f), CornerRadius(6f, 6f))
                if (illustrationType != "DIODE_GLASS_DIAC") {
                    drawRect(Color(0xFFE2E8F0), Offset(w * 0.64f, cy - h * 0.14f), Size(w * 0.06f, h * 0.28f))
                }
            }
            "LED_5MM", "LED_RGB_4PIN", "SENSOR_FLAME_LED" -> {
                val domeCol = when (illustrationType) {
                    "LED_RGB_4PIN" -> Color(0xFFE2E8F0)
                    "SENSOR_FLAME_LED" -> Color(0xFF1E1B4B)
                    else -> Color(0xFFEF4444)
                }
                val pins = if (illustrationType == "LED_RGB_4PIN") listOf(-0.12f, -0.04f, 0.04f, 0.12f) else listOf(-0.06f, 0.06f)
                pins.forEachIndexed { i, dx ->
                    val len = if (i == 0 || (illustrationType == "LED_RGB_4PIN" && i == 1)) 0.90f else 0.80f
                    drawLine(leadColor, Offset(cx + w * dx, h * 0.56f), Offset(cx + w * dx, h * len), 4f)
                }
                drawArc(domeCol, 180f, 180f, true, Offset(cx - w * 0.16f, h * 0.16f), Size(w * 0.32f, h * 0.34f))
                drawRect(domeCol, Offset(cx - w * 0.16f, h * 0.33f), Size(w * 0.32f, h * 0.22f))
                drawRoundRect(domeCol.copy(alpha = 0.85f), Offset(cx - w * 0.19f, h * 0.52f), Size(w * 0.38f, h * 0.07f), CornerRadius(3f, 3f))
            }
            "TRANSISTOR_TO92" -> {
                for (dx in listOf(-0.10f, 0f, 0.10f)) {
                    drawLine(leadColor, Offset(cx + w * dx, h * 0.52f), Offset(cx + w * dx, h * 0.88f), 4f)
                }
                drawRoundRect(Color(0xFF1E293B), Offset(cx - w * 0.16f, h * 0.20f), Size(w * 0.32f, h * 0.34f), CornerRadius(12f, 12f))
                drawCanvasLabel(textMeasurer, "TO-92", Offset(cx - w * 0.11f, h * 0.32f), Color.White)
            }
            "TRANSISTOR_TO220", "TRANSISTOR_TO247" -> {
                drawRect(Color(0xFF94A3B8), Offset(cx - w * 0.16f, h * 0.12f), Size(w * 0.32f, h * 0.20f))
                drawCircle(Color(0xFF0F172A), w * 0.045f, Offset(cx, h * 0.20f))
                drawRect(Color(0xFF1E293B), Offset(cx - w * 0.18f, h * 0.28f), Size(w * 0.36f, h * 0.34f))
                for (dx in listOf(-0.11f, 0f, 0.11f)) {
                    drawLine(leadColor, Offset(cx + w * dx, h * 0.62f), Offset(cx + w * dx, h * 0.90f), 5f)
                }
            }
            "BRIDGE_KBPC", "MODULE_IGBT_BLOCK" -> {
                drawRoundRect(Color(0xFF1E293B), Offset(w * 0.24f, h * 0.20f), Size(w * 0.52f, h * 0.58f), CornerRadius(8f, 8f))
                drawCircle(Color(0xFF94A3B8), w * 0.055f, Offset(cx, cy))
                drawCanvasLabel(textMeasurer, "+  ~", Offset(w * 0.28f, h * 0.24f), Color.White)
                drawCanvasLabel(textMeasurer, "~  −", Offset(w * 0.28f, h * 0.62f), Color.White)
            }
            "IC_DIP8", "IC_DIP14", "IC_DIP16", "IC_DIP28_MCU" -> {
                val pinCountPerSide = when (illustrationType) {
                    "IC_DIP8" -> 4
                    "IC_DIP14" -> 7
                    "IC_DIP16" -> 8
                    else -> 10
                }
                val bodyW = if (illustrationType == "IC_DIP28_MCU") w * 0.64f else w * 0.44f
                val left = cx - bodyW / 2f
                drawRoundRect(Color(0xFF1E293B), Offset(left, h * 0.30f), Size(bodyW, h * 0.40f), CornerRadius(6f, 6f))
                drawArc(Color(0xFF64748B), -90f, 180f, true, Offset(left - w * 0.03f, cy - h * 0.07f), Size(w * 0.06f, h * 0.14f))
                val step = bodyW / (pinCountPerSide + 0.5f)
                for (i in 0 until pinCountPerSide) {
                    val px = left + step * (i + 0.75f)
                    drawRect(leadColor, Offset(px - 3f, h * 0.18f), Size(6f, h * 0.12f))
                    drawRect(leadColor, Offset(px - 3f, h * 0.70f), Size(6f, h * 0.12f))
                }
            }
            "RELAY_CUBE" -> {
                drawRoundRect(Color(0xFF0284C7), Offset(w * 0.26f, h * 0.18f), Size(w * 0.48f, h * 0.54f), CornerRadius(8f, 8f))
                drawCanvasLabel(textMeasurer, "5V 10A", Offset(cx - w * 0.14f, h * 0.38f), Color.White)
                for (dx in listOf(-0.14f, 0f, 0.14f)) {
                    drawLine(leadColor, Offset(cx + w * dx, h * 0.72f), Offset(cx + w * dx, h * 0.88f), 5f)
                }
            }
            "SWITCH_TACTILE" -> {
                drawRoundRect(Color(0xFF94A3B8), Offset(w * 0.30f, h * 0.28f), Size(w * 0.40f, h * 0.44f), CornerRadius(6f, 6f))
                drawCircle(Color(0xFF1E293B), w.coerceAtMost(h) * 0.12f, Offset(cx, cy))
                for (px in listOf(0.22f, 0.78f)) {
                    drawLine(leadColor, Offset(w * px, h * 0.36f), Offset(w * 0.30f, h * 0.36f), 4f)
                    drawLine(leadColor, Offset(w * px, h * 0.64f), Offset(w * 0.30f, h * 0.64f), 4f)
                }
            }
            "MOTOR_DC_BODY", "MOTOR_STEPPER_NEMA", "SOLENOID_VALVE" -> {
                drawLine(leadColor, Offset(w * 0.08f, cy), Offset(w * 0.24f, cy), 6f)
                val bodyCol = if (illustrationType == "MOTOR_STEPPER_NEMA") Color(0xFF1E293B) else Color(0xFF94A3B8)
                drawRoundRect(bodyCol, Offset(w * 0.24f, h * 0.24f), Size(w * 0.52f, h * 0.52f), CornerRadius(10f, 10f))
                drawCanvasLabel(textMeasurer, if (illustrationType == "SOLENOID_VALVE") "SOL" else "M", Offset(cx - w * 0.04f, cy - h * 0.07f), Color.White)
            }
            "SERVO_SG90" -> {
                drawRoundRect(Color(0xFF2563EB), Offset(w * 0.24f, h * 0.34f), Size(w * 0.50f, h * 0.40f), CornerRadius(6f, 6f))
                drawCircle(Color.White, w * 0.09f, Offset(w * 0.38f, h * 0.24f))
                drawRoundRect(Color.White, Offset(w * 0.34f, h * 0.12f), Size(w * 0.08f, h * 0.24f), CornerRadius(6f, 6f))
            }
            "BUZZER_ROUND", "SPEAKER_CONE", "MIC_ELECTRET" -> {
                drawCircle(Color(0xFF1E293B), w.coerceAtMost(h) * 0.30f, Offset(cx, cy))
                drawCircle(Color(0xFF475569), w.coerceAtMost(h) * 0.14f, Offset(cx, cy))
                drawCircle(Color(0xFF0F172A), w.coerceAtMost(h) * 0.05f, Offset(cx, cy))
            }
            "SENSOR_HC_SR04" -> {
                drawRoundRect(pcbBlue, Offset(w * 0.14f, h * 0.26f), Size(w * 0.72f, h * 0.44f), CornerRadius(8f, 8f))
                drawCircle(Color(0xFFCBD5E1), w * 0.12f, Offset(w * 0.32f, h * 0.48f))
                drawCircle(Color(0xFF334155), w * 0.07f, Offset(w * 0.32f, h * 0.48f))
                drawCircle(Color(0xFFCBD5E1), w * 0.12f, Offset(w * 0.68f, h * 0.48f))
                drawCircle(Color(0xFF334155), w * 0.07f, Offset(w * 0.68f, h * 0.48f))
            }
            "SENSOR_PIR_DOME" -> {
                drawRoundRect(pcbGreen, Offset(w * 0.20f, h * 0.56f), Size(w * 0.60f, h * 0.20f), CornerRadius(4f, 4f))
                drawArc(Color(0xFFF1F5F9), 180f, 180f, true, Offset(w * 0.26f, h * 0.20f), Size(w * 0.48f, h * 0.72f))
            }
            "SENSOR_MQ_GAS" -> {
                drawRoundRect(pcbBlue, Offset(w * 0.18f, h * 0.48f), Size(w * 0.64f, h * 0.28f), CornerRadius(6f, 6f))
                drawCircle(Color(0xFF94A3B8), w.coerceAtMost(h) * 0.18f, Offset(cx, h * 0.38f))
            }
            "SENSOR_DHT", "SENSOR_TOUCH_TTP223", "SENSOR_IR_PAIR", "SENSOR_RAIN_PAD", "SENSOR_SOIL_FORK", "MODULE_BREAKOUT" -> {
                val c = if (illustrationType == "SENSOR_DHT") Color(0xFF0284C7) else if (illustrationType == "SENSOR_TOUCH_TTP223") Color(0xFFDC2626) else pcbBlue
                drawRoundRect(c, Offset(w * 0.26f, h * 0.20f), Size(w * 0.48f, h * 0.54f), CornerRadius(8f, 8f))
                drawCircle(Color(0xFFF59E0B), w * 0.06f, Offset(cx, h * 0.40f))
                for (dx in listOf(-0.12f, 0f, 0.12f)) {
                    drawLine(leadColor, Offset(cx + w * dx, h * 0.74f), Offset(cx + w * dx, h * 0.90f), 4f)
                }
            }
            "MODULE_BUCK_LM2596", "MODULE_TP4056", "MODULE_BMS", "MODULE_SMPS", "MODULE_INVERTER" -> {
                drawRoundRect(pcbBlue, Offset(w * 0.16f, h * 0.24f), Size(w * 0.68f, h * 0.52f), CornerRadius(8f, 8f))
                drawRect(Color(0xFF1E293B), Offset(w * 0.26f, h * 0.34f), Size(w * 0.18f, h * 0.26f))
                drawCircle(amberColor, w * 0.08f, Offset(w * 0.62f, cy))
            }
            "DISPLAY_7SEG_1DIGIT" -> {
                drawRoundRect(Color(0xFF0F172A), Offset(w * 0.30f, h * 0.16f), Size(w * 0.40f, h * 0.68f), CornerRadius(6f, 6f))
                drawCanvasLabel(textMeasurer, "8.", Offset(cx - w * 0.08f, cy - h * 0.16f), Color(0xFFEF4444), fontSizeSp = 22f)
            }
            "DISPLAY_LCD_16X2" -> {
                drawRoundRect(pcbGreen, Offset(w * 0.10f, h * 0.22f), Size(w * 0.80f, h * 0.56f), CornerRadius(6f, 6f))
                drawRect(Color(0xFF84CC16), Offset(w * 0.18f, h * 0.32f), Size(w * 0.64f, h * 0.36f))
                drawCanvasLabel(textMeasurer, "CIRCUIT WIZARD", Offset(w * 0.21f, h * 0.44f), Color(0xFF064E3B), fontSizeSp = 9f)
            }
            "DISPLAY_OLED_096", "DISPLAY_TFT_SPI" -> {
                drawRoundRect(pcbBlue, Offset(w * 0.20f, h * 0.18f), Size(w * 0.60f, h * 0.64f), CornerRadius(8f, 8f))
                drawRect(Color(0xFF020617), Offset(w * 0.26f, h * 0.26f), Size(w * 0.48f, h * 0.42f))
                drawCanvasLabel(textMeasurer, if (illustrationType == "DISPLAY_OLED_096") "OLED" else "TFT", Offset(cx - w * 0.10f, cy - h * 0.08f), primaryColor)
            }
            "DISPLAY_MATRIX_8X8" -> {
                drawRoundRect(Color(0xFF1E293B), Offset(w * 0.26f, h * 0.18f), Size(w * 0.48f, h * 0.64f), CornerRadius(6f, 6f))
                for (r in 0..3) {
                    for (c in 0..3) {
                        drawCircle(Color(0xFFEF4444), 4f, Offset(w * 0.34f + c * w * 0.10f, h * 0.28f + r * h * 0.13f))
                    }
                }
            }
            "MODULE_HC05", "MODULE_ESP01", "MODULE_ESP_SHIELDED", "MODULE_RF_NRF24", "MODULE_GSM_SIM", "MODULE_GPS_PATCH", "MODULE_RFID_RC522", "MODULE_LORA_SX1278" -> {
                drawRoundRect(pcbBlue, Offset(w * 0.20f, h * 0.20f), Size(w * 0.60f, h * 0.60f), CornerRadius(8f, 8f))
                drawRect(Color(0xFF94A3B8), Offset(w * 0.28f, h * 0.30f), Size(w * 0.44f, h * 0.32f))
                drawCanvasLabel(textMeasurer, "RF", Offset(cx - w * 0.06f, h * 0.40f), Color(0xFF0F172A))
            }
            "BOARD_ARDUINO_UNO", "BOARD_ESP32_DEVKIT", "BOARD_NANO_STICK", "BOARD_RPI_PICO" -> {
                val bCol = when (illustrationType) {
                    "BOARD_ARDUINO_UNO" -> Color(0xFF00979D)
                    "BOARD_RPI_PICO" -> pcbGreen
                    "BOARD_ESP32_DEVKIT" -> Color(0xFF1E293B)
                    else -> pcbBlue
                }
                drawRoundRect(bCol, Offset(w * 0.14f, h * 0.20f), Size(w * 0.72f, h * 0.60f), CornerRadius(10f, 10f))
                drawRect(Color(0xFF94A3B8), Offset(w * 0.10f, h * 0.38f), Size(w * 0.12f, h * 0.24f))
                drawRect(Color(0xFF0F172A), Offset(w * 0.42f, h * 0.36f), Size(w * 0.22f, h * 0.28f))
                for (i in 0..5) {
                    drawCircle(amberColor, 3.5f, Offset(w * 0.28f + i * w * 0.09f, h * 0.24f))
                    drawCircle(amberColor, 3.5f, Offset(w * 0.28f + i * w * 0.09f, h * 0.76f))
                }
            }
            "CONN_JST_HEADER", "CONN_USB_PORT", "CONN_USB_C", "CONN_HDMI", "CONN_RJ45", "CONN_TERMINAL_BLOCK" -> {
                val shellCol = if (illustrationType == "CONN_TERMINAL_BLOCK") Color(0xFF16A34A) else Color(0xFF94A3B8)
                drawRoundRect(shellCol, Offset(w * 0.22f, h * 0.26f), Size(w * 0.56f, h * 0.48f), CornerRadius(10f, 10f))
                drawRoundRect(Color(0xFF0F172A), Offset(w * 0.30f, h * 0.38f), Size(w * 0.40f, h * 0.24f), CornerRadius(6f, 6f))
            }
            "CONN_JUMPER_WIRES" -> {
                val cols = listOf(Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFF3B82F6))
                cols.forEachIndexed { idx, col ->
                    val y = h * 0.28f + idx * h * 0.14f
                    drawLine(col, Offset(w * 0.14f, y), Offset(w * 0.86f, y), 6f)
                    drawRect(Color(0xFF0F172A), Offset(w * 0.12f, y - 6f), Size(w * 0.09f, 12f))
                    drawRect(Color(0xFF0F172A), Offset(w * 0.79f, y - 6f), Size(w * 0.09f, 12f))
                }
            }
            "CONN_BREADBOARD" -> {
                drawRoundRect(Color(0xFFF1F5F9), Offset(w * 0.12f, h * 0.20f), Size(w * 0.76f, h * 0.60f), CornerRadius(8f, 8f))
                drawLine(Color(0xFFEF4444), Offset(w * 0.15f, h * 0.26f), Offset(w * 0.85f, h * 0.26f), 3f)
                drawLine(Color(0xFF2563EB), Offset(w * 0.15f, h * 0.74f), Offset(w * 0.85f, h * 0.74f), 3f)
                drawRect(Color(0xFFCBD5E1), Offset(w * 0.14f, cy - 4f), Size(w * 0.72f, 8f))
            }
            "CONN_PCB_BOARD" -> {
                drawRoundRect(pcbGreen, Offset(w * 0.16f, h * 0.20f), Size(w * 0.68f, h * 0.60f), CornerRadius(8f, 8f))
                drawLine(amberColor, Offset(w * 0.26f, h * 0.34f), Offset(w * 0.56f, h * 0.34f), 4f)
                drawLine(amberColor, Offset(w * 0.56f, h * 0.34f), Offset(w * 0.68f, h * 0.56f), 4f)
                drawCircle(amberColor, 6f, Offset(w * 0.26f, h * 0.34f))
                drawCircle(amberColor, 6f, Offset(w * 0.68f, h * 0.56f))
            }
            "PROT_FUSE_GLASS", "PROT_THERMAL_FUSE" -> {
                drawLine(leadColor, Offset(w * 0.06f, cy), Offset(w * 0.94f, cy), 4f)
                drawRoundRect(Color(0xFF94A3B8), Offset(w * 0.20f, cy - h * 0.14f), Size(w * 0.14f, h * 0.28f), CornerRadius(4f, 4f))
                drawRoundRect(Color(0xFF94A3B8), Offset(w * 0.66f, cy - h * 0.14f), Size(w * 0.14f, h * 0.28f), CornerRadius(4f, 4f))
                drawRect(Color(0xFFE2E8F0).copy(alpha = 0.45f), Offset(w * 0.34f, cy - h * 0.12f), Size(w * 0.32f, h * 0.24f))
            }
            "PROT_MCB_BREAKER", "PROT_RCCB_BREAKER", "PROT_SPD_MODULE" -> {
                drawRoundRect(Color(0xFFE2E8F0), Offset(w * 0.26f, h * 0.14f), Size(w * 0.48f, h * 0.72f), CornerRadius(8f, 8f))
                val leverCol = if (illustrationType == "PROT_SPD_MODULE") Color(0xFFEF4444) else Color(0xFF0284C7)
                drawRoundRect(leverCol, Offset(w * 0.34f, h * 0.40f), Size(w * 0.32f, h * 0.18f), CornerRadius(4f, 4f))
                if (illustrationType == "PROT_RCCB_BREAKER") {
                    drawCircle(amberColor, w * 0.05f, Offset(w * 0.62f, h * 0.28f))
                }
            }
            else -> {
                drawRoundRect(primaryColor.copy(alpha = 0.2f), Offset(w * 0.22f, h * 0.22f), Size(w * 0.56f, h * 0.56f), CornerRadius(12f, 12f))
                drawCanvasLabel(textMeasurer, "PART", Offset(cx - w * 0.10f, cy - h * 0.08f), onSurfaceColor)
            }
        }
    }
}
