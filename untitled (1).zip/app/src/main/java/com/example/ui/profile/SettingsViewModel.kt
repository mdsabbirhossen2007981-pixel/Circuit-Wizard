package com.example.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.localization.AppLanguage
import com.example.data.local.datastore.StreakInfo
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.repository.AcademyRepository
import com.example.data.repository.ComponentRepository
import com.example.data.repository.QuizRepository
import com.example.domain.model.AcademyCourse
import com.example.domain.model.ComponentCategory
import com.example.domain.model.ElectronicComponent
import com.example.domain.model.LearningAchievement
import com.example.domain.model.Lesson
import com.example.ui.book.CategoryProgress
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AcademyCourseProgressItem(
    val course: AcademyCourse,
    val totalLessons: Int,
    val completedLessons: Int
)

data class SettingsUiState(
    val isDarkTheme: Boolean = true,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val totalComponents: Int = 0,
    val studiedComponents: Int = 0,
    val bookmarkedComponents: Int = 0,
    val categoryProgress: List<CategoryProgress> = emptyList(),
    val totalLessons: Int = 0,
    val completedLessons: Int = 0,
    val bookmarkedLessons: Int = 0,
    val savedNotesCount: Int = 0,
    val academyProgress: List<AcademyCourseProgressItem> = emptyList(),
    val streak: StreakInfo = StreakInfo(),
    val achievements: List<LearningAchievement> = emptyList()
)

class SettingsViewModel(
    private val prefsStore: UserPrefsStore,
    repository: ComponentRepository,
    academyRepository: AcademyRepository,
    quizRepository: QuizRepository
) : ViewModel() {

    val uiState: StateFlow<SettingsUiState> = combine(
        prefsStore.isDarkTheme,
        prefsStore.language,
        repository.observeAllComponents(),
        academyRepository.observeAllLessons(),
        academyRepository.observeAllNotes(),
        prefsStore.streakInfo,
        quizRepository.observeAchievements()
    ) { values ->
        val dark = values[0] as Boolean
        val lang = values[1] as AppLanguage
        @Suppress("UNCHECKED_CAST")
        val components = values[2] as List<ElectronicComponent>
        @Suppress("UNCHECKED_CAST")
        val lessons = values[3] as List<Lesson>
        @Suppress("UNCHECKED_CAST")
        val notes = values[4] as List<*>
        val streak = values[5] as StreakInfo
        @Suppress("UNCHECKED_CAST")
        val achievements = values[6] as List<LearningAchievement>

        val breakdown = ComponentCategory.entries.map { cat ->
            val items = components.filter { it.category == cat }
            CategoryProgress(
                category = cat,
                totalCount = items.size,
                studiedCount = items.count { it.isStudied }
            )
        }
        val academyBreakdown = AcademyCourse.entries.map { course ->
            val items = lessons.filter { it.course == course }
            AcademyCourseProgressItem(
                course = course,
                totalLessons = items.size,
                completedLessons = items.count { it.isCompleted }
            )
        }
        SettingsUiState(
            isDarkTheme = dark,
            language = lang,
            totalComponents = components.size,
            studiedComponents = components.count { it.isStudied },
            bookmarkedComponents = components.count { it.isBookmarked },
            categoryProgress = breakdown,
            totalLessons = lessons.size,
            completedLessons = lessons.count { it.isCompleted },
            bookmarkedLessons = lessons.count { it.isBookmarked },
            savedNotesCount = notes.size,
            academyProgress = academyBreakdown,
            streak = streak,
            achievements = achievements
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState()
    )

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            prefsStore.setDarkTheme(enabled)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsStore.setLanguage(language)
        }
    }

    class Factory(
        private val prefsStore: UserPrefsStore,
        private val repository: ComponentRepository,
        private val academyRepository: AcademyRepository,
        private val quizRepository: QuizRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(prefsStore, repository, academyRepository, quizRepository) as T
        }
    }
}
