package com.example.simulation

import com.example.domain.lab.LabComponentCatalog
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabPinSpec
import com.example.domain.model.PlacedComponent
import kotlin.math.roundToInt

enum class SimulationStatus {
    STOPPED,
    RUNNING,
    PAUSED
}

enum class ComponentSupportLevel(val labelEn: String, val labelBn: String) {
    FULLY_SIMULATED("Fully Simulated", "সম্পূর্ণ সিমুলেটেড"),
    PARTIALLY_SIMULATED("Partially Simulated", "আংশিক সিমুলেটেড"),
    VISUAL_ONLY("Visual Only", "শুধুমাত্র ভিজ্যুয়াল"),
    NOT_SUPPORTED("Not Supported", "সমর্থিত নয়")
}

data class ComponentModelSupportInfo(
    val typeId: String,
    val nameEn: String,
    val supportLevel: ComponentSupportLevel,
    val notesEn: String
)

enum class WarningCategory {
    SHORT_CIRCUIT,
    EXCESSIVE_CURRENT,
    REVERSE_POLARITY,
    POWER_RATING_EXCEEDED,
    CAPACITOR_OVERVOLTAGE,
    OPEN_CIRCUIT,
    FLOATING_NODE,
    HIGH_VOLTAGE_SAFETY,
    SOLVER_ERROR,
    UNSUPPORTED_PART
}

enum class SafetySeverity {
    INFO,
    WARNING,
    CRITICAL
}

data class SimulationWarning(
    val category: WarningCategory,
    val severity: SafetySeverity,
    val componentId: String?,
    val messageEn: String
)

data class ComponentSimulationReading(
    val instanceId: String,
    val typeId: String,
    val voltageDropV: Double = 0.0,
    val currentMa: Double = 0.0,
    val powerMw: Double = 0.0,
    val effectiveResistanceOhms: Double? = null,
    val brightnessFraction: Float = 0f, // 0f..1f for LEDs
    val isConducting: Boolean = false,
    val isReverseBiased: Boolean = false,
    val isFloating: Boolean = false,
    val motorRpm: Float = 0f,
    val relayEnergized: Boolean = false,
    val pinVoltagesV: Map<String, Double> = emptyMap()
)

data class WireSimulationReading(
    val wireId: String,
    val voltageV: Double = 0.0,
    val currentMa: Double = 0.0,
    val directionForward: Boolean = true
)

data class OscilloscopeSample(
    val timeSec: Double,
    val voltageV: Double
)

data class SimulationResult(
    val simTimeSec: Double = 0.0,
    val converged: Boolean = true,
    val iterationsUsed: Int = 0,
    val groundReferenceNetId: String? = null,
    val nodeVoltagesV: Map<String, Double> = emptyMap(), // netId / canonicalKey -> Volts
    val canonicalKeyToNetId: Map<String, String> = emptyMap(),
    val componentReadings: Map<String, ComponentSimulationReading> = emptyMap(),
    val wireReadings: Map<String, WireSimulationReading> = emptyMap(),
    val warnings: List<SimulationWarning> = emptyList(),
    val solverErrorMessage: String? = null
)

data class ElectricalNodeGroup(
    val netId: String,
    val memberKeys: Set<String>
)

data class NetlistSummary(
    val componentCount: Int,
    val wireCount: Int,
    val activeNodeCount: Int,
    val floatingComponentCount: Int,
    val railShortDetected: Boolean,
    val nets: List<ElectricalNodeGroup>
)

interface SimulationEngineBridge {
    fun stageNetlist(snapshot: LabCircuitSnapshot): NetlistSummary
}

object NetlistExtractor : SimulationEngineBridge {

    fun breadboardBusKey(col: Int, row: Int): String? {
        if (col !in 0..29) return null
        return when (row) {
            -2 -> "RAIL_TOP_POS"
            -1 -> "RAIL_TOP_NEG"
            in 0..4 -> "COL_${col}_TOP"
            in 6..10 -> "COL_${col}_BOT"
            12 -> "RAIL_BOT_POS"
            13 -> "RAIL_BOT_NEG"
            else -> null
        }
    }

    fun resolvePinWorldGrid(comp: PlacedComponent, pin: LabPinSpec): Pair<Float, Float> {
        val (rx, ry) = when (((comp.rotationDeg % 360) + 360) % 360) {
            90 -> -pin.localRowOffset to pin.localColOffset
            180 -> -pin.localColOffset to -pin.localRowOffset
            270 -> pin.localRowOffset to -pin.localColOffset
            else -> pin.localColOffset to pin.localRowOffset
        }
        return (comp.gridCol + rx) to (comp.gridRow + ry)
    }

    override fun stageNetlist(snapshot: LabCircuitSnapshot): NetlistSummary {
        val parent = mutableMapOf<String, String>()

        fun find(x: String): String {
            val p = parent.getOrPut(x) { x }
            if (p != x) {
                parent[x] = find(p)
            }
            return parent[x]!!
        }

        fun union(a: String, b: String) {
            val ra = find(a)
            val rb = find(b)
            if (ra != rb) parent[ra] = rb
        }

        val connectedComponents = mutableSetOf<String>()
        for (comp in snapshot.components) {
            val def = LabComponentCatalog.find(comp.typeId) ?: continue
            for (pin in def.pins) {
                val pinKey = "PIN:${comp.instanceId}:${pin.id}"
                find(pinKey)
                if (def.snapToBreadboard) {
                    val (wx, wy) = resolvePinWorldGrid(comp, pin)
                    val col = wx.roundToInt()
                    val row = wy.roundToInt()
                    val busKey = breadboardBusKey(col, row)
                    if (busKey != null) {
                        union(pinKey, busKey)
                        val holeKey = "HOLE:$col:$row"
                        union(holeKey, busKey)
                        connectedComponents += comp.instanceId
                    }
                }
            }
        }

        for (wire in snapshot.wires) {
            val startKey = wire.start.canonicalKey()
            val endKey = wire.end.canonicalKey()
            find(startKey)
            find(endKey)
            union(startKey, endKey)

            if (wire.start.isBreadboardHole) {
                breadboardBusKey(wire.start.holeCol, wire.start.holeRow)?.let { union(startKey, it) }
            } else if (wire.start.componentId != null) {
                connectedComponents += wire.start.componentId
            }

            if (wire.end.isBreadboardHole) {
                breadboardBusKey(wire.end.holeCol, wire.end.holeRow)?.let { union(endKey, it) }
            } else if (wire.end.componentId != null) {
                connectedComponents += wire.end.componentId
            }
        }

        val groups = parent.keys.groupBy { find(it) }
            .entries
            .mapIndexed { idx, (_, members) ->
                ElectricalNodeGroup(netId = "NET_${idx + 1}", memberKeys = members.toSet())
            }

        val topShort = find("RAIL_TOP_POS") == find("RAIL_TOP_NEG")
        val botShort = find("RAIL_BOT_POS") == find("RAIL_BOT_NEG")
        val floatingCount = snapshot.components.count { it.instanceId !in connectedComponents }

        return NetlistSummary(
            componentCount = snapshot.components.size,
            wireCount = snapshot.wires.size,
            activeNodeCount = groups.size,
            floatingComponentCount = floatingCount,
            railShortDetected = topShort || botShort,
            nets = groups
        )
    }

    val componentSupportCatalog: List<ComponentModelSupportInfo> = listOf(
        ComponentModelSupportInfo("battery_9v", "9V Battery", ComponentSupportLevel.FULLY_SIMULATED, "Ideal DC EMF + 0.05Ω internal resistance, polarity & short-circuit foldback"),
        ComponentModelSupportInfo("battery_aa", "AA 1.5V Cell", ComponentSupportLevel.FULLY_SIMULATED, "DC voltage source with 0.05Ω internal resistance & polarity support"),
        ComponentModelSupportInfo("dc_psu", "Bench DC Power Supply", ComponentSupportLevel.FULLY_SIMULATED, "Configurable DC voltage + output ON/OFF & current limit foldback"),
        ComponentModelSupportInfo("ground_terminal", "Ground Terminal (0V)", ComponentSupportLevel.FULLY_SIMULATED, "Defines 0.00V MNA reference potential across tied nodes"),
        ComponentModelSupportInfo("resistor", "Resistor (4-Band)", ComponentSupportLevel.FULLY_SIMULATED, "Exact Ohm's Law conductance G = 1/R + 0.25W power rating check"),
        ComponentModelSupportInfo("potentiometer", "Potentiometer", ComponentSupportLevel.FULLY_SIMULATED, "Dual-section voltage divider across Terminal 1, Wiper (%), and Terminal 2"),
        ComponentModelSupportInfo("cap_ceramic", "Ceramic Capacitor", ComponentSupportLevel.FULLY_SIMULATED, "Backward-Euler transient companion model (I = C·dV/dt) + voltage rating check"),
        ComponentModelSupportInfo("cap_electrolytic", "Electrolytic Capacitor", ComponentSupportLevel.FULLY_SIMULATED, "Transient Backward-Euler model + reverse polarity & rated-voltage checks"),
        ComponentModelSupportInfo("inductor", "Inductor Coil", ComponentSupportLevel.FULLY_SIMULATED, "Backward-Euler transient companion model (V = L·dI/dt) with 0.5Ω DCR"),
        ComponentModelSupportInfo("diode_1n4007", "PN Diode (1N4007)", ComponentSupportLevel.FULLY_SIMULATED, "Nonlinear Shockley exponential diode solved via Newton-Raphson"),
        ComponentModelSupportInfo("diode_zener", "Zener Diode (5.1V)", ComponentSupportLevel.FULLY_SIMULATED, "Forward Shockley diode + reverse Zener breakdown regulation at Vz"),
        ComponentModelSupportInfo("led_5mm", "5mm LED", ComponentSupportLevel.FULLY_SIMULATED, "Calibrated forward Vf exponential curve, current-based brightness, reverse/over-current warnings"),
        ComponentModelSupportInfo("bjt_npn", "NPN BJT (2N2222)", ComponentSupportLevel.FULLY_SIMULATED, "Simplified Ebers-Moll base-emitter diode & beta-controlled collector with saturation clamp"),
        ComponentModelSupportInfo("bjt_pnp", "PNP BJT (2N3906)", ComponentSupportLevel.FULLY_SIMULATED, "Complementary simplified Ebers-Moll PNP active/saturation/cutoff solver"),
        ComponentModelSupportInfo("n_mosfet", "N-MOSFET (IRFZ44N)", ComponentSupportLevel.FULLY_SIMULATED, "Gate-threshold controlled Rds(on) conduction & body diode"),
        ComponentModelSupportInfo("slide_switch", "Slide Switch (SPDT)", ComponentSupportLevel.FULLY_SIMULATED, "Switches COM between Terminal 1 (ON) and Terminal 2 (OFF)"),
        ComponentModelSupportInfo("pushbutton", "Tactile Push Button", ComponentSupportLevel.FULLY_SIMULATED, "Bridged 1A–1B & 2A–2B rails with momentary ON/OFF contact"),
        ComponentModelSupportInfo("relay_5v", "5V SPDT Relay", ComponentSupportLevel.FULLY_SIMULATED, "70Ω coil energizing threshold (~70% rated V) switching COM between NC and NO"),
        ComponentModelSupportInfo("dc_motor", "DC Motor", ComponentSupportLevel.FULLY_SIMULATED, "Steady-state armature resistance (~8Ω) + proportional RPM estimation"),
        ComponentModelSupportInfo("jumper_bridge", "Preformed Jumper Bridge", ComponentSupportLevel.FULLY_SIMULATED, "Low-resistance (0.02Ω) physical wire link"),
        ComponentModelSupportInfo("ldr_sensor", "Photoresistor (LDR)", ComponentSupportLevel.PARTIALLY_SIMULATED, "Conductance mapped from configured luxLevel property; no optical raytracing"),
        ComponentModelSupportInfo("screw_terminal", "2-Pin Screw Terminal", ComponentSupportLevel.VISUAL_ONLY, "Passive two-pin mechanical connector; pins expose node voltages without active load"),
        ComponentModelSupportInfo("seven_seg", "7-Segment Display", ComponentSupportLevel.VISUAL_ONLY, "Physical pin placement & node tracing only; multiplexed segment LEDs not driven"),
        ComponentModelSupportInfo("ic_555", "555 Timer IC", ComponentSupportLevel.NOT_SUPPORTED, "Complex internal comparator/flip-flop analog macro-model deferred beyond Phase 4"),
        ComponentModelSupportInfo("ic_lm358", "LM358 Op-Amp", ComponentSupportLevel.NOT_SUPPORTED, "Dual op-amp analog macro-model not active in Phase 4 solver"),
        ComponentModelSupportInfo("hcsr04", "HC-SR04 Ultrasonic", ComponentSupportLevel.NOT_SUPPORTED, "Requires firmware trigger/echo pulse timing and acoustic time-of-flight"),
        ComponentModelSupportInfo("arduino_uno", "Arduino UNO R3", ComponentSupportLevel.NOT_SUPPORTED, "Programmable AVR firmware execution out of Phase 4 scope"),
        ComponentModelSupportInfo("esp32_devkit", "ESP32 DevKit V1", ComponentSupportLevel.NOT_SUPPORTED, "Programmable Xtensa microcontroller/Wi-Fi runtime out of Phase 4 scope"),
        ComponentModelSupportInfo("lcd_16x2", "16×2 LCD Module", ComponentSupportLevel.NOT_SUPPORTED, "Requires I2C HD44780 digital bus protocol")
    )
}
