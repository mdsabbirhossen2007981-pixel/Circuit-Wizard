package com.example.simulation

import com.example.domain.lab.LabComponentCatalog
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabInstrumentState
import com.example.domain.model.LabInstrumentType
import com.example.domain.model.PlacedComponent
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.tanh

data class ProbeTargetOption(
    val key: String,
    val label: String
)

class CircuitTransientState {
    var simTimeSec: Double = 0.0
    val capacitorVoltages: MutableMap<String, Double> = mutableMapOf()
    val inductorCurrents: MutableMap<String, Double> = mutableMapOf()
    val relayEnergized: MutableMap<String, Boolean> = mutableMapOf()
    var lastNodeGuess: Map<String, Double> = emptyMap()

    fun reset() {
        simTimeSec = 0.0
        capacitorVoltages.clear()
        inductorCurrents.clear()
        relayEnergized.clear()
        lastNodeGuess = emptyMap()
    }
}

object CircuitMnaSolver {

    private const val THERMAL_V = 0.02585
    private const val G_MIN = 1e-10
    private const val G_OPEN = 1e-11
    private const val R_SWITCH_ON = 0.02
    private const val MAX_NR_ITER = 35
    private const val CONVERGENCE_TOL_V = 1e-4

    private data class UnionNetData(
        val netCount: Int,
        val groundNetIdx: Int,
        val canonicalKeyToNetIdx: Map<String, Int>,
        val netIdxToId: Map<Int, String>
    )

    private data class LinearVoltageStamp(
        val instanceId: String,
        val posIdx: Int,
        val negIdx: Int,
        val voltageV: Double,
        val rInternal: Double,
        val currentLimitA: Double
    )

    private data class SolverSolution(
        val nodeVoltages: DoubleArray,
        val converged: Boolean,
        val iterations: Int,
        val errorMessage: String? = null
    )

    fun buildProbeOptions(snapshot: LabCircuitSnapshot): List<ProbeTargetOption> {
        val options = mutableListOf<ProbeTargetOption>()
        options += ProbeTargetOption("HOLE:0:-2", "Top + Power Rail")
        options += ProbeTargetOption("HOLE:0:-1", "Top − Power Rail")
        options += ProbeTargetOption("HOLE:0:12", "Bottom + Power Rail")
        options += ProbeTargetOption("HOLE:0:13", "Bottom − Power Rail")
        for (comp in snapshot.components) {
            val def = LabComponentCatalog.find(comp.typeId) ?: continue
            val shortName = def.nameEn.substringBefore(" (")
            for (pin in def.pins) {
                options += ProbeTargetOption(
                    key = "PIN:${comp.instanceId}:${pin.id}",
                    label = "$shortName • ${pin.label}"
                )
            }
        }
        return options
    }

    fun stepTransient(
        snapshot: LabCircuitSnapshot,
        transientState: CircuitTransientState,
        dtSec: Double
    ): SimulationResult {
        val safeDt = dtSec.coerceIn(1e-4, 0.25)
        if (snapshot.components.isEmpty()) {
            transientState.simTimeSec += safeDt
            return SimulationResult(simTimeSec = transientState.simTimeSec)
        }

        val netData = buildUnionNets(snapshot)
        val warnings = mutableListOf<SimulationWarning>()

        // Emit explicit notices for non-simulated / partially simulated parts in circuit
        val supportById = NetlistExtractor.componentSupportCatalog.associateBy { it.typeId }
        for (comp in snapshot.components) {
            val info = supportById[comp.typeId]
            if (info != null && (info.supportLevel == ComponentSupportLevel.NOT_SUPPORTED ||
                    info.supportLevel == ComponentSupportLevel.VISUAL_ONLY)
            ) {
                warnings += SimulationWarning(
                    category = WarningCategory.UNSUPPORTED_PART,
                    severity = SafetySeverity.INFO,
                    componentId = comp.instanceId,
                    messageEn = "${info.nameEn}: ${info.supportLevel.labelEn} (${info.notesEn})"
                )
            }
        }

        // First solve pass (with current-limit foldback guard & relay switching pass)
        val effectiveSources = mutableListOf<LinearVoltageStamp>()
        val sourceOverrides = mutableMapOf<String, Double>() // instanceId -> effective series R override on short foldback

        var solution = solveNonlinearStep(
            snapshot = snapshot,
            netData = netData,
            transientState = transientState,
            dtSec = safeDt,
            sourceSeriesROverrides = sourceOverrides,
            collectedSources = effectiveSources
        )

        // Check if any voltage source exceeded current limit or had dead short across pos/neg
        var needsFoldbackResolve = false
        for (src in effectiveSources) {
            val vDiff = solution.nodeVoltages[src.posIdx] - solution.nodeVoltages[src.negIdx]
            val srcCurrent = (src.voltageV - vDiff) / src.rInternal
            val directShort = src.posIdx == src.negIdx && abs(src.voltageV) > 0.05
            if (directShort || abs(srcCurrent) > src.currentLimitA) {
                warnings += SimulationWarning(
                    category = WarningCategory.SHORT_CIRCUIT,
                    severity = SafetySeverity.CRITICAL,
                    componentId = src.instanceId,
                    messageEn = if (directShort) {
                        "Direct short circuit detected across power source terminals! Current limited to ${"%.2f".format(src.currentLimitA)} A."
                    } else {
                        "Short circuit / over-current on source (${"%.2f".format(abs(srcCurrent))} A > ${"%.2f".format(src.currentLimitA)} A limit) — foldback active."
                    }
                )
                if (!directShort) {
                    sourceOverrides[src.instanceId] = (abs(src.voltageV) / src.currentLimitA.coerceAtLeast(0.05))
                    needsFoldbackResolve = true
                }
            }
            if (abs(src.voltageV) > 24.0) {
                warnings += SimulationWarning(
                    category = WarningCategory.HIGH_VOLTAGE_SAFETY,
                    severity = SafetySeverity.WARNING,
                    componentId = src.instanceId,
                    messageEn = "Voltage (${"%.1f".format(src.voltageV)}V) exceeds safe low-voltage threshold (24V). Never experiment with mains AC electricity."
                )
            }
        }

        if (needsFoldbackResolve) {
            effectiveSources.clear()
            solution = solveNonlinearStep(
                snapshot = snapshot,
                netData = netData,
                transientState = transientState,
                dtSec = safeDt,
                sourceSeriesROverrides = sourceOverrides,
                collectedSources = effectiveSources
            )
        }

        // Check relay pickup state transitions & do 1 re-solve if a relay switched
        var relayChanged = false
        for (comp in snapshot.components) {
            if (comp.typeId == "relay_5v") {
                val c1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil1"] ?: continue
                val c2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil2"] ?: continue
                val vCoil = abs(solution.nodeVoltages[c1] - solution.nodeVoltages[c2])
                val pickup = (comp.properties["coilV"]?.toDoubleOrNull() ?: 5.0) * 0.7
                val nowOn = vCoil >= pickup
                if (transientState.relayEnergized[comp.instanceId] != nowOn) {
                    transientState.relayEnergized[comp.instanceId] = nowOn
                    relayChanged = true
                }
            }
        }
        if (relayChanged) {
            effectiveSources.clear()
            solution = solveNonlinearStep(
                snapshot = snapshot,
                netData = netData,
                transientState = transientState,
                dtSec = safeDt,
                sourceSeriesROverrides = sourceOverrides,
                collectedSources = effectiveSources
            )
        }

        if (!solution.converged || solution.errorMessage != null) {
            warnings += SimulationWarning(
                category = WarningCategory.SOLVER_ERROR,
                severity = SafetySeverity.CRITICAL,
                componentId = null,
                messageEn = solution.errorMessage ?: "Nonlinear solver did not converge cleanly within $MAX_NR_ITER iterations."
            )
        }

        // Capture pre-step capacitor voltages for dV/dt readout, then advance transient history
        val preStepCapVoltages = transientState.capacitorVoltages.toMap()
        transientState.simTimeSec += safeDt
        val v = solution.nodeVoltages
        for (comp in snapshot.components) {
            when (comp.typeId) {
                "cap_ceramic", "cap_electrolytic" -> {
                    val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                    transientState.capacitorVoltages[comp.instanceId] = v[p1] - v[p2]
                }
                "inductor" -> {
                    val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                    val lHenry = parseInductanceHenries(comp.properties["inductance"], comp.properties["unit"])
                    val rDc = 0.5
                    val gEq = 1.0 / (lHenry / safeDt + rDc)
                    val iPrev = transientState.inductorCurrents[comp.instanceId] ?: 0.0
                    val iNext = gEq * (v[p1] - v[p2]) + gEq * (lHenry / safeDt) * iPrev
                    transientState.inductorCurrents[comp.instanceId] = iNext
                }
            }
        }

        // Save node guesses warm-start
        val guessMap = mutableMapOf<String, Double>()
        for (idx in 0 until netData.netCount) {
            val id = netData.netIdxToId[idx] ?: continue
            guessMap[id] = v[idx]
        }
        transientState.lastNodeGuess = guessMap

        // Build connectivity reachability from Ground + Energized Sources
        val closedLoopComps = computeClosedLoopComponents(snapshot, netData, transientState)

        // Compute per-component readings & safety checks
        val compReadings = mutableMapOf<String, ComponentSimulationReading>()
        val netlistSummary = NetlistExtractor.stageNetlist(snapshot)
        if (netlistSummary.railShortDetected) {
            if (warnings.none { it.category == WarningCategory.SHORT_CIRCUIT }) {
                warnings += SimulationWarning(
                    category = WarningCategory.SHORT_CIRCUIT,
                    severity = SafetySeverity.CRITICAL,
                    componentId = null,
                    messageEn = "Breadboard '+' and '−' power rails are shorted together!"
                )
            }
        }

        for (comp in snapshot.components) {
            val def = LabComponentCatalog.find(comp.typeId) ?: continue
            val pinVoltages = def.pins.associate { pin ->
                val idx = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:${pin.id}"]
                pin.id to (if (idx != null) v[idx] else 0.0)
            }
            val inClosedLoop = comp.instanceId in closedLoopComps
            val reading = evaluateComponentReading(
                comp = comp,
                netData = netData,
                nodeVoltages = v,
                transientState = transientState,
                preStepCapVoltages = preStepCapVoltages,
                dtSec = safeDt,
                sourceSeriesROverrides = sourceOverrides,
                pinVoltages = pinVoltages,
                isFloating = !inClosedLoop,
                warnings = warnings
            )
            compReadings[comp.instanceId] = reading

            if (!inClosedLoop &&
                comp.typeId !in setOf("ground_terminal", "arduino_uno", "esp32_devkit", "ic_555", "ic_lm358", "lcd_16x2", "hcsr04")
            ) {
                warnings += SimulationWarning(
                    category = WarningCategory.FLOATING_NODE,
                    severity = SafetySeverity.INFO,
                    componentId = comp.instanceId,
                    messageEn = "${def.nameEn}: Open-circuit or disconnected from closed power return loop."
                )
            }
        }

        // Build canonicalKey -> voltage lookup
        val allKeyVoltages = mutableMapOf<String, Double>()
        val keyToNetId = mutableMapOf<String, String>()
        for ((key, idx) in netData.canonicalKeyToNetIdx) {
            allKeyVoltages[key] = v[idx]
            val netId = netData.netIdxToId[idx] ?: "NET_$idx"
            keyToNetId[key] = netId
            allKeyVoltages[netId] = v[idx]
        }

        // Wire telemetry (voltage on net + inferred branch current if endpoint matches a pin or closed loop)
        val wireReadings = mutableMapOf<String, WireSimulationReading>()
        val sourceCurrentAvailable = effectiveSources.any { abs((it.voltageV - (v[it.posIdx] - v[it.negIdx])) / it.rInternal) > 1e-4 }
        for (wire in snapshot.wires) {
            val sKey = wire.start.canonicalKey()
            val eKey = wire.end.canonicalKey()
            val vWire = allKeyVoltages[sKey] ?: 0.0
            val startComp = wire.start.componentId?.let { compReadings[it] }
            val endComp = wire.end.componentId?.let { compReadings[it] }
            var estMa = when {
                startComp != null && abs(startComp.currentMa) > 0.05 -> abs(startComp.currentMa)
                endComp != null && abs(endComp.currentMa) > 0.05 -> abs(endComp.currentMa)
                else -> 0.0
            }
            if (estMa == 0.0 && sourceCurrentAvailable) {
                // Check if this hole net contains any active conducting component
                val netId = keyToNetId[sKey]
                val neighborComp = snapshot.components.firstOrNull { c ->
                    val def = LabComponentCatalog.find(c.typeId) ?: return@firstOrNull false
                    val reading = compReadings[c.instanceId] ?: return@firstOrNull false
                    abs(reading.currentMa) > 0.05 && def.pins.any { p ->
                        keyToNetId["PIN:${c.instanceId}:${p.id}"] == netId
                    }
                }
                if (neighborComp != null) {
                    estMa = abs(compReadings[neighborComp.instanceId]?.currentMa ?: 0.0)
                }
            }
            val forward = (wire.start.pinId != "neg") && (vWire >= 0.0)
            wireReadings[wire.id] = WireSimulationReading(
                wireId = wire.id,
                voltageV = vWire,
                currentMa = estMa,
                directionForward = forward
            )
        }

        return SimulationResult(
            simTimeSec = transientState.simTimeSec,
            converged = solution.converged,
            iterationsUsed = solution.iterations,
            groundReferenceNetId = netData.netIdxToId[netData.groundNetIdx],
            nodeVoltagesV = allKeyVoltages,
            canonicalKeyToNetId = keyToNetId,
            componentReadings = compReadings,
            wireReadings = wireReadings,
            warnings = warnings.distinctBy { "${it.category}:${it.componentId}:${it.messageEn}" },
            solverErrorMessage = solution.errorMessage
        )
    }

    /**
     * Evaluates a measurement instrument strictly from actual SimulationResult & netlist topology.
     */
    fun evaluateInstrument(
        instrument: LabInstrumentState,
        result: SimulationResult,
        snapshot: LabCircuitSnapshot
    ): String {
        val posKey = instrument.positiveProbeKey
        val negKey = instrument.negativeProbeKey

        fun lookupVoltage(key: String?): Double? {
            if (key == null) return null
            result.nodeVoltagesV[key]?.let { return it }
            return null
        }

        return when (runCatching { LabInstrumentType.valueOf(instrument.type) }.getOrNull()) {
            LabInstrumentType.VOLTMETER -> {
                val vPos = lookupVoltage(posKey)
                if (vPos == null) "Connect (+) probe to measure"
                else {
                    val vNeg = lookupVoltage(negKey) ?: 0.0
                    "${"%.3f".format(vPos - vNeg)} V DC"
                }
            }
            LabInstrumentType.AMMETER -> {
                val compId = posKey?.takeIf { it.startsWith("PIN:") }?.split(":")?.getOrNull(1)
                val reading = compId?.let { result.componentReadings[it] }
                if (reading == null) "Probe component pin for branch mA"
                else "${"%.2f".format(reading.currentMa)} mA"
            }
            LabInstrumentType.DIGITAL_MULTIMETER -> {
                when (instrument.mode) {
                    "VDC" -> {
                        val vPos = lookupVoltage(posKey)
                        if (vPos == null) "Connect (+) probe"
                        else {
                            val vNeg = lookupVoltage(negKey) ?: 0.0
                            "${"%.3f".format(vPos - vNeg)} V"
                        }
                    }
                    "mA" -> {
                        val compId = posKey?.takeIf { it.startsWith("PIN:") }?.split(":")?.getOrNull(1)
                        val reading = compId?.let { result.componentReadings[it] }
                        if (reading == null) "Probe component pin"
                        else "${"%.2f".format(reading.currentMa)} mA"
                    }
                    "Ω" -> {
                        val compId = posKey?.takeIf { it.startsWith("PIN:") }?.split(":")?.getOrNull(1)
                        val r = compId?.let { result.componentReadings[it]?.effectiveResistanceOhms }
                        if (r == null) "OL / Select passive part"
                        else if (r >= 1_000_000.0) "${"%.2f".format(r / 1_000_000.0)} MΩ"
                        else if (r >= 1_000.0) "${"%.2f".format(r / 1_000.0)} kΩ"
                        else "${"%.1f".format(r)} Ω"
                    }
                    "Cont" -> {
                        if (posKey == null || negKey == null) "Attach (+) & (−) probes"
                        else {
                            val netA = result.canonicalKeyToNetId[posKey]
                            val netB = result.canonicalKeyToNetId[negKey]
                            if (netA != null && netA == netB) "BEEP • Short / Continuous (0 Ω)"
                            else "OL • Open Circuit"
                        }
                    }
                    else -> "Mode unavailable"
                }
            }
            LabInstrumentType.OSCILLOSCOPE -> {
                val vPos = lookupVoltage(posKey)
                if (vPos == null) "Attach CH1 (+) probe"
                else {
                    val vNeg = lookupVoltage(negKey) ?: 0.0
                    "CH1: ${"%.3f".format(vPos - vNeg)} V @ t=${"%.2f".format(result.simTimeSec)}s"
                }
            }
            LabInstrumentType.DC_POWER_SUPPLY -> {
                if (instrument.isEnabled) "${"%.1f".format(instrument.voltageSetting)} V / ${"%.1f".format(instrument.currentLimit)} A"
                else "OFF (0.0 V)"
            }
            null -> "Unknown Instrument"
        }
    }

    private fun buildUnionNets(snapshot: LabCircuitSnapshot): UnionNetData {
        val parent = mutableMapOf<String, String>()
        fun find(x: String): String {
            val p = parent.getOrPut(x) { x }
            if (p != x) parent[x] = find(p)
            return parent[x]!!
        }
        fun union(a: String, b: String) {
            val ra = find(a)
            val rb = find(b)
            if (ra != rb) parent[ra] = rb
        }

        // Pre-seed all standard rails so rail probe keys always map cleanly
        for (c in 0..29) {
            for (r in listOf(-2, -1, 12, 13)) {
                NetlistExtractor.breadboardBusKey(c, r)?.let { bus ->
                    union("HOLE:$c:$r", bus)
                }
            }
        }

        for (comp in snapshot.components) {
            val def = LabComponentCatalog.find(comp.typeId) ?: continue
            for (pin in def.pins) {
                val pinKey = "PIN:${comp.instanceId}:${pin.id}"
                find(pinKey)
                if (def.snapToBreadboard) {
                    val (wx, wy) = NetlistExtractor.resolvePinWorldGrid(comp, pin)
                    val col = wx.roundToInt()
                    val row = wy.roundToInt()
                    val busKey = NetlistExtractor.breadboardBusKey(col, row)
                    if (busKey != null) {
                        union(pinKey, busKey)
                        union("HOLE:$col:$row", busKey)
                    }
                }
            }
        }

        for (wire in snapshot.wires) {
            val sKey = wire.start.canonicalKey()
            val eKey = wire.end.canonicalKey()
            find(sKey)
            find(eKey)
            union(sKey, eKey)
            if (wire.start.isBreadboardHole) {
                NetlistExtractor.breadboardBusKey(wire.start.holeCol, wire.start.holeRow)?.let { union(sKey, it) }
            }
            if (wire.end.isBreadboardHole) {
                NetlistExtractor.breadboardBusKey(wire.end.holeCol, wire.end.holeRow)?.let { union(eKey, it) }
            }
        }

        // Unify explicit ground terminals together
        val gndRoots = snapshot.components
            .filter { it.typeId == "ground_terminal" }
            .map { find("PIN:${it.instanceId}:gnd") }
        if (gndRoots.size > 1) {
            for (i in 1 until gndRoots.size) {
                union(gndRoots[0], gndRoots[i])
            }
        }

        val allKeys = parent.keys.toList()
        val roots = allKeys.map { find(it) }.distinct()

        // Determine Ground root: explicit Ground Terminal -> first active DC source negative pin -> Top '-' rail -> root[0]
        val groundRoot: String = gndRoots.firstOrNull()?.let { find(it) }
            ?: snapshot.components.firstOrNull { it.typeId in setOf("battery_9v", "battery_aa", "dc_psu") }?.let { src ->
                val isRev = src.properties["polarity"] == "Reversed"
                val refPin = if (isRev) "pos" else "neg"
                find("PIN:${src.instanceId}:$refPin")
            }
            ?: find("RAIL_TOP_NEG")

        val orderedRoots = listOf(groundRoot) + roots.filter { it != groundRoot }
        val rootToIdx = orderedRoots.withIndex().associate { (i, r) -> r to i }

        val keyToIdx = mutableMapOf<String, Int>()
        for (k in allKeys) {
            keyToIdx[k] = rootToIdx[find(k)] ?: 0
        }
        val idxToId = orderedRoots.indices.associateWith { i -> if (i == 0) "GND" else "NET_$i" }

        return UnionNetData(
            netCount = orderedRoots.size.coerceAtLeast(1),
            groundNetIdx = 0,
            canonicalKeyToNetIdx = keyToIdx,
            netIdxToId = idxToId
        )
    }

    private fun solveNonlinearStep(
        snapshot: LabCircuitSnapshot,
        netData: UnionNetData,
        transientState: CircuitTransientState,
        dtSec: Double,
        sourceSeriesROverrides: Map<String, Double>,
        collectedSources: MutableList<LinearVoltageStamp>
    ): SolverSolution {
        val nNodes = netData.netCount // node 0 is ground (fixed 0.0 V)
        val nonGroundCount = (nNodes - 1).coerceAtLeast(0)
        if (nonGroundCount == 0) {
            return SolverSolution(DoubleArray(nNodes), converged = true, iterations = 1)
        }

        val vCurrent = DoubleArray(nNodes)
        for (i in 1 until nNodes) {
            val netId = netData.netIdxToId[i] ?: continue
            vCurrent[i] = transientState.lastNodeGuess[netId] ?: 0.0
        }

        var converged = false
        var iters = 0

        for (iter in 1..MAX_NR_ITER) {
            iters = iter
            val gMat = Array(nonGroundCount) { DoubleArray(nonGroundCount) }
            val rhs = DoubleArray(nonGroundCount)
            if (iter == 1) collectedSources.clear()

            fun stampConductance(n1: Int, n2: Int, g: Double) {
                if (!g.isFinite() || g <= 0.0) return
                if (n1 > 0) gMat[n1 - 1][n1 - 1] += g
                if (n2 > 0) gMat[n2 - 1][n2 - 1] += g
                if (n1 > 0 && n2 > 0) {
                    gMat[n1 - 1][n2 - 1] -= g
                    gMat[n2 - 1][n1 - 1] -= g
                }
            }

            fun stampCurrentInjection(nFrom: Int, nTo: Int, iAmps: Double) {
                if (!iAmps.isFinite()) return
                if (nFrom > 0) rhs[nFrom - 1] -= iAmps
                if (nTo > 0) rhs[nTo - 1] += iAmps
            }

            // Weak global G_min to Ground prevents floating subcircuit singular matrices
            for (i in 1 until nNodes) {
                gMat[i - 1][i - 1] += G_MIN
            }

            for (comp in snapshot.components) {
                when (comp.typeId) {
                    "battery_9v", "battery_aa", "dc_psu" -> {
                        val pos = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:pos"] ?: continue
                        val neg = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:neg"] ?: continue
                        val rawV = comp.properties["voltage"]?.toDoubleOrNull()
                            ?: if (comp.typeId == "battery_aa") 1.5 else if (comp.typeId == "dc_psu") 5.0 else 9.0
                        val polRev = comp.properties["polarity"] == "Reversed"
                        val enabled = comp.typeId != "dc_psu" || comp.properties["state"] != "OFF"
                        val emf = if (!enabled) 0.0 else if (polRev) -rawV else rawV
                        val iLim = comp.properties["currentLimit"]?.toDoubleOrNull()
                            ?: if (comp.typeId == "dc_psu") 1.5 else 2.5
                        val rInt = sourceSeriesROverrides[comp.instanceId] ?: 0.05
                        if (iter == 1) {
                            collectedSources += LinearVoltageStamp(comp.instanceId, pos, neg, emf, rInt, iLim)
                        }
                        if (enabled) {
                            val gSrc = 1.0 / rInt
                            // Norton equivalent: current source emf / rInt from neg -> pos in parallel with rInt
                            stampConductance(pos, neg, gSrc)
                            stampCurrentInjection(neg, pos, emf * gSrc)
                        } else {
                            stampConductance(pos, neg, G_OPEN)
                        }
                    }

                    "resistor" -> {
                        val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                        val r = parseResistanceOhms(comp.properties["value"], comp.properties["unit"])
                        stampConductance(p1, p2, 1.0 / r)
                    }

                    "jumper_bridge" -> {
                        val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                        stampConductance(p1, p2, 1.0 / 0.02)
                    }

                    "ldr_sensor" -> {
                        val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                        val r = parseLdrOhms(comp.properties["luxLevel"], comp.properties["darkOhms"])
                        stampConductance(p1, p2, 1.0 / r)
                    }

                    "potentiometer" -> {
                        val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: continue
                        val w = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:wiper"] ?: continue
                        val t2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t2"] ?: continue
                        val rTotal = parseResistanceOhms(comp.properties["value"], comp.properties["unit"])
                        val alpha = ((comp.properties["wiperPct"]?.toDoubleOrNull() ?: 50.0) / 100.0).coerceIn(0.01, 0.99)
                        stampConductance(t1, w, 1.0 / (rTotal * alpha))
                        stampConductance(w, t2, 1.0 / (rTotal * (1.0 - alpha)))
                    }

                    "cap_ceramic", "cap_electrolytic" -> {
                        val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                        val capF = parseCapacitanceFarads(comp.properties["capacitance"], comp.properties["unit"])
                        val gEq = capF / dtSec
                        val vPrev = transientState.capacitorVoltages[comp.instanceId] ?: 0.0
                        stampConductance(p1, p2, gEq + G_MIN)
                        // Backward Euler history source: pushes current from p2 to p1 proportional to vPrev
                        stampCurrentInjection(p2, p1, gEq * vPrev)
                    }

                    "inductor" -> {
                        val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                        val lHenry = parseInductanceHenries(comp.properties["inductance"], comp.properties["unit"])
                        val rDc = 0.5
                        val gEq = 1.0 / (lHenry / dtSec + rDc)
                        val iPrev = transientState.inductorCurrents[comp.instanceId] ?: 0.0
                        val iHist = gEq * (lHenry / dtSec) * iPrev
                        stampConductance(p1, p2, gEq)
                        stampCurrentInjection(p1, p2, iHist)
                    }

                    "slide_switch" -> {
                        val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: continue
                        val com = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:com"] ?: continue
                        val t2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t2"] ?: continue
                        val isOn = comp.properties["state"] == "ON"
                        if (isOn) {
                            stampConductance(t1, com, 1.0 / R_SWITCH_ON)
                            stampConductance(com, t2, G_OPEN)
                        } else {
                            stampConductance(t1, com, G_OPEN)
                            stampConductance(com, t2, 1.0 / R_SWITCH_ON)
                        }
                    }

                    "pushbutton" -> {
                        val a1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:a1"] ?: continue
                        val a2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:a2"] ?: continue
                        val b1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b1"] ?: continue
                        val b2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b2"] ?: continue
                        stampConductance(a1, a2, 1.0 / R_SWITCH_ON)
                        stampConductance(b1, b2, 1.0 / R_SWITCH_ON)
                        val isOn = comp.properties["state"] == "ON"
                        stampConductance(a1, b1, if (isOn) 1.0 / R_SWITCH_ON else G_OPEN)
                    }

                    "relay_5v" -> {
                        val c1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil1"] ?: continue
                        val c2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil2"] ?: continue
                        val com = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:com"] ?: continue
                        val no = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:no"] ?: continue
                        val nc = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:nc"] ?: continue
                        val rCoil = (comp.properties["coilOhms"]?.toDoubleOrNull() ?: 70.0).coerceAtLeast(5.0)
                        stampConductance(c1, c2, 1.0 / rCoil)
                        val energized = transientState.relayEnergized[comp.instanceId] == true
                        if (energized) {
                            stampConductance(com, no, 1.0 / 0.05)
                            stampConductance(com, nc, G_OPEN)
                        } else {
                            stampConductance(com, nc, 1.0 / 0.05)
                            stampConductance(com, no, G_OPEN)
                        }
                    }

                    "dc_motor" -> {
                        val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: continue
                        val t2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t2"] ?: continue
                        stampConductance(t1, t2, 1.0 / 8.0) // 8 Ohm armature equivalent
                    }

                    "diode_1n4007", "diode_zener", "led_5mm" -> {
                        val a = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:anode"] ?: continue
                        val k = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:cathode"] ?: continue
                        val vd = vCurrent[a] - vCurrent[k]
                        val (iD, gD) = evalDiodeCurrentAndConductance(comp, vd)
                        val iEq = iD - gD * vd
                        stampConductance(a, k, gD + G_MIN)
                        stampCurrentInjection(a, k, iEq)
                    }

                    "bjt_npn" -> {
                        val b = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b"] ?: continue
                        val c = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:c"] ?: continue
                        val e = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:e"] ?: continue
                        val beta = (comp.properties["hfe"]?.toDoubleOrNull() ?: 150.0).coerceIn(20.0, 500.0)
                        val vbe = vCurrent[b] - vCurrent[e]
                        val vce = vCurrent[c] - vCurrent[e]

                        val (iBe, gBe) = evalShockleyJunction(vbe, nFactor = 1.6, iSat = 1e-12, vClamp = 0.85)
                        val iBeEq = iBe - gBe * vbe
                        stampConductance(b, e, gBe + G_MIN)
                        stampCurrentInjection(b, e, iBeEq)

                        // Controlled collector current Ic = beta * Ibe * tanh_sat(Vce)
                        val sat = if (vce >= 0.0) tanh(vce / 0.14) else 0.0
                        val dSatDvce = if (vce >= 0.0) {
                            val t = tanh(vce / 0.14)
                            (1.0 - t * t) / 0.14
                        } else 0.0
                        val gm = beta * gBe * sat
                        val go = (beta * iBe * dSatDvce).coerceAtLeast(0.0) + 1e-7
                        val iC = beta * iBe * sat

                        // Linearize Ic around (vbe, vce)
                        val iC0 = iC - gm * vbe - go * vce
                        if (c > 0 && b > 0) gMat[c - 1][b - 1] += gm
                        if (c > 0 && e > 0) gMat[c - 1][e - 1] -= gm
                        if (e > 0 && b > 0) gMat[e - 1][b - 1] -= gm
                        if (e > 0) gMat[e - 1][e - 1] += gm

                        stampConductance(c, e, go)
                        stampCurrentInjection(c, e, iC0)
                    }

                    "bjt_pnp" -> {
                        val b = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b"] ?: continue
                        val c = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:c"] ?: continue
                        val e = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:e"] ?: continue
                        val beta = (comp.properties["hfe"]?.toDoubleOrNull() ?: 120.0).coerceIn(20.0, 500.0)
                        val veb = vCurrent[e] - vCurrent[b]
                        val vec = vCurrent[e] - vCurrent[c]

                        val (iEb, gEb) = evalShockleyJunction(veb, nFactor = 1.6, iSat = 1e-12, vClamp = 0.85)
                        val iEbEq = iEb - gEb * veb
                        stampConductance(e, b, gEb + G_MIN)
                        stampCurrentInjection(e, b, iEbEq)

                        val sat = if (vec >= 0.0) tanh(vec / 0.14) else 0.0
                        val dSatDvec = if (vec >= 0.0) {
                            val t = tanh(vec / 0.14)
                            (1.0 - t * t) / 0.14
                        } else 0.0
                        val gm = beta * gEb * sat
                        val go = (beta * iEb * dSatDvec).coerceAtLeast(0.0) + 1e-7
                        val iEc = beta * iEb * sat
                        val iC0 = iEc - gm * veb - go * vec

                        // Ic flows from e -> c: +Ic leaves e, -Ic enters c
                        if (e > 0 && e > 0) gMat[e - 1][e - 1] += gm
                        if (e > 0 && b > 0) gMat[e - 1][b - 1] -= gm
                        if (c > 0 && e > 0) gMat[c - 1][e - 1] -= gm
                        if (c > 0 && b > 0) gMat[c - 1][b - 1] += gm

                        stampConductance(e, c, go)
                        stampCurrentInjection(e, c, iC0)
                    }

                    "n_mosfet" -> {
                        val gPin = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:g"] ?: continue
                        val dPin = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:d"] ?: continue
                        val sPin = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:s"] ?: continue
                        val vTh = (comp.properties["vgsTh"]?.toDoubleOrNull() ?: 3.0).coerceIn(0.5, 8.0)
                        val rOn = (comp.properties["rdsOn"]?.toDoubleOrNull() ?: 0.05).coerceAtLeast(0.01)
                        val vgs = vCurrent[gPin] - vCurrent[sPin]
                        val vds = vCurrent[dPin] - vCurrent[sPin]

                        // High-impedance insulated gate
                        stampConductance(gPin, sPin, 1e-9)

                        val gMax = 1.0 / rOn
                        val gChannel = if (vgs > vTh) {
                            val ov = (vgs - vTh).coerceAtMost(5.0)
                            (gMax * (ov / 2.0)).coerceIn(G_OPEN, gMax)
                        } else G_OPEN
                        stampConductance(dPin, sPin, gChannel + G_MIN)

                        // Body diode s -> d
                        if (vds < -0.5) {
                            val (iBody, gBody) = evalShockleyJunction(-vds, nFactor = 1.6, iSat = 1e-11, vClamp = 0.85)
                            val iBodyEq = iBody - gBody * (-vds)
                            stampConductance(sPin, dPin, gBody)
                            stampCurrentInjection(sPin, dPin, iBodyEq)
                        }
                    }
                }
            }

            val solved = solveLinearSystem(gMat, rhs)
                ?: return SolverSolution(
                    nodeVoltages = vCurrent,
                    converged = false,
                    iterations = iter,
                    errorMessage = "Singular circuit matrix encountered (check shorted loops)."
                )

            var maxStep = 0.0
            for (i in 1 until nNodes) {
                val target = solved[i - 1]
                val rawDelta = target - vCurrent[i]
                val clampedDelta = rawDelta.coerceIn(-1.5, 1.5)
                vCurrent[i] += clampedDelta
                maxStep = max(maxStep, abs(rawDelta))
            }
            if (maxStep < CONVERGENCE_TOL_V) {
                converged = true
                break
            }
        }

        return SolverSolution(vCurrent, converged, iters)
    }

    private fun evalDiodeCurrentAndConductance(comp: PlacedComponent, vd: Double): Pair<Double, Double> {
        return when (comp.typeId) {
            "led_5mm" -> {
                val vf = (comp.properties["vf"]?.toDoubleOrNull() ?: 2.0).coerceIn(1.2, 4.0)
                val nVt = 2.0 * THERMAL_V
                // Calibrate Is so at vd == vf, I_led = 15 mA
                val iSat = 0.015 / exp(vf / nVt)
                evalShockleyJunction(vd, nFactor = 2.0, iSat = iSat, vClamp = vf + 0.35)
            }
            "diode_zener" -> {
                val vz = (comp.properties["vz"]?.toDoubleOrNull() ?: 5.1).coerceIn(1.8, 24.0)
                if (vd >= -vz * 0.85) {
                    evalShockleyJunction(vd, nFactor = 1.7, iSat = 1e-11, vClamp = 0.90)
                } else {
                    // Zener reverse breakdown at -vz
                    val vRev = (-vd) - vz
                    val (iZ, gZ) = evalShockleyJunction(vRev + 0.7, nFactor = 1.5, iSat = 1e-11, vClamp = 1.0)
                    -iZ to gZ
                }
            }
            else -> evalShockleyJunction(vd, nFactor = 1.7, iSat = 1e-11, vClamp = 0.90)
        }
    }

    private fun evalShockleyJunction(
        v: Double,
        nFactor: Double,
        iSat: Double,
        vClamp: Double
    ): Pair<Double, Double> {
        val nVt = nFactor * THERMAL_V
        return if (v <= vClamp) {
            val e = exp((v / nVt).coerceAtLeast(-40.0))
            val i = iSat * (e - 1.0)
            val g = (iSat / nVt) * e
            i to g
        } else {
            val eClamp = exp(vClamp / nVt)
            val iClamp = iSat * (eClamp - 1.0)
            val gClamp = (iSat / nVt) * eClamp
            val i = iClamp + gClamp * (v - vClamp)
            i to gClamp
        }
    }

    private fun evaluateComponentReading(
        comp: PlacedComponent,
        netData: UnionNetData,
        nodeVoltages: DoubleArray,
        transientState: CircuitTransientState,
        preStepCapVoltages: Map<String, Double>,
        dtSec: Double,
        sourceSeriesROverrides: Map<String, Double>,
        pinVoltages: Map<String, Double>,
        isFloating: Boolean,
        warnings: MutableList<SimulationWarning>
    ): ComponentSimulationReading {
        val def = LabComponentCatalog.find(comp.typeId)
        val name = def?.nameEn ?: comp.typeId
        return when (comp.typeId) {
            "battery_9v", "battery_aa", "dc_psu" -> {
                val pos = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:pos"] ?: 0
                val neg = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:neg"] ?: 0
                val rawV = comp.properties["voltage"]?.toDoubleOrNull()
                    ?: if (comp.typeId == "battery_aa") 1.5 else if (comp.typeId == "dc_psu") 5.0 else 9.0
                val enabled = comp.typeId != "dc_psu" || comp.properties["state"] != "OFF"
                val emf = if (!enabled) 0.0 else if (comp.properties["polarity"] == "Reversed") -rawV else rawV
                val rInt = sourceSeriesROverrides[comp.instanceId] ?: 0.05
                val vTerm = nodeVoltages[pos] - nodeVoltages[neg]
                val iAmp = if (enabled) (emf - vTerm) / rInt else 0.0
                val iMa = iAmp * 1000.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vTerm,
                    currentMa = iMa,
                    powerMw = abs(vTerm * iMa),
                    isConducting = abs(iMa) > 0.01,
                    isFloating = false,
                    pinVoltagesV = pinVoltages
                )
            }

            "resistor", "ldr_sensor", "jumper_bridge" -> {
                val (p1, p2) = twoPinIndices(comp, netData) ?: return ComponentSimulationReading(comp.instanceId, comp.typeId)
                val r = when (comp.typeId) {
                    "resistor" -> parseResistanceOhms(comp.properties["value"], comp.properties["unit"])
                    "ldr_sensor" -> parseLdrOhms(comp.properties["luxLevel"], comp.properties["darkOhms"])
                    else -> 0.02
                }
                val vDrop = nodeVoltages[p1] - nodeVoltages[p2]
                val iMa = (vDrop / r) * 1000.0
                val pMw = abs(vDrop * iMa)
                if (comp.typeId == "resistor" && pMw > 250.0) {
                    warnings += SimulationWarning(
                        category = WarningCategory.POWER_RATING_EXCEEDED,
                        severity = SafetySeverity.WARNING,
                        componentId = comp.instanceId,
                        messageEn = "$name dissipating ${"%.0f".format(pMw)} mW (> 250 mW standard ¼W rating)!"
                    )
                }
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vDrop,
                    currentMa = iMa,
                    powerMw = pMw,
                    effectiveResistanceOhms = r,
                    isConducting = abs(iMa) > 0.01,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "potentiometer" -> {
                val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: 0
                val w = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:wiper"] ?: 0
                val t2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t2"] ?: 0
                val rTotal = parseResistanceOhms(comp.properties["value"], comp.properties["unit"])
                val alpha = ((comp.properties["wiperPct"]?.toDoubleOrNull() ?: 50.0) / 100.0).coerceIn(0.01, 0.99)
                val v1 = nodeVoltages[t1] - nodeVoltages[w]
                val v2 = nodeVoltages[w] - nodeVoltages[t2]
                val i1 = v1 / (rTotal * alpha)
                val i2 = v2 / (rTotal * (1.0 - alpha))
                val iAvgMa = ((abs(i1) + abs(i2)) * 0.5) * 1000.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = nodeVoltages[t1] - nodeVoltages[t2],
                    currentMa = iAvgMa,
                    powerMw = (abs(v1 * i1) + abs(v2 * i2)) * 1000.0,
                    effectiveResistanceOhms = rTotal,
                    isConducting = iAvgMa > 0.01,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "cap_ceramic", "cap_electrolytic" -> {
                val (p1, p2) = twoPinIndices(comp, netData) ?: return ComponentSimulationReading(comp.instanceId, comp.typeId)
                val vCap = nodeVoltages[p1] - nodeVoltages[p2]
                val capF = parseCapacitanceFarads(comp.properties["capacitance"], comp.properties["unit"])
                val prevCapV = preStepCapVoltages[comp.instanceId] ?: 0.0
                val vRated = comp.properties["voltageRating"]?.replace("V", "", ignoreCase = true)?.toDoubleOrNull() ?: 25.0
                if (abs(vCap) > vRated) {
                    warnings += SimulationWarning(
                        category = WarningCategory.CAPACITOR_OVERVOLTAGE,
                        severity = SafetySeverity.CRITICAL,
                        componentId = comp.instanceId,
                        messageEn = "$name voltage (${"%.1f".format(abs(vCap))}V) exceeds ${vRated}V rating!"
                    )
                }
                if (comp.typeId == "cap_electrolytic" && vCap < -0.5) {
                    warnings += SimulationWarning(
                        category = WarningCategory.REVERSE_POLARITY,
                        severity = SafetySeverity.CRITICAL,
                        componentId = comp.instanceId,
                        messageEn = "Reverse polarity across Electrolytic Capacitor (${"%.2f".format(vCap)}V)!"
                    )
                }
                val dvDt = (vCap - prevCapV) / dtSec
                val iMa = capF * dvDt * 1000.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vCap,
                    currentMa = iMa,
                    powerMw = abs(vCap * iMa),
                    isConducting = abs(iMa) > 0.01,
                    isReverseBiased = comp.typeId == "cap_electrolytic" && vCap < -0.5,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "inductor" -> {
                val (p1, p2) = twoPinIndices(comp, netData) ?: return ComponentSimulationReading(comp.instanceId, comp.typeId)
                val vL = nodeVoltages[p1] - nodeVoltages[p2]
                val iMa = (transientState.inductorCurrents[comp.instanceId] ?: 0.0) * 1000.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vL,
                    currentMa = iMa,
                    powerMw = abs(vL * iMa),
                    isConducting = abs(iMa) > 0.01,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "diode_1n4007", "diode_zener", "led_5mm" -> {
                val a = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:anode"] ?: 0
                val k = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:cathode"] ?: 0
                val vd = nodeVoltages[a] - nodeVoltages[k]
                val (iAmp, _) = evalDiodeCurrentAndConductance(comp, vd)
                val iMa = if (isFloating) 0.0 else iAmp * 1000.0
                val maxMa = comp.properties["maxMa"]?.toDoubleOrNull() ?: 20.0
                val reverseBiased = !isFloating && vd < -0.45 && (comp.typeId != "diode_zener")

                if (comp.typeId == "led_5mm") {
                    if (reverseBiased) {
                        warnings += SimulationWarning(
                            category = WarningCategory.REVERSE_POLARITY,
                            severity = SafetySeverity.WARNING,
                            componentId = comp.instanceId,
                            messageEn = "LED is reverse-biased (${"%.2f".format(vd)}V) — no forward conduction."
                        )
                    }
                    if (iMa > maxMa) {
                        warnings += SimulationWarning(
                            category = WarningCategory.EXCESSIVE_CURRENT,
                            severity = SafetySeverity.CRITICAL,
                            componentId = comp.instanceId,
                            messageEn = "LED over-current: ${"%.1f".format(iMa)} mA exceeds ${maxMa.roundToInt()} mA rated limit!"
                        )
                    }
                }

                val brightness = if (comp.typeId == "led_5mm" && iMa > 0.2) {
                    (iMa / maxMa).toFloat().coerceIn(0.05f, 1.0f)
                } else 0f

                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vd,
                    currentMa = iMa,
                    powerMw = abs(vd * iMa),
                    brightnessFraction = brightness,
                    isConducting = abs(iMa) > 0.05,
                    isReverseBiased = reverseBiased,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "bjt_npn", "bjt_pnp" -> {
                val b = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b"] ?: 0
                val c = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:c"] ?: 0
                val e = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:e"] ?: 0
                val beta = (comp.properties["hfe"]?.toDoubleOrNull() ?: 150.0).coerceIn(20.0, 500.0)
                val isNpn = comp.typeId == "bjt_npn"
                val vbe = if (isNpn) nodeVoltages[b] - nodeVoltages[e] else nodeVoltages[e] - nodeVoltages[b]
                val vce = if (isNpn) nodeVoltages[c] - nodeVoltages[e] else nodeVoltages[e] - nodeVoltages[c]
                val (iBe, _) = evalShockleyJunction(vbe, nFactor = 1.6, iSat = 1e-12, vClamp = 0.85)
                val sat = if (vce >= 0.0) tanh(vce / 0.14) else 0.0
                val iCMa = if (isFloating) 0.0 else (beta * iBe * sat) * 1000.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vce,
                    currentMa = iCMa,
                    powerMw = abs(vce * iCMa),
                    isConducting = abs(iCMa) > 0.05,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "n_mosfet" -> {
                val gPin = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:g"] ?: 0
                val dPin = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:d"] ?: 0
                val sPin = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:s"] ?: 0
                val vTh = (comp.properties["vgsTh"]?.toDoubleOrNull() ?: 3.0)
                val rOn = (comp.properties["rdsOn"]?.toDoubleOrNull() ?: 0.05).coerceAtLeast(0.01)
                val vgs = nodeVoltages[gPin] - nodeVoltages[sPin]
                val vds = nodeVoltages[dPin] - nodeVoltages[sPin]
                val gChannel = if (vgs > vTh) {
                    ((1.0 / rOn) * ((vgs - vTh).coerceAtMost(5.0) / 2.0)).coerceIn(G_OPEN, 1.0 / rOn)
                } else G_OPEN
                val iMa = if (isFloating) 0.0 else (vds * gChannel) * 1000.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vds,
                    currentMa = iMa,
                    powerMw = abs(vds * iMa),
                    isConducting = vgs > vTh && abs(iMa) > 0.05,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "slide_switch" -> {
                val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: 0
                val com = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:com"] ?: 0
                val isOn = comp.properties["state"] == "ON"
                val vDrop = nodeVoltages[t1] - nodeVoltages[com]
                val iMa = if (isOn && !isFloating) (vDrop / R_SWITCH_ON) * 1000.0 else 0.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vDrop,
                    currentMa = iMa,
                    isConducting = isOn && abs(iMa) > 0.01,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "pushbutton" -> {
                val a1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:a1"] ?: 0
                val b1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b1"] ?: 0
                val isOn = comp.properties["state"] == "ON"
                val vDrop = nodeVoltages[a1] - nodeVoltages[b1]
                val iMa = if (isOn && !isFloating) (vDrop / R_SWITCH_ON) * 1000.0 else 0.0
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vDrop,
                    currentMa = iMa,
                    isConducting = isOn && abs(iMa) > 0.01,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "relay_5v" -> {
                val c1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil1"] ?: 0
                val c2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil2"] ?: 0
                val rCoil = (comp.properties["coilOhms"]?.toDoubleOrNull() ?: 70.0).coerceAtLeast(5.0)
                val vCoil = nodeVoltages[c1] - nodeVoltages[c2]
                val iCoilMa = (vCoil / rCoil) * 1000.0
                val energized = transientState.relayEnergized[comp.instanceId] == true
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vCoil,
                    currentMa = iCoilMa,
                    powerMw = abs(vCoil * iCoilMa),
                    isConducting = abs(iCoilMa) > 0.5,
                    relayEnergized = energized,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            "dc_motor" -> {
                val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: 0
                val t2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t2"] ?: 0
                val vM = nodeVoltages[t1] - nodeVoltages[t2]
                val ratedV = (comp.properties["ratedV"]?.toDoubleOrNull() ?: 6.0).coerceAtLeast(1.0)
                val ratedRpm = (comp.properties["rpm"]?.toDoubleOrNull() ?: 6000.0)
                val iMa = if (isFloating) 0.0 else (vM / 8.0) * 1000.0
                val rpm = if (abs(vM) > 0.25 && !isFloating) ((abs(vM) / ratedV) * ratedRpm).toFloat() else 0f
                ComponentSimulationReading(
                    instanceId = comp.instanceId,
                    typeId = comp.typeId,
                    voltageDropV = vM,
                    currentMa = iMa,
                    powerMw = abs(vM * iMa),
                    motorRpm = rpm,
                    isConducting = abs(iMa) > 1.0,
                    isFloating = isFloating,
                    pinVoltagesV = pinVoltages
                )
            }

            else -> ComponentSimulationReading(
                instanceId = comp.instanceId,
                typeId = comp.typeId,
                isFloating = isFloating,
                pinVoltagesV = pinVoltages
            )
        }
    }

    private fun computeClosedLoopComponents(
        snapshot: LabCircuitSnapshot,
        netData: UnionNetData,
        transientState: CircuitTransientState
    ): Set<String> {
        val adj = mutableMapOf<Int, MutableList<Pair<Int, String>>>()
        fun addEdge(a: Int, b: Int, compId: String) {
            adj.getOrPut(a) { mutableListOf() }.add(b to compId)
            adj.getOrPut(b) { mutableListOf() }.add(a to compId)
        }

        val energizedSources = mutableListOf<Triple<String, Int, Int>>()
        for (comp in snapshot.components) {
            when (comp.typeId) {
                "battery_9v", "battery_aa", "dc_psu" -> {
                    val enabled = comp.typeId != "dc_psu" || comp.properties["state"] != "OFF"
                    if (enabled) {
                        val p = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:pos"] ?: continue
                        val n = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:neg"] ?: continue
                        energizedSources += Triple(comp.instanceId, p, n)
                    }
                }
                "resistor", "ldr_sensor", "jumper_bridge", "cap_ceramic", "cap_electrolytic",
                "inductor", "dc_motor", "diode_1n4007", "diode_zener", "led_5mm" -> {
                    val (p1, p2) = twoPinIndices(comp, netData) ?: continue
                    addEdge(p1, p2, comp.instanceId)
                }
                "potentiometer" -> {
                    val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: continue
                    val w = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:wiper"] ?: continue
                    val t2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t2"] ?: continue
                    addEdge(t1, w, comp.instanceId)
                    addEdge(w, t2, comp.instanceId)
                }
                "slide_switch" -> {
                    val t1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t1"] ?: continue
                    val com = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:com"] ?: continue
                    val t2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:t2"] ?: continue
                    if (comp.properties["state"] == "ON") addEdge(t1, com, comp.instanceId)
                    else addEdge(com, t2, comp.instanceId)
                }
                "pushbutton" -> {
                    val a1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:a1"] ?: continue
                    val a2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:a2"] ?: continue
                    val b1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b1"] ?: continue
                    val b2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b2"] ?: continue
                    addEdge(a1, a2, comp.instanceId)
                    addEdge(b1, b2, comp.instanceId)
                    if (comp.properties["state"] == "ON") addEdge(a1, b1, comp.instanceId)
                }
                "bjt_npn", "bjt_pnp" -> {
                    val b = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:b"] ?: continue
                    val c = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:c"] ?: continue
                    val e = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:e"] ?: continue
                    addEdge(b, e, comp.instanceId)
                    addEdge(c, e, comp.instanceId)
                }
                "n_mosfet" -> {
                    val d = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:d"] ?: continue
                    val s = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:s"] ?: continue
                    addEdge(d, s, comp.instanceId)
                }
                "relay_5v" -> {
                    val c1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil1"] ?: continue
                    val c2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:coil2"] ?: continue
                    val com = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:com"] ?: continue
                    val no = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:no"] ?: continue
                    val nc = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:nc"] ?: continue
                    addEdge(c1, c2, comp.instanceId)
                    if (transientState.relayEnergized[comp.instanceId] == true) addEdge(com, no, comp.instanceId)
                    else addEdge(com, nc, comp.instanceId)
                }
            }
        }

        // A component is part of a closed source-to-source loop if it lies on paths reachable from BOTH pos and neg without crossing through the source itself
        val result = mutableSetOf<String>()
        for ((srcId, pos, neg) in energizedSources) {
            fun bfs(start: Int): Set<Int> {
                val visited = mutableSetOf(start)
                val q = ArrayDeque<Int>()
                q.add(start)
                while (q.isNotEmpty()) {
                    val cur = q.removeFirst()
                    for ((nxt, _) in adj[cur].orEmpty()) {
                        if (nxt !in visited) {
                            visited += nxt
                            q.add(nxt)
                        }
                    }
                }
                return visited
            }
            val reachFromPos = bfs(pos)
            val reachFromNeg = bfs(neg)
            val bothReachable = reachFromPos intersect reachFromNeg
            if (bothReachable.isNotEmpty()) {
                result += srcId
                for (node in bothReachable) {
                    for ((nxt, compId) in adj[node].orEmpty()) {
                        if (nxt in bothReachable) result += compId
                    }
                }
            }
        }
        return result
    }

    private fun twoPinIndices(comp: PlacedComponent, netData: UnionNetData): Pair<Int, Int>? {
        val def = LabComponentCatalog.find(comp.typeId) ?: return null
        if (def.pins.size < 2) return null
        val p1 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:${def.pins[0].id}"] ?: return null
        val p2 = netData.canonicalKeyToNetIdx["PIN:${comp.instanceId}:${def.pins[1].id}"] ?: return null
        return p1 to p2
    }

    private fun parseResistanceOhms(valueStr: String?, unit: String?): Double {
        val v = valueStr?.toDoubleOrNull()?.coerceAtLeast(0.1) ?: 330.0
        val mult = when (unit?.trim()) {
            "kΩ", "k" -> 1_000.0
            "MΩ", "M" -> 1_000_000.0
            else -> 1.0
        }
        return (v * mult).coerceIn(0.1, 1e9)
    }

    private fun parseCapacitanceFarads(valueStr: String?, unit: String?): Double {
        val v = valueStr?.toDoubleOrNull()?.coerceAtLeast(0.01) ?: 100.0
        val mult = when (unit?.trim()) {
            "pF" -> 1e-12
            "nF" -> 1e-9
            "µF", "uF" -> 1e-6
            "mF" -> 1e-3
            else -> 1e-6
        }
        return (v * mult).coerceIn(1e-12, 1.0)
    }

    private fun parseInductanceHenries(valueStr: String?, unit: String?): Double {
        val v = valueStr?.toDoubleOrNull()?.coerceAtLeast(0.01) ?: 100.0
        val mult = when (unit?.trim()) {
            "µH", "uH" -> 1e-6
            "mH" -> 1e-3
            "H" -> 1.0
            else -> 1e-6
        }
        return (v * mult).coerceIn(1e-6, 100.0)
    }

    private fun parseLdrOhms(luxStr: String?, darkStr: String?): Double {
        val lux = (luxStr?.toDoubleOrNull() ?: 500.0).coerceIn(1.0, 10_000.0)
        val dark = (darkStr?.toDoubleOrNull() ?: 100_000.0).coerceAtLeast(1_000.0)
        return (dark / (1.0 + lux * 0.08)).coerceIn(200.0, 2_000_000.0)
    }

    /**
     * Dense Gaussian elimination with partial pivoting (n <= ~100 circuit nets runs in microseconds).
     */
    private fun solveLinearSystem(a: Array<DoubleArray>, b: DoubleArray): DoubleArray? {
        val n = b.size
        val m = Array(n) { r -> DoubleArray(n + 1) { c -> if (c < n) a[r][c] else b[r] } }

        for (col in 0 until n) {
            var pivotRow = col
            var maxVal = abs(m[col][col])
            for (r in (col + 1) until n) {
                val v = abs(m[r][col])
                if (v > maxVal) {
                    maxVal = v
                    pivotRow = r
                }
            }
            if (maxVal < 1e-15 || !maxVal.isFinite()) return null

            if (pivotRow != col) {
                val tmp = m[col]
                m[col] = m[pivotRow]
                m[pivotRow] = tmp
            }

            val diag = m[col][col]
            for (r in (col + 1) until n) {
                val factor = m[r][col] / diag
                if (factor == 0.0) continue
                for (c in col..n) {
                    m[r][c] -= factor * m[col][c]
                }
            }
        }

        val x = DoubleArray(n)
        for (r in (n - 1) downTo 0) {
            var sum = m[r][n]
            for (c in (r + 1) until n) {
                sum -= m[r][c] * x[c]
            }
            val res = sum / m[r][r]
            if (!res.isFinite()) return null
            x[r] = res
        }
        return x
    }
}
