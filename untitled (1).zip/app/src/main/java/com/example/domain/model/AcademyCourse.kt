package com.example.domain.model

import com.example.core.localization.AppLanguage

enum class AcademyCourse(
    val id: String,
    val courseNumber: Int,
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val difficultyEn: String,
    val difficultyBn: String
) {
    COURSE_1_BASIC(
        id = "c1_basic",
        courseNumber = 1,
        titleEn = "Basic Electronics",
        titleBn = "বেসিক ইলেকট্রনিক্স",
        subtitleEn = "Voltage, current, Ohm's law, power, series & parallel circuits, units and meters",
        subtitleBn = "ভোল্টেজ, কারেন্ট, ওহমের সূত্র, পাওয়ার, সিরিজ ও প্যারালাল সার্কিট ও পরিমাপ",
        difficultyEn = "Beginner",
        difficultyBn = "প্রাথমিক"
    ),
    COURSE_2_PASSIVE(
        id = "c2_passive",
        courseNumber = 2,
        titleEn = "Passive Components",
        titleBn = "প্যাসিভ কম্পোনেন্ট",
        subtitleEn = "Resistors, capacitors, inductors, transformers, potentiometers, thermistors & LDR",
        subtitleBn = "রেজিস্টর, ক্যাপাসিটর, ইন্ডাক্টর, ট্রান্সফরমার, পটেনশিওমিটার, থার্মিস্টর ও এলডিআর",
        difficultyEn = "Beginner → Intermediate",
        difficultyBn = "প্রাথমিক → মধ্যম"
    ),
    COURSE_3_SEMI(
        id = "c3_semi",
        courseNumber = 3,
        titleEn = "Semiconductor Electronics",
        titleBn = "সেমিকন্ডাক্টর ইলেকট্রনিক্স",
        subtitleEn = "PN, Zener, Schottky, LED, NPN/PNP BJTs, MOSFET, JFET, SCR & TRIAC",
        subtitleBn = "পিএন, জেনার, শটকি, এলইডি, এনপিএন/পিএনপি ট্রানজিস্টর, মসফেট, জেফেট, এসসিআর ও ট্রায়াক",
        difficultyEn = "Intermediate",
        difficultyBn = "মধ্যম"
    ),
    COURSE_4_ANALOG(
        id = "c4_analog",
        courseNumber = 4,
        titleEn = "Analog Electronics",
        titleBn = "অ্যানালগ ইলেকট্রনিক্স",
        subtitleEn = "Rectifiers, filters, linear regulators, amplifiers, op-amps, 555 timer & oscillators",
        subtitleBn = "রেক্টিফায়ার, ফিল্টার সার্কিট, ভোল্টেজ রেগুলেটর, অ্যামপ্লিফায়ার, অপ-অ্যাম্প, ৫৫৫ টাইমার ও অসিলেটর",
        difficultyEn = "Intermediate",
        difficultyBn = "মধ্যম"
    ),
    COURSE_5_DIGITAL(
        id = "c5_digital",
        courseNumber = 5,
        titleEn = "Digital Electronics",
        titleBn = "ডিজিটাল ইলেকট্রনিক্স",
        subtitleEn = "Binary numbers, logic gates, Boolean algebra, flip-flops, counters, registers & ADC/DAC",
        subtitleBn = "বাইনারি সংখ্যা, লজিক গেট, বুলিয়ান অ্যালজেব্রা, ফ্লিপ-ফ্লপ, কাউন্টার, রেজিস্টার ও এডিসি/ডিএসি",
        difficultyEn = "Intermediate → Advanced",
        difficultyBn = "মধ্যম → উন্নত"
    ),
    COURSE_6_POWER(
        id = "c6_power",
        courseNumber = 6,
        titleEn = "Power Electronics",
        titleBn = "পাওয়ার ইলেকট্রনিক্স",
        subtitleEn = "Power supplies, bridge rectifiers, buck/boost converters, inverters, SMPS & BMS",
        subtitleBn = "পাওয়ার সাপ্লাই, ব্রিজ রেক্টিফায়ার, বাক/বুস্ট কনভার্টার, ইনভার্টার, এসএমপিএস ও বিএমএস",
        difficultyEn = "Advanced",
        difficultyBn = "উন্নত"
    ),
    COURSE_7_MCU(
        id = "c7_mcu",
        courseNumber = 7,
        titleEn = "Microcontrollers",
        titleBn = "মাইক্রোকন্ট্রোলার ও এমবেডেড",
        subtitleEn = "Arduino UNO/Nano, ESP32, ESP8266, digital/analog I/O, PWM, sensors & C++ coding",
        subtitleBn = "আরডুইনো ইউনো/ন্যানো, ইএসপি৩২, ইএসপি৮২৬৬, ডিজিটাল/অ্যানালগ ইনপুট-আউটপুট, পিডব্লিউএম ও প্রোগ্রামিং",
        difficultyEn = "Beginner → Advanced",
        difficultyBn = "প্রাথমিক → উন্নত"
    );

    fun title(lang: AppLanguage): String = if (lang == AppLanguage.BANGLA) titleBn else titleEn
    fun subtitle(lang: AppLanguage): String = if (lang == AppLanguage.BANGLA) subtitleBn else subtitleEn
    fun difficulty(lang: AppLanguage): String = if (lang == AppLanguage.BANGLA) difficultyBn else difficultyEn

    companion object {
        fun fromId(id: String): AcademyCourse =
            entries.firstOrNull { it.id == id } ?: COURSE_1_BASIC
    }
}
