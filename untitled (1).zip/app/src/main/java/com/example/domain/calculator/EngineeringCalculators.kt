package com.example.domain.calculator

import kotlin.math.PI
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

data class OhmResult(
    val voltageV: Double,
    val currentMa: Double,
    val resistanceOhm: Double,
    val powerMw: Double
)

data class DividerResult(
    val vOut: Double,
    val currentMa: Double,
    val powerR1Mw: Double,
    val powerR2Mw: Double
)

data class RcResult(
    val tauMs: Double,
    val charge63Ms: Double,
    val fullChargeMs: Double,
    val cutoffHz: Double
)

data class Ne555Result(
    val frequencyHz: Double,
    val dutyCyclePercent: Double,
    val highTimeMs: Double,
    val lowTimeMs: Double
)

data class ResistorBandColor(
    val key: String,
    val nameEn: String,
    val nameBn: String,
    val digit: Int?,
    val multiplier: Double,
    val tolerancePct: Double?,
    val colorHex: Long
)

object EngineeringCalculators {

    val resistorBands: List<ResistorBandColor> = listOf(
        ResistorBandColor("BLACK", "Black (0)", "কালো (০)", 0, 1.0, null, 0xFF111827),
        ResistorBandColor("BROWN", "Brown (1)", "বাদামী (১)", 1, 10.0, 1.0, 0xFF78350F),
        ResistorBandColor("RED", "Red (2)", "লাল (২)", 2, 100.0, 2.0, 0xFFDC2626),
        ResistorBandColor("ORANGE", "Orange (3)", "কমলা (৩)", 3, 1_000.0, null, 0xFFF97316),
        ResistorBandColor("YELLOW", "Yellow (4)", "হলুদ (৪)", 4, 10_000.0, null, 0xFFEAB308),
        ResistorBandColor("GREEN", "Green (5)", "সবুজ (৫)", 5, 100_000.0, 0.5, 0xFF16A34A),
        ResistorBandColor("BLUE", "Blue (6)", "নীল (৬)", 6, 1_000_000.0, 0.25, 0xFF2563EB),
        ResistorBandColor("VIOLET", "Violet (7)", "বেগুনি (৭)", 7, 10_000_000.0, 0.1, 0xFF7C3AED),
        ResistorBandColor("GREY", "Grey (8)", "ধূসর (৮)", 8, 100_000_000.0, 0.05, 0xFF64748B),
        ResistorBandColor("WHITE", "White (9)", "সাদা (৯)", 9, 1_000_000_000.0, null, 0xFFF8FAFC),
        ResistorBandColor("GOLD", "Gold (×0.1)", "সোনালী (×০.১)", null, 0.1, 5.0, 0xFFF59E0B),
        ResistorBandColor("SILVER", "Silver (×0.01)", "রুপালী (×০.০১)", null, 0.01, 10.0, 0xFFCBD5E1)
    )

    fun solveOhmsLawFromVR(voltageV: Double, resistanceOhm: Double): OhmResult {
        val safeR = resistanceOhm.coerceAtLeast(0.1)
        val iAmp = voltageV / safeR
        val powerW = voltageV * iAmp
        return OhmResult(
            voltageV = voltageV,
            currentMa = iAmp * 1000.0,
            resistanceOhm = safeR,
            powerMw = powerW * 1000.0
        )
    }

    fun solveLedSeriesResistor(supplyV: Double, ledForwardV: Double, targetCurrentMa: Double): OhmResult {
        val safeI = (targetCurrentMa / 1000.0).coerceAtLeast(0.0005)
        val dropV = (supplyV - ledForwardV).coerceAtLeast(0.0)
        val rOhm = dropV / safeI
        val powerMw = dropV * targetCurrentMa
        return OhmResult(
            voltageV = dropV,
            currentMa = targetCurrentMa,
            resistanceOhm = rOhm,
            powerMw = powerMw
        )
    }

    fun solveSeriesParallel(r1Ohm: Double, r2Ohm: Double): Pair<Double, Double> {
        val safeR1 = r1Ohm.coerceAtLeast(0.1)
        val safeR2 = r2Ohm.coerceAtLeast(0.1)
        val series = safeR1 + safeR2
        val parallel = (safeR1 * safeR2) / (safeR1 + safeR2)
        return series to parallel
    }

    fun solveVoltageDivider(vIn: Double, r1Ohm: Double, r2Ohm: Double): DividerResult {
        val safeR1 = r1Ohm.coerceAtLeast(0.1)
        val safeR2 = r2Ohm.coerceAtLeast(0.1)
        val total = safeR1 + safeR2
        val currentAmp = vIn / total
        val vOut = vIn * (safeR2 / total)
        return DividerResult(
            vOut = vOut,
            currentMa = currentAmp * 1000.0,
            powerR1Mw = currentAmp.pow(2) * safeR1 * 1000.0,
            powerR2Mw = currentAmp.pow(2) * safeR2 * 1000.0
        )
    }

    fun solveRcCircuit(rOhm: Double, cUf: Double): RcResult {
        val safeR = rOhm.coerceAtLeast(1.0)
        val safeCFarads = (cUf.coerceAtLeast(0.001)) * 1e-6
        val tauSec = safeR * safeCFarads
        val tauMs = tauSec * 1000.0
        val cutoffHz = 1.0 / (2.0 * PI * tauSec)
        return RcResult(
            tauMs = tauMs,
            charge63Ms = tauMs,
            fullChargeMs = tauMs * 5.0,
            cutoffHz = cutoffHz
        )
    }

    fun solveNe555Astable(raOhm: Double, rbOhm: Double, cUf: Double): Ne555Result {
        val ra = raOhm.coerceAtLeast(100.0)
        val rb = rbOhm.coerceAtLeast(100.0)
        val cFarads = (cUf.coerceAtLeast(0.001)) * 1e-6
        val tHighSec = ln(2.0) * (ra + rb) * cFarads
        val tLowSec = ln(2.0) * rb * cFarads
        val period = tHighSec + tLowSec
        val freq = 1.0 / period
        val duty = (tHighSec / period) * 100.0
        return Ne555Result(
            frequencyHz = freq,
            dutyCyclePercent = duty,
            highTimeMs = tHighSec * 1000.0,
            lowTimeMs = tLowSec * 1000.0
        )
    }

    fun solveBuckConverter(vIn: Double, dutyPercent: Double, efficiencyPct: Double = 90.0): Triple<Double, Double, Double> {
        val d = (dutyPercent / 100.0).coerceIn(0.05, 0.95)
        val vOut = vIn * d
        val vInRatio = if (vOut > 0) (vOut / vIn) * 100.0 else 0.0
        return Triple(vOut, vInRatio, efficiencyPct)
    }

    fun decodeFourBandResistor(
        band1: ResistorBandColor,
        band2: ResistorBandColor,
        multiplier: ResistorBandColor,
        tolerance: ResistorBandColor
    ): Pair<Double, Double> {
        val d1 = band1.digit ?: 1
        val d2 = band2.digit ?: 0
        val ohms = (d1 * 10 + d2) * multiplier.multiplier
        val tol = tolerance.tolerancePct ?: 5.0
        return ohms to tol
    }

    fun formatOhms(ohms: Double): String = when {
        ohms >= 1_000_000.0 -> "${((ohms / 1_000_000.0) * 100.0).roundToInt() / 100.0} MΩ"
        ohms >= 1_000.0 -> "${((ohms / 1_000.0) * 100.0).roundToInt() / 100.0} kΩ"
        else -> "${(ohms * 100.0).roundToInt() / 100.0} Ω"
    }

    fun formatFreq(hz: Double): String = when {
        hz >= 1_000_000.0 -> "${((hz / 1_000_000.0) * 100.0).roundToInt() / 100.0} MHz"
        hz >= 1_000.0 -> "${((hz / 1_000.0) * 100.0).roundToInt() / 100.0} kHz"
        else -> "${(hz * 100.0).roundToInt() / 100.0} Hz"
    }
}
