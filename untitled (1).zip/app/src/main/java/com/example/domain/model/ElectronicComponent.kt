package com.example.domain.model

import com.example.core.localization.AppLanguage
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ComponentVariation(
    val nameEn: String,
    val nameBn: String,
    val summaryEn: String,
    val summaryBn: String
) {
    fun name(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) nameBn else nameEn
    fun summary(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) summaryBn else summaryEn
}

@JsonClass(generateAdapter = true)
data class PinInfo(
    val pinLabel: String,
    val nameEn: String,
    val nameBn: String,
    val roleEn: String,
    val roleBn: String,
    val isPackageDependent: Boolean = false
) {
    fun name(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) nameBn else nameEn
    fun role(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) roleBn else roleEn
}

@JsonClass(generateAdapter = true)
data class SpecItem(
    val labelEn: String,
    val labelBn: String,
    val value: String,
    val noteEn: String = "",
    val noteBn: String = ""
) {
    fun label(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) labelBn else labelEn
    fun note(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) noteBn else noteEn
}

@JsonClass(generateAdapter = true)
data class UnitMeasurementInfo(
    val unitNameEn: String,
    val unitNameBn: String,
    val unitSymbol: String,
    val measurementToolEn: String,
    val measurementToolBn: String,
    val howToMeasureEn: String,
    val howToMeasureBn: String
) {
    fun unitName(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) unitNameBn else unitNameEn
    fun measurementTool(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) measurementToolBn else measurementToolEn
    fun howToMeasure(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) howToMeasureBn else howToMeasureEn
}

@JsonClass(generateAdapter = true)
data class PracticalCircuitInfo(
    val titleEn: String,
    val titleBn: String,
    val descriptionEn: String,
    val descriptionBn: String,
    val diagramType: String
) {
    fun title(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) titleBn else titleEn
    fun description(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) descriptionBn else descriptionEn
}

@JsonClass(generateAdapter = true)
data class ComponentSeedPayload(
    val id: String,
    val categoryId: String,
    val orderIndex: Int,
    val featured: Boolean = false,
    val nameEn: String,
    val nameBn: String,
    val summaryEn: String,
    val summaryBn: String,
    val symbolType: String,
    val illustrationType: String,
    val pinoutType: String,
    val comparisonType: String? = null,
    val structureEn: String,
    val structureBn: String,
    val introductionEn: String,
    val introductionBn: String,
    val whatItDoesEn: String,
    val whatItDoesBn: String,
    val howItWorksEn: String,
    val howItWorksBn: String,
    val workingPrincipleEn: String,
    val workingPrincipleBn: String,
    val typesAndVariations: List<ComponentVariation>,
    val pinConfiguration: List<PinInfo>,
    val technicalSpecs: List<SpecItem>,
    val unitAndMeasurement: UnitMeasurementInfo,
    val commonApplicationsEn: List<String>,
    val commonApplicationsBn: List<String>,
    val realLifeExamplesEn: List<String>,
    val realLifeExamplesBn: List<String>,
    val practicalCircuits: List<PracticalCircuitInfo>,
    val advantagesEn: List<String>,
    val advantagesBn: List<String>,
    val limitationsEn: List<String>,
    val limitationsBn: List<String>,
    val commonMistakesEn: List<String>,
    val commonMistakesBn: List<String>,
    val safetyInstructionsEn: List<String>,
    val safetyInstructionsBn: List<String>,
    val relatedComponentIds: List<String>,
    val beginnerExplanationEn: String,
    val beginnerExplanationBn: String,
    val advancedExplanationEn: String,
    val advancedExplanationBn: String
)

data class ElectronicComponent(
    val payload: ComponentSeedPayload,
    val isBookmarked: Boolean = false,
    val isStudied: Boolean = false,
    val lastViewedAt: Long = 0L,
    val viewCount: Int = 0
) {
    val id: String get() = payload.id
    val category: ComponentCategory get() = ComponentCategory.fromId(payload.categoryId)
    val featured: Boolean get() = payload.featured
    fun name(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.nameBn else payload.nameEn
    fun summary(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.summaryBn else payload.summaryEn
    fun structure(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.structureBn else payload.structureEn
    fun introduction(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.introductionBn else payload.introductionEn
    fun whatItDoes(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.whatItDoesBn else payload.whatItDoesEn
    fun howItWorks(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.howItWorksBn else payload.howItWorksEn
    fun workingPrinciple(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.workingPrincipleBn else payload.workingPrincipleEn
    fun commonApplications(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.commonApplicationsBn else payload.commonApplicationsEn
    fun realLifeExamples(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.realLifeExamplesBn else payload.realLifeExamplesEn
    fun advantages(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.advantagesBn else payload.advantagesEn
    fun limitations(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.limitationsBn else payload.limitationsEn
    fun commonMistakes(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.commonMistakesBn else payload.commonMistakesEn
    fun safetyInstructions(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.safetyInstructionsBn else payload.safetyInstructionsEn
    fun beginnerExplanation(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.beginnerExplanationBn else payload.beginnerExplanationEn
    fun advancedExplanation(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.advancedExplanationBn else payload.advancedExplanationEn
}
