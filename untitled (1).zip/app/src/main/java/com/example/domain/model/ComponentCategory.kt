package com.example.domain.model

import com.example.core.localization.AppLanguage

enum class ComponentCategory(
    val id: String,
    val chapterCode: String,
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String
) {
    PASSIVE(
        id = "A",
        chapterCode = "CH. A",
        titleEn = "Passive Components",
        titleBn = "প্যাসিভ কম্পোনেন্ট",
        subtitleEn = "Resistors, Capacitors, Inductors, Transformers, Thermistors, LDR",
        subtitleBn = "রেজিস্টর, ক্যাপাসিটর, ইন্ডাক্টর, ট্রান্সফরমার, থার্মিস্টর, এলডিআর"
    ),
    SEMICONDUCTOR(
        id = "B",
        chapterCode = "CH. B",
        titleEn = "Semiconductor Components",
        titleBn = "সেমিকন্ডাক্টর কম্পোনেন্ট",
        subtitleEn = "Diodes, LEDs, BJTs, JFET, MOSFET, IGBT, SCR, TRIAC, DIAC",
        subtitleBn = "ডায়োড, এলইডি, বিজেটি, জেফেট, মসফেট, আইজিবিটি, এসসিআর, ট্রায়াক"
    ),
    INTEGRATED_CIRCUITS(
        id = "C",
        chapterCode = "CH. C",
        titleEn = "Integrated Circuits",
        titleBn = "ইন্টিগ্রেটেড সার্কিট (IC)",
        subtitleEn = "555 Timer, Op-Amps, Logic Gates, Regulators, Drivers, Memory",
        subtitleBn = "৫৫৫ টাইমার, অপ-অ্যাম্প, লজিক গেট, ভোল্টেজ রেগুলেটর, ড্রাইভার আইসি"
    ),
    ELECTROMECHANICAL(
        id = "D",
        chapterCode = "CH. D",
        titleEn = "Electromechanical Components",
        titleBn = "ইলেকট্রোমেকানিক্যাল কম্পোনেন্ট",
        subtitleEn = "Relays, Switches, DC/Servo/Stepper Motors, Solenoids, Buzzers",
        subtitleBn = "রিলে, সুইচ, মোটর, সার্ভো, স্টেপার, সলেনয়েড, বাজার, স্পিকার"
    ),
    SENSORS(
        id = "E",
        chapterCode = "CH. E",
        titleEn = "Sensors",
        titleBn = "সেন্সর",
        subtitleEn = "Temp, Humidity, Pressure, Gas, PIR, IR, Ultrasonic, IMU",
        subtitleBn = "তাপমাত্রা, আর্দ্রতা, চাপ, গ্যাস, পিআইআর, আল্ট্রাসনিক, অ্যাক্সেলেরোমিটার"
    ),
    POWER_ELECTRONICS(
        id = "F",
        chapterCode = "CH. F",
        titleEn = "Power Electronics",
        titleBn = "পাওয়ার ইলেকট্রনিক্স",
        subtitleEn = "Rectifiers, Buck/Boost Converters, Inverters, SMPS, BMS, Chargers",
        subtitleBn = "রেক্টিফায়ার, বাক/বুস্ট কনভার্টার, ইনভার্টার, এসএমপিএস, বিএমএস"
    ),
    DISPLAYS(
        id = "G",
        chapterCode = "CH. G",
        titleEn = "Display Components",
        titleBn = "ডিসপ্লে কম্পোনেন্ট",
        subtitleEn = "LED, RGB LED, 7-Segment, LCD, OLED, TFT, Dot Matrix",
        subtitleBn = "এলইডি, আরজিবি এলইডি, সেভেন সেগমেন্ট, এলসিডি, ওএলইডি, টিএফটি"
    ),
    COMMUNICATION(
        id = "H",
        chapterCode = "CH. H",
        titleEn = "Communication Components",
        titleBn = "কমিউনিকেশন মডিউল",
        subtitleEn = "Bluetooth, Wi-Fi, ESP8266/ESP32, RF, GSM, GPS, RFID, LoRa, Zigbee",
        subtitleBn = "ব্লুটুথ, ওয়াই-ফাই, আরএফ, জিএসএম, জিপিএস, আরএফআইডি, লোরা, জিগবি"
    ),
    MICROCONTROLLERS(
        id = "I",
        chapterCode = "CH. I",
        titleEn = "Microcontrollers & Boards",
        titleBn = "মাইক্রোকন্ট্রোলার ও ডেভেলপমেন্ট বোর্ড",
        subtitleEn = "Arduino UNO/Nano/Mega, ESP32, RP2040 Pico, STM32, PIC",
        subtitleBn = "আরডুইনো, ইএসপি৩২, রাস্পবেরি পাই পিকো, এসটিএম৩২, পিক"
    ),
    CONNECTORS_WIRING(
        id = "J",
        chapterCode = "CH. J",
        titleEn = "Connectors & Wiring",
        titleBn = "কানেক্টর ও ওয়্যারিং",
        subtitleEn = "JST, USB, USB-C, HDMI, RJ45, Terminal Blocks, Breadboards, PCB",
        subtitleBn = "জেএসটি, ইউএসবি-সি, এইচডিএমআই, আরজে৪৫, ব্রেডবোর্ড, পিসিবি"
    ),
    PROTECTION(
        id = "K",
        chapterCode = "CH. K",
        titleEn = "Protection Components",
        titleBn = "সুরক্ষা কম্পোনেন্ট (Protection)",
        subtitleEn = "Fuses, PTC, MCB, RCCB, MOV, TVS Diode, Thermal Fuse, Surge",
        subtitleBn = "ফিউজ, পিটিসি, এমসিবি, আরসিসিবি, এমওভি, টিভিএস, সার্জ প্রোটেকশন"
    );

    fun title(lang: AppLanguage): String =
        if (lang == AppLanguage.BANGLA) titleBn else titleEn

    fun subtitle(lang: AppLanguage): String =
        if (lang == AppLanguage.BANGLA) subtitleBn else subtitleEn

    companion object {
        fun fromId(id: String): ComponentCategory =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: PASSIVE
    }
}
