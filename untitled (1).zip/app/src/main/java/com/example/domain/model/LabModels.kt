package com.example.domain.model

import com.example.core.localization.AppLanguage
import com.squareup.moshi.JsonClass

enum class LabCategory(
    val id: String,
    val titleEn: String,
    val titleBn: String
) {
    RESISTORS("resistors", "Resistors", "রেজিস্টর"),
    CAPACITORS("capacitors", "Capacitors", "ক্যাপাসিটর"),
    INDUCTORS("inductors", "Inductors", "ইন্ডাক্টর"),
    DIODES("diodes", "Diodes", "ডায়োড"),
    LEDS("leds", "LEDs", "এলইডি"),
    TRANSISTORS("transistors", "Transistors", "ট্রানজিস্টর"),
    MOSFETS("mosfets", "MOSFETs", "মসফেট"),
    ICS("ics", "ICs", "আইসি"),
    SWITCHES("switches", "Switches", "সুইচ"),
    PUSH_BUTTONS("push_buttons", "Push Buttons", "পুশ বাটন"),
    BATTERIES("batteries", "Batteries", "ব্যাটারি"),
    DC_POWER_SUPPLIES("dc_power_supplies", "DC Power Supplies", "ডিসি পাওয়ার সাপ্লাই"),
    SENSORS("sensors", "Sensors", "সেন্সর"),
    MOTORS("motors", "Motors", "মোটর"),
    RELAYS("relays", "Relays", "রিলে"),
    ARDUINO_BOARDS("arduino_boards", "Arduino Boards", "আরডুইনো বোর্ড"),
    ESP32_BOARDS("esp32_boards", "ESP32 Boards", "ESP32 বোর্ড"),
    DISPLAYS("displays", "Displays", "ডিসপ্লে"),
    CONNECTORS("connectors", "Connectors", "কানেক্টর"),
    WIRES("wires", "Wires", "তার ও জাম্পার"),
    GROUND_TERMINALS("ground_terminals", "Ground Terminals", "গ্রাউন্ড টার্মিনাল");

    fun title(lang: AppLanguage): String = if (lang == AppLanguage.BANGLA) titleBn else titleEn
}

enum class LabTool {
    SELECT,
    MOVE,
    WIRE,
    DELETE
}

enum class LabRenderMode {
    PERSPECTIVE_3D,
    LIGHTWEIGHT_2D
}

enum class WireRouteStyle(val labelEn: String, val labelBn: String) {
    CURVED("Curved 3D", "বাঁকানো ৩ডি"),
    MANHATTAN("Orthogonal L", "সোজা কোণাকুণি"),
    DIRECT("Straight", "সরাসরি")
}

enum class LabWireColor(val key: String, val nameEn: String, val nameBn: String, val argb: Long) {
    RED("RED", "Red (+VCC)", "লাল (+VCC)", 0xFFEF4444),
    BLACK("BLACK", "Black (GND)", "কালো (GND)", 0xFF1E293B),
    GREEN("GREEN", "Green", "সবুজ", 0xFF10B981),
    BLUE("BLUE", "Blue", "নীল", 0xFF3B82F6),
    YELLOW("YELLOW", "Yellow", "হলুদ", 0xFFF59E0B),
    ORANGE("ORANGE", "Orange", "কমলা", 0xFFF97316),
    PURPLE("PURPLE", "Purple", "বেগুনি", 0xFF8B5CF6),
    WHITE("WHITE", "White", "সাদা", 0xFFE2E8F0)
}

@JsonClass(generateAdapter = true)
data class LabPinSpec(
    val id: String,
    val label: String,
    val localColOffset: Float,
    val localRowOffset: Float
)

data class LabComponentDef(
    val typeId: String,
    val category: LabCategory,
    val nameEn: String,
    val nameBn: String,
    val visualStyle: String,
    val spanCols: Float,
    val spanRows: Float,
    val heightZ: Float,
    val snapToBreadboard: Boolean = true,
    val pins: List<LabPinSpec>,
    val defaultProperties: Map<String, String> = emptyMap()
) {
    fun name(lang: AppLanguage): String = if (lang == AppLanguage.BANGLA) nameBn else nameEn
}

@JsonClass(generateAdapter = true)
data class PlacedComponent(
    val instanceId: String,
    val typeId: String,
    val gridCol: Float, // 0f..29f on breadboard
    val gridRow: Float, // -2f/-1f top rail, 0..4 top area (a..e), 6..10 bottom area (f..j), 12..13 bottom rail
    val rotationDeg: Int = 0, // 0, 90, 180, 270
    val properties: Map<String, String> = emptyMap()
)

@JsonClass(generateAdapter = true)
data class PinEndpoint(
    val isBreadboardHole: Boolean,
    val componentId: String? = null,
    val pinId: String? = null,
    val holeCol: Int = 0,
    val holeRow: Int = 0
) {
    fun canonicalKey(): String = if (isBreadboardHole) {
        "HOLE:${holeCol}:${holeRow}"
    } else {
        "PIN:${componentId}:${pinId}"
    }
}

@JsonClass(generateAdapter = true)
data class LabWire(
    val id: String,
    val start: PinEndpoint,
    val end: PinEndpoint,
    val colorKey: String = LabWireColor.GREEN.key,
    val routeStyle: String = WireRouteStyle.CURVED.name,
    val bendOffset: Float = 0.8f
)

enum class LabInstrumentType(val titleEn: String, val titleBn: String) {
    DIGITAL_MULTIMETER("Digital Multimeter", "ডিজিটাল মাল্টিমিটার"),
    VOLTMETER("Voltmeter", "ভোল্টমিটার"),
    AMMETER("Ammeter", "অ্যামিটার"),
    OSCILLOSCOPE("Oscilloscope", "অসিলোস্কোপ"),
    DC_POWER_SUPPLY("DC Power Supply", "ডিসি পাওয়ার সাপ্লাই");

    fun title(lang: AppLanguage): String = if (lang == AppLanguage.BANGLA) titleBn else titleEn
}

@JsonClass(generateAdapter = true)
data class LabInstrumentState(
    val type: String,
    val mode: String = "VDC",
    val positiveProbeKey: String? = null,
    val negativeProbeKey: String? = null,
    val voltageSetting: Float = 5.0f,
    val currentLimit: Float = 1.0f,
    val timebaseMs: Float = 5.0f,
    val voltsPerDiv: Float = 2.0f,
    val isEnabled: Boolean = false
)

@JsonClass(generateAdapter = true)
data class LabCircuitSnapshot(
    val projectId: Long = 0L,
    val projectName: String = "Untitled Lab Circuit",
    val components: List<PlacedComponent> = emptyList(),
    val wires: List<LabWire> = emptyList(),
    val instruments: List<LabInstrumentState> = emptyList()
)
