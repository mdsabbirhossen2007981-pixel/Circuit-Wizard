package com.example.domain.model

import com.example.core.localization.AppLanguage
import com.squareup.moshi.JsonClass

enum class ExplanationLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}

@JsonClass(generateAdapter = true)
data class TechTerm(
    val termEn: String,
    val meaningBn: String,
    val definitionEn: String,
    val definitionBn: String
) {
    fun definition(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) definitionBn else definitionEn
}

@JsonClass(generateAdapter = true)
data class FormulaItem(
    val formula: String,
    val meaningEn: String,
    val meaningBn: String
) {
    fun meaning(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) meaningBn else meaningEn
}

@JsonClass(generateAdapter = true)
data class CalculationExample(
    val problemEn: String,
    val problemBn: String,
    val stepsEn: List<String>,
    val stepsBn: List<String>,
    val answer: String
) {
    fun problem(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) problemBn else problemEn
    fun steps(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) stepsBn else stepsEn
}

@JsonClass(generateAdapter = true)
data class ExperimentGuide(
    val titleEn: String,
    val titleBn: String,
    val partsEn: List<String>,
    val partsBn: List<String>,
    val stepsEn: List<String>,
    val stepsBn: List<String>
) {
    fun title(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) titleBn else titleEn
    fun parts(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) partsBn else partsEn
    fun steps(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) stepsBn else stepsEn
}

@JsonClass(generateAdapter = true)
data class LessonSeedPayload(
    val id: String,
    val courseId: String,
    val orderIndex: Int,
    val titleEn: String,
    val titleBn: String,
    val estimatedMinutes: Int = 8,
    val symbolType: String,
    val illustrationType: String,
    val circuitDiagramType: String,
    val animationType: String = "CURRENT_FLOW",
    val calculatorType: String? = null,
    val virtualLabCircuitId: String? = null,
    val introductionEn: String,
    val introductionBn: String,
    val englishBanglaTerms: List<TechTerm>,
    val beginnerEn: String,
    val beginnerBn: String,
    val intermediateEn: String,
    val intermediateBn: String,
    val advancedEn: String,
    val advancedBn: String,
    val simpleExplanationEn: String,
    val simpleExplanationBn: String,
    val realLifeAnalogiesEn: List<String>,
    val realLifeAnalogiesBn: List<String>,
    val workingPrincipleEn: String,
    val workingPrincipleBn: String,
    val technicalSpecs: List<SpecItem>,
    val importantFormulas: List<FormulaItem>,
    val stepByStepCalculations: List<CalculationExample>,
    val practicalExperiments: List<ExperimentGuide>,
    val commonMistakesEn: List<String>,
    val commonMistakesBn: List<String>,
    val troubleshootingEn: List<String>,
    val troubleshootingBn: List<String>,
    val summaryEn: String,
    val summaryBn: String,
    val inlineChecks: List<QuizQuestionPayload>,
    val relatedComponentIds: List<String> = emptyList()
)

data class Lesson(
    val payload: LessonSeedPayload,
    val isCompleted: Boolean = false,
    val isBookmarked: Boolean = false,
    val lastViewedAt: Long = 0L,
    val completedAt: Long = 0L
) {
    val id: String get() = payload.id
    val course: AcademyCourse get() = AcademyCourse.fromId(payload.courseId)
    fun title(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.titleBn else payload.titleEn
    fun introduction(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.introductionBn else payload.introductionEn
    fun explanation(level: ExplanationLevel, lang: AppLanguage): String = when (level) {
        ExplanationLevel.BEGINNER -> if (lang == AppLanguage.BANGLA) payload.beginnerBn else payload.beginnerEn
        ExplanationLevel.INTERMEDIATE -> if (lang == AppLanguage.BANGLA) payload.intermediateBn else payload.intermediateEn
        ExplanationLevel.ADVANCED -> if (lang == AppLanguage.BANGLA) payload.advancedBn else payload.advancedEn
    }
    fun simpleExplanation(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.simpleExplanationBn else payload.simpleExplanationEn
    fun analogies(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.realLifeAnalogiesBn else payload.realLifeAnalogiesEn
    fun workingPrinciple(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.workingPrincipleBn else payload.workingPrincipleEn
    fun commonMistakes(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.commonMistakesBn else payload.commonMistakesEn
    fun troubleshooting(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.troubleshootingBn else payload.troubleshootingEn
    fun summary(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) payload.summaryBn else payload.summaryEn
}
