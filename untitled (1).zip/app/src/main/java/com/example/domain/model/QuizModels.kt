package com.example.domain.model

import com.example.core.localization.AppLanguage
import com.squareup.moshi.JsonClass

enum class QuizQuestionType {
    MCQ,
    TRUE_FALSE,
    COMPONENT_ID,
    CIRCUIT_ANALYSIS
}

@JsonClass(generateAdapter = true)
data class QuizQuestionPayload(
    val id: String,
    val courseId: String = "c1_basic",
    val questionType: String = "MCQ", // MCQ, TRUE_FALSE, COMPONENT_ID, CIRCUIT_ANALYSIS
    val promptEn: String,
    val promptBn: String,
    val visualSymbolType: String? = null,
    val visualIllustrationType: String? = null,
    val circuitDiagramType: String? = null,
    val optionsEn: List<String>,
    val optionsBn: List<String>,
    val correctIndex: Int,
    val explanationEn: String,
    val explanationBn: String
) {
    fun prompt(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) promptBn else promptEn
    fun options(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) optionsBn else optionsEn
    fun explanation(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) explanationBn else explanationEn
    fun typeEnum(): QuizQuestionType =
        QuizQuestionType.entries.firstOrNull { it.name == questionType } ?: QuizQuestionType.MCQ
}

data class QuizAttemptRecord(
    val id: Long,
    val courseId: String,
    val quizTitle: String,
    val isTimedExam: Boolean,
    val score: Int,
    val totalQuestions: Int,
    val durationSeconds: Int,
    val wrongQuestionIds: List<String>,
    val timestamp: Long
) {
    val percentage: Int
        get() = if (totalQuestions <= 0) 0 else ((score * 100f) / totalQuestions).toInt()
}

data class LearningAchievement(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val descEn: String,
    val descBn: String,
    val iconKey: String,
    val isUnlocked: Boolean,
    val unlockedAt: Long
) {
    fun title(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) titleBn else titleEn
    fun description(lang: AppLanguage) = if (lang == AppLanguage.BANGLA) descBn else descEn
}
