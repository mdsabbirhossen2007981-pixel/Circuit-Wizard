package com.example.domain.lab

import com.example.domain.model.LabCategory
import com.example.domain.model.LabCircuitSnapshot
import com.example.domain.model.LabComponentDef
import com.example.domain.model.LabInstrumentState
import com.example.domain.model.LabInstrumentType
import com.example.domain.model.LabPinSpec
import com.example.domain.model.LabWire
import com.example.domain.model.LabWireColor
import com.example.domain.model.PinEndpoint
import com.example.domain.model.PlacedComponent

object LabComponentCatalog {

    val all: List<LabComponentDef> = listOf(
        // 1. Resistors
        LabComponentDef(
            typeId = "resistor",
            category = LabCategory.RESISTORS,
            nameEn = "Resistor (4-Band)",
            nameBn = "রেজিস্টর (৪-ব্যান্ড)",
            visualStyle = "RESISTOR_AXIAL",
            spanCols = 4f,
            spanRows = 0.8f,
            heightZ = 0.45f,
            pins = listOf(
                LabPinSpec("p1", "1", 0f, 0f),
                LabPinSpec("p2", "2", 4f, 0f)
            ),
            defaultProperties = mapOf("value" to "330", "unit" to "Ω")
        ),
        LabComponentDef(
            typeId = "potentiometer",
            category = LabCategory.RESISTORS,
            nameEn = "Potentiometer",
            nameBn = "পটেনশিওমিটার",
            visualStyle = "POTENTIOMETER",
            spanCols = 2.6f,
            spanRows = 2.2f,
            heightZ = 0.9f,
            pins = listOf(
                LabPinSpec("t1", "Terminal 1", 0f, 0f),
                LabPinSpec("wiper", "Wiper", 1f, 0f),
                LabPinSpec("t2", "Terminal 2", 2f, 0f)
            ),
            defaultProperties = mapOf("value" to "10", "unit" to "kΩ", "wiperPct" to "50")
        ),
        // 2. Capacitors
        LabComponentDef(
            typeId = "cap_ceramic",
            category = LabCategory.CAPACITORS,
            nameEn = "Ceramic Capacitor",
            nameBn = "সিরামিক ক্যাপাসিটর",
            visualStyle = "CAP_CERAMIC",
            spanCols = 2f,
            spanRows = 0.8f,
            heightZ = 0.65f,
            pins = listOf(
                LabPinSpec("p1", "1", 0f, 0f),
                LabPinSpec("p2", "2", 2f, 0f)
            ),
            defaultProperties = mapOf("capacitance" to "100", "unit" to "nF", "voltageRating" to "50V", "capType" to "Ceramic")
        ),
        LabComponentDef(
            typeId = "cap_electrolytic",
            category = LabCategory.CAPACITORS,
            nameEn = "Electrolytic Capacitor",
            nameBn = "ইলেক্ট্রোলাইটিক ক্যাপাসিটর",
            visualStyle = "CAP_ELECTRO",
            spanCols = 1.6f,
            spanRows = 1.6f,
            heightZ = 1.15f,
            pins = listOf(
                LabPinSpec("pos", "+", 0f, 0f),
                LabPinSpec("neg", "−", 1f, 0f)
            ),
            defaultProperties = mapOf("capacitance" to "100", "unit" to "µF", "voltageRating" to "25V", "capType" to "Electrolytic")
        ),
        // 3. Inductors
        LabComponentDef(
            typeId = "inductor",
            category = LabCategory.INDUCTORS,
            nameEn = "Inductor Coil",
            nameBn = "ইন্ডাক্টর কয়েল",
            visualStyle = "INDUCTOR_COIL",
            spanCols = 3f,
            spanRows = 1.0f,
            heightZ = 0.7f,
            pins = listOf(
                LabPinSpec("p1", "1", 0f, 0f),
                LabPinSpec("p2", "2", 3f, 0f)
            ),
            defaultProperties = mapOf("inductance" to "100", "unit" to "µH")
        ),
        // 4. Diodes
        LabComponentDef(
            typeId = "diode_1n4007",
            category = LabCategory.DIODES,
            nameEn = "PN Diode (1N4007)",
            nameBn = "পিএন ডায়োড (1N4007)",
            visualStyle = "DIODE_AXIAL",
            spanCols = 3f,
            spanRows = 0.8f,
            heightZ = 0.5f,
            pins = listOf(
                LabPinSpec("anode", "A (+)", 0f, 0f),
                LabPinSpec("cathode", "K (−)", 3f, 0f)
            ),
            defaultProperties = mapOf("model" to "1N4007", "vf" to "0.7")
        ),
        LabComponentDef(
            typeId = "diode_zener",
            category = LabCategory.DIODES,
            nameEn = "Zener Diode (5.1V)",
            nameBn = "জেনার ডায়োড (৫.১V)",
            visualStyle = "DIODE_ZENER",
            spanCols = 3f,
            spanRows = 0.8f,
            heightZ = 0.5f,
            pins = listOf(
                LabPinSpec("anode", "A", 0f, 0f),
                LabPinSpec("cathode", "K", 3f, 0f)
            ),
            defaultProperties = mapOf("model" to "1N4733A", "vz" to "5.1")
        ),
        // 5. LEDs
        LabComponentDef(
            typeId = "led_5mm",
            category = LabCategory.LEDS,
            nameEn = "5mm LED",
            nameBn = "৫ মিমি এলইডি",
            visualStyle = "LED_DOME",
            spanCols = 1.4f,
            spanRows = 1.2f,
            heightZ = 0.95f,
            pins = listOf(
                LabPinSpec("anode", "Anode (+)", 0f, 0f),
                LabPinSpec("cathode", "Cathode (−)", 1f, 0f)
            ),
            defaultProperties = mapOf("color" to "Red", "vf" to "2.0", "maxMa" to "20")
        ),
        // 6. Transistors
        LabComponentDef(
            typeId = "bjt_npn",
            category = LabCategory.TRANSISTORS,
            nameEn = "NPN BJT (2N2222)",
            nameBn = "NPN ট্রানজিস্টর",
            visualStyle = "TO92_BJT",
            spanCols = 2.4f,
            spanRows = 1.1f,
            heightZ = 0.85f,
            pins = listOf(
                LabPinSpec("e", "E", 0f, 0f),
                LabPinSpec("b", "B", 1f, 0f),
                LabPinSpec("c", "C", 2f, 0f)
            ),
            defaultProperties = mapOf("part" to "2N2222", "polarity" to "NPN", "hfe" to "150")
        ),
        LabComponentDef(
            typeId = "bjt_pnp",
            category = LabCategory.TRANSISTORS,
            nameEn = "PNP BJT (2N3906)",
            nameBn = "PNP ট্রানজিস্টর",
            visualStyle = "TO92_BJT",
            spanCols = 2.4f,
            spanRows = 1.1f,
            heightZ = 0.85f,
            pins = listOf(
                LabPinSpec("e", "E", 0f, 0f),
                LabPinSpec("b", "B", 1f, 0f),
                LabPinSpec("c", "C", 2f, 0f)
            ),
            defaultProperties = mapOf("part" to "2N3906", "polarity" to "PNP", "hfe" to "120")
        ),
        // 7. MOSFETs
        LabComponentDef(
            typeId = "n_mosfet",
            category = LabCategory.MOSFETS,
            nameEn = "N-MOSFET (IRFZ44N)",
            nameBn = "N-চ্যানেল মসফেট",
            visualStyle = "TO220_MOSFET",
            spanCols = 2.6f,
            spanRows = 1.4f,
            heightZ = 1.35f,
            pins = listOf(
                LabPinSpec("g", "Gate", 0f, 0f),
                LabPinSpec("d", "Drain", 1f, 0f),
                LabPinSpec("s", "Source", 2f, 0f)
            ),
            defaultProperties = mapOf("part" to "IRFZ44N", "vgsTh" to "3.0", "rdsOn" to "0.02")
        ),
        // 8. ICs
        LabComponentDef(
            typeId = "ic_555",
            category = LabCategory.ICS,
            nameEn = "555 Timer IC (DIP-8)",
            nameBn = "৫৫৫ টাইমার আইসি",
            visualStyle = "IC_DIP8",
            spanCols = 3.6f,
            spanRows = 2.4f,
            heightZ = 0.65f,
            pins = listOf(
                LabPinSpec("gnd", "1 GND", 0f, 2f),
                LabPinSpec("trig", "2 TRIG", 1f, 2f),
                LabPinSpec("out", "3 OUT", 2f, 2f),
                LabPinSpec("rst", "4 RST", 3f, 2f),
                LabPinSpec("ctrl", "5 CTRL", 3f, 0f),
                LabPinSpec("thr", "6 THR", 2f, 0f),
                LabPinSpec("dis", "7 DIS", 1f, 0f),
                LabPinSpec("vcc", "8 VCC", 0f, 0f)
            ),
            defaultProperties = mapOf("part" to "NE555", "vccMax" to "15V")
        ),
        LabComponentDef(
            typeId = "ic_lm358",
            category = LabCategory.ICS,
            nameEn = "LM358 Op-Amp (DIP-8)",
            nameBn = "LM358 অপ-অ্যাম্প",
            visualStyle = "IC_DIP8",
            spanCols = 3.6f,
            spanRows = 2.4f,
            heightZ = 0.65f,
            pins = listOf(
                LabPinSpec("out1", "1 OUT1", 0f, 2f),
                LabPinSpec("in1m", "2 IN1-", 1f, 2f),
                LabPinSpec("in1p", "3 IN1+", 2f, 2f),
                LabPinSpec("gnd", "4 GND", 3f, 2f),
                LabPinSpec("in2p", "5 IN2+", 3f, 0f),
                LabPinSpec("in2m", "6 IN2-", 2f, 0f),
                LabPinSpec("out2", "7 OUT2", 1f, 0f),
                LabPinSpec("vcc", "8 VCC", 0f, 0f)
            ),
            defaultProperties = mapOf("part" to "LM358", "gain" to "100dB")
        ),
        // 9. Switches
        LabComponentDef(
            typeId = "slide_switch",
            category = LabCategory.SWITCHES,
            nameEn = "Slide Switch (SPDT)",
            nameBn = "স্লাইড সুইচ",
            visualStyle = "SWITCH_SLIDE",
            spanCols = 2.4f,
            spanRows = 1.2f,
            heightZ = 0.7f,
            pins = listOf(
                LabPinSpec("t1", "T1", 0f, 0f),
                LabPinSpec("com", "COM", 1f, 0f),
                LabPinSpec("t2", "T2", 2f, 0f)
            ),
            defaultProperties = mapOf("state" to "OFF")
        ),
        // 10. Push Buttons
        LabComponentDef(
            typeId = "pushbutton",
            category = LabCategory.PUSH_BUTTONS,
            nameEn = "Tactile Push Button",
            nameBn = "পুশ বাটন",
            visualStyle = "PUSHBUTTON",
            spanCols = 2.4f,
            spanRows = 2.2f,
            heightZ = 0.75f,
            pins = listOf(
                LabPinSpec("a1", "1A", 0f, 0f),
                LabPinSpec("a2", "1B", 2f, 0f),
                LabPinSpec("b1", "2A", 0f, 2f),
                LabPinSpec("b2", "2B", 2f, 2f)
            ),
            defaultProperties = mapOf("state" to "OFF")
        ),
        // 11. Batteries
        LabComponentDef(
            typeId = "battery_9v",
            category = LabCategory.BATTERIES,
            nameEn = "9V Battery",
            nameBn = "৯ ভোল্ট ব্যাটারি",
            visualStyle = "BATTERY_9V",
            spanCols = 3.2f,
            spanRows = 4.6f,
            heightZ = 1.3f,
            snapToBreadboard = false,
            pins = listOf(
                LabPinSpec("pos", "+9V", 0f, 0f),
                LabPinSpec("neg", "−", 2f, 0f)
            ),
            defaultProperties = mapOf("voltage" to "9.0", "polarity" to "Normal")
        ),
        LabComponentDef(
            typeId = "battery_aa",
            category = LabCategory.BATTERIES,
            nameEn = "AA 1.5V Cell",
            nameBn = "AA ১.৫V ব্যাটারি",
            visualStyle = "BATTERY_AA",
            spanCols = 4.0f,
            spanRows = 2.0f,
            heightZ = 1.1f,
            snapToBreadboard = false,
            pins = listOf(
                LabPinSpec("pos", "+", 0f, 0f),
                LabPinSpec("neg", "−", 3f, 0f)
            ),
            defaultProperties = mapOf("voltage" to "1.5", "polarity" to "Normal")
        ),
        // 12. DC Power Supplies
        LabComponentDef(
            typeId = "dc_psu",
            category = LabCategory.DC_POWER_SUPPLIES,
            nameEn = "Bench DC Power Supply",
            nameBn = "বেঞ্চ ডিসি পাওয়ার সাপ্লাই",
            visualStyle = "BENCH_PSU",
            spanCols = 5.4f,
            spanRows = 3.6f,
            heightZ = 1.7f,
            snapToBreadboard = false,
            pins = listOf(
                LabPinSpec("pos", "+VCC", 1f, 3f),
                LabPinSpec("neg", "−GND", 4f, 3f)
            ),
            defaultProperties = mapOf("voltage" to "5.0", "currentLimit" to "1.5", "state" to "ON")
        ),
        // 13. Sensors
        LabComponentDef(
            typeId = "ldr_sensor",
            category = LabCategory.SENSORS,
            nameEn = "Photoresistor (LDR)",
            nameBn = "এলডিআর লাইট সেন্সর",
            visualStyle = "SENSOR_LDR",
            spanCols = 2.0f,
            spanRows = 1.0f,
            heightZ = 0.6f,
            pins = listOf(
                LabPinSpec("p1", "1", 0f, 0f),
                LabPinSpec("p2", "2", 2f, 0f)
            ),
            defaultProperties = mapOf("luxLevel" to "500", "darkOhms" to "100000")
        ),
        LabComponentDef(
            typeId = "hcsr04",
            category = LabCategory.SENSORS,
            nameEn = "HC-SR04 Ultrasonic",
            nameBn = "আল্ট্রাসনিক সেন্সর",
            visualStyle = "SENSOR_HCSR04",
            spanCols = 4.2f,
            spanRows = 2.2f,
            heightZ = 1.25f,
            pins = listOf(
                LabPinSpec("vcc", "VCC", 0f, 0f),
                LabPinSpec("trig", "TRIG", 1f, 0f),
                LabPinSpec("echo", "ECHO", 2f, 0f),
                LabPinSpec("gnd", "GND", 3f, 0f)
            ),
            defaultProperties = mapOf("distanceCm" to "40")
        ),
        // 14. Motors
        LabComponentDef(
            typeId = "dc_motor",
            category = LabCategory.MOTORS,
            nameEn = "DC Motor",
            nameBn = "ডিসি মোটর",
            visualStyle = "MOTOR_DC",
            spanCols = 3.6f,
            spanRows = 3.0f,
            heightZ = 1.5f,
            snapToBreadboard = false,
            pins = listOf(
                LabPinSpec("t1", "T1 (+)", 0f, 1f),
                LabPinSpec("t2", "T2 (−)", 3f, 1f)
            ),
            defaultProperties = mapOf("ratedV" to "6.0", "rpm" to "6000")
        ),
        // 15. Relays
        LabComponentDef(
            typeId = "relay_5v",
            category = LabCategory.RELAYS,
            nameEn = "5V SPDT Relay",
            nameBn = "৫V এসপিডিটি রিলে",
            visualStyle = "RELAY_5V",
            spanCols = 3.2f,
            spanRows = 2.4f,
            heightZ = 1.4f,
            pins = listOf(
                LabPinSpec("coil1", "COIL1", 0f, 0f),
                LabPinSpec("com", "COM", 0f, 1f),
                LabPinSpec("coil2", "COIL2", 0f, 2f),
                LabPinSpec("no", "NO", 3f, 0f),
                LabPinSpec("nc", "NC", 3f, 2f)
            ),
            defaultProperties = mapOf("coilV" to "5.0", "coilOhms" to "70")
        ),
        // 16. Arduino Boards
        LabComponentDef(
            typeId = "arduino_uno",
            category = LabCategory.ARDUINO_BOARDS,
            nameEn = "Arduino UNO R3",
            nameBn = "আরডুইনো ইউনো R3",
            visualStyle = "BOARD_UNO",
            spanCols = 9.0f,
            spanRows = 6.2f,
            heightZ = 0.9f,
            snapToBreadboard = false,
            pins = listOf(
                LabPinSpec("5v", "5V", 1f, 5f),
                LabPinSpec("gnd", "GND", 2f, 5f),
                LabPinSpec("a0", "A0", 5f, 5f),
                LabPinSpec("d13", "D13", 3f, 0f),
                LabPinSpec("d9", "D9~", 5f, 0f),
                LabPinSpec("d2", "D2", 7f, 0f)
            ),
            defaultProperties = mapOf("logicV" to "5.0V", "clockMHz" to "16")
        ),
        // 17. ESP32 Boards
        LabComponentDef(
            typeId = "esp32_devkit",
            category = LabCategory.ESP32_BOARDS,
            nameEn = "ESP32 DevKit V1",
            nameBn = "ESP32 ডেভকিট বোর্ড",
            visualStyle = "BOARD_ESP32",
            spanCols = 7.4f,
            spanRows = 3.4f,
            heightZ = 0.85f,
            snapToBreadboard = false,
            pins = listOf(
                LabPinSpec("3v3", "3V3", 0f, 0f),
                LabPinSpec("gnd", "GND", 1f, 0f),
                LabPinSpec("gpio2", "G2", 4f, 0f),
                LabPinSpec("gpio4", "G4", 5f, 0f),
                LabPinSpec("vin", "VIN", 0f, 3f),
                LabPinSpec("gpio34", "G34", 4f, 3f)
            ),
            defaultProperties = mapOf("logicV" to "3.3V", "wifi" to "Enabled")
        ),
        // 18. Displays
        LabComponentDef(
            typeId = "seven_seg",
            category = LabCategory.DISPLAYS,
            nameEn = "7-Segment Display",
            nameBn = "৭-সেগমেন্ট ডিসপ্লে",
            visualStyle = "DISPLAY_7SEG",
            spanCols = 4.2f,
            spanRows = 2.6f,
            heightZ = 0.85f,
            pins = listOf(
                LabPinSpec("a", "A", 3f, 0f),
                LabPinSpec("b", "B", 4f, 0f),
                LabPinSpec("com_top", "COM", 2f, 0f),
                LabPinSpec("d", "D", 1f, 2f),
                LabPinSpec("e", "E", 0f, 2f),
                LabPinSpec("com_bot", "COM", 2f, 2f)
            ),
            defaultProperties = mapOf("type" to "Common Cathode", "color" to "Red")
        ),
        LabComponentDef(
            typeId = "lcd_16x2",
            category = LabCategory.DISPLAYS,
            nameEn = "16×2 LCD Module",
            nameBn = "১৬×২ এলসিডি ডিসপ্লে",
            visualStyle = "DISPLAY_LCD16X2",
            spanCols = 9.0f,
            spanRows = 3.6f,
            heightZ = 0.9f,
            snapToBreadboard = false,
            pins = listOf(
                LabPinSpec("vss", "GND", 0f, 0f),
                LabPinSpec("vdd", "VCC", 1f, 0f),
                LabPinSpec("sda", "SDA", 2f, 0f),
                LabPinSpec("scl", "SCL", 3f, 0f)
            ),
            defaultProperties = mapOf("interface" to "I2C 0x27", "backlight" to "Green")
        ),
        // 19. Connectors
        LabComponentDef(
            typeId = "screw_terminal",
            category = LabCategory.CONNECTORS,
            nameEn = "2-Pin Screw Terminal",
            nameBn = "স্ক্রু টার্মিনাল ব্লক",
            visualStyle = "SCREW_TERM",
            spanCols = 2.0f,
            spanRows = 1.4f,
            heightZ = 0.95f,
            pins = listOf(
                LabPinSpec("p1", "1", 0f, 0f),
                LabPinSpec("p2", "2", 1f, 0f)
            ),
            defaultProperties = mapOf("pitchMm" to "5.08")
        ),
        // 20. Wires (Jumper preset block + activates Wire Tool)
        LabComponentDef(
            typeId = "jumper_bridge",
            category = LabCategory.WIRES,
            nameEn = "Preformed Jumper Bridge",
            nameBn = "জাম্পার ব্রিজ তার",
            visualStyle = "WIRE_BRIDGE",
            spanCols = 3f,
            spanRows = 0.4f,
            heightZ = 0.3f,
            pins = listOf(
                LabPinSpec("p1", "A", 0f, 0f),
                LabPinSpec("p2", "B", 3f, 0f)
            ),
            defaultProperties = mapOf("color" to "Green")
        ),
        // 21. Ground Terminals
        LabComponentDef(
            typeId = "ground_terminal",
            category = LabCategory.GROUND_TERMINALS,
            nameEn = "Ground Terminal (0V)",
            nameBn = "গ্রাউন্ড টার্মিনাল (0V)",
            visualStyle = "GND_TERM",
            spanCols = 1.4f,
            spanRows = 1.4f,
            heightZ = 0.7f,
            pins = listOf(
                LabPinSpec("gnd", "GND", 0f, 0f)
            ),
            defaultProperties = mapOf("reference" to "0.0V Earth")
        )
    )

    private val byId = all.associateBy { it.typeId }

    fun find(typeId: String): LabComponentDef? = byId[typeId]

    fun defaultLedCircuitStarter(): LabCircuitSnapshot {
        val bat = PlacedComponent(
            instanceId = "cmp_bat_1",
            typeId = "battery_9v",
            gridCol = 1f,
            gridRow = -7.5f,
            properties = mapOf("voltage" to "9.0", "polarity" to "Normal")
        )
        val res = PlacedComponent(
            instanceId = "cmp_res_1",
            typeId = "resistor",
            gridCol = 6f,
            gridRow = 2f,
            properties = mapOf("value" to "330", "unit" to "Ω")
        )
        val led = PlacedComponent(
            instanceId = "cmp_led_1",
            typeId = "led_5mm",
            gridCol = 12f,
            gridRow = 2f,
            properties = mapOf("color" to "Red", "vf" to "2.0", "maxMa" to "20")
        )
        val sw = PlacedComponent(
            instanceId = "cmp_sw_1",
            typeId = "slide_switch",
            gridCol = 16f,
            gridRow = 7f,
            properties = mapOf("state" to "ON")
        )
        val w1 = LabWire(
            id = "wire_1",
            start = PinEndpoint(isBreadboardHole = false, componentId = "cmp_bat_1", pinId = "pos"),
            end = PinEndpoint(isBreadboardHole = true, holeCol = 6, holeRow = -2),
            colorKey = LabWireColor.RED.key
        )
        val w2 = LabWire(
            id = "wire_2",
            start = PinEndpoint(isBreadboardHole = true, holeCol = 6, holeRow = -2),
            end = PinEndpoint(isBreadboardHole = true, holeCol = 6, holeRow = 4),
            colorKey = LabWireColor.RED.key
        )
        val w3 = LabWire(
            id = "wire_3",
            start = PinEndpoint(isBreadboardHole = true, holeCol = 10, holeRow = 4),
            end = PinEndpoint(isBreadboardHole = true, holeCol = 12, holeRow = 4),
            colorKey = LabWireColor.YELLOW.key
        )
        val w4 = LabWire(
            id = "wire_4",
            start = PinEndpoint(isBreadboardHole = true, holeCol = 13, holeRow = 4),
            end = PinEndpoint(isBreadboardHole = true, holeCol = 16, holeRow = 6),
            colorKey = LabWireColor.BLUE.key
        )
        val w5 = LabWire(
            id = "wire_5",
            start = PinEndpoint(isBreadboardHole = true, holeCol = 17, holeRow = 8),
            end = PinEndpoint(isBreadboardHole = true, holeCol = 17, holeRow = -1),
            colorKey = LabWireColor.BLACK.key
        )
        val w6 = LabWire(
            id = "wire_6",
            start = PinEndpoint(isBreadboardHole = false, componentId = "cmp_bat_1", pinId = "neg"),
            end = PinEndpoint(isBreadboardHole = true, holeCol = 3, holeRow = -1),
            colorKey = LabWireColor.BLACK.key
        )
        val defaultInstruments = LabInstrumentType.entries.map { type ->
            when (type) {
                LabInstrumentType.DIGITAL_MULTIMETER -> LabInstrumentState(
                    type = type.name,
                    mode = "VDC",
                    positiveProbeKey = "PIN:cmp_led_1:anode",
                    negativeProbeKey = "HOLE:0:-1",
                    isEnabled = true
                )
                LabInstrumentType.VOLTMETER -> LabInstrumentState(
                    type = type.name,
                    positiveProbeKey = "PIN:cmp_led_1:anode",
                    negativeProbeKey = "HOLE:0:-1",
                    isEnabled = true
                )
                LabInstrumentType.AMMETER -> LabInstrumentState(
                    type = type.name,
                    positiveProbeKey = "PIN:cmp_res_1:p1",
                    negativeProbeKey = "HOLE:0:-1",
                    isEnabled = false
                )
                LabInstrumentType.OSCILLOSCOPE -> LabInstrumentState(
                    type = type.name,
                    positiveProbeKey = "PIN:cmp_led_1:anode",
                    negativeProbeKey = "HOLE:0:-1",
                    voltsPerDiv = 2.0f,
                    timebaseMs = 10.0f,
                    isEnabled = true
                )
                LabInstrumentType.DC_POWER_SUPPLY -> LabInstrumentState(
                    type = type.name,
                    mode = type.name
                )
            }
        }
        return LabCircuitSnapshot(
            projectName = "LED & 330Ω Starter Bench",
            components = listOf(bat, res, led, sw),
            wires = listOf(w1, w2, w3, w4, w5, w6),
            instruments = defaultInstruments
        )
    }
}
