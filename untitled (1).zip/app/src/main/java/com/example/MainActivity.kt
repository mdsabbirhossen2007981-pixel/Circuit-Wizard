package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.localization.AppLanguage
import com.example.ui.AppViewModel
import com.example.ui.navigation.CircuitWizardAppShell
import com.example.ui.theme.CircuitWizardTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        val container = (application as CircuitWizardApp).container

        setContent {
            val appViewModel: AppViewModel = viewModel(
                factory = AppViewModel.Factory(container)
            )
            val isDarkTheme by appViewModel.isDarkTheme.collectAsStateWithLifecycle()
            val language by appViewModel.language.collectAsStateWithLifecycle()

            LaunchedEffect(isDarkTheme) {
                val style = if (isDarkTheme) {
                    SystemBarStyle.dark(Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }

            CircuitWizardTheme(
                darkTheme = isDarkTheme,
                isBangla = language == AppLanguage.BANGLA
            ) {
                CircuitWizardAppShell(
                    appViewModel = appViewModel,
                    container = container
                )
            }
        }
    }
}
