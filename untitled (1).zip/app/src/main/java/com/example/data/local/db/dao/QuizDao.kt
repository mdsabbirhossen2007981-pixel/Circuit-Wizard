package com.example.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.db.entity.AchievementEntity
import com.example.data.local.db.entity.QuizAttemptEntity
import com.example.data.local.db.entity.QuizQuestionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QuizDao {
    @Query("SELECT * FROM quiz_questions")
    fun observeAllQuestions(): Flow<List<QuizQuestionEntity>>

    @Query("SELECT * FROM quiz_questions WHERE courseId = :courseId")
    fun observeQuestionsByCourse(courseId: String): Flow<List<QuizQuestionEntity>>

    @Query("SELECT * FROM quiz_questions")
    suspend fun getAllQuestionsOnce(): List<QuizQuestionEntity>

    @Query("SELECT * FROM quiz_questions WHERE courseId = :courseId")
    suspend fun getQuestionsByCourseOnce(courseId: String): List<QuizQuestionEntity>

    @Query("SELECT COUNT(*) FROM quiz_questions")
    suspend fun countQuestions(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertQuestions(items: List<QuizQuestionEntity>)

    @Query("SELECT * FROM quiz_attempts ORDER BY timestamp DESC")
    fun observeAttempts(): Flow<List<QuizAttemptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttempt(attempt: QuizAttemptEntity): Long

    @Query("SELECT * FROM achievements")
    fun observeAchievements(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements")
    suspend fun getAchievementsOnce(): List<AchievementEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun unlockAchievement(item: AchievementEntity)
}
