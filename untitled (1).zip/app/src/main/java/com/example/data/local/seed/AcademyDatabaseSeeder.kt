package com.example.data.local.seed

import android.content.Context
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.dao.LessonDao
import com.example.data.local.db.dao.QuizDao
import com.example.data.local.db.entity.LessonEntity
import com.example.data.local.db.entity.QuizQuestionEntity
import com.example.domain.model.LessonSeedPayload
import com.example.domain.model.QuizQuestionPayload
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class AcademyDatabaseSeeder(
    private val context: Context,
    private val lessonDao: LessonDao,
    private val quizDao: QuizDao,
    private val userPrefsStore: UserPrefsStore,
    private val moshi: Moshi
) {
    private val mutex = Mutex()

    suspend fun ensureSeeded() = mutex.withLock {
        withContext(Dispatchers.IO) {
            val currentVersion = userPrefsStore.academySeedVersion.first()
            val lessonCount = lessonDao.countAll()
            val questionCount = quizDao.countQuestions()
            if (currentVersion >= CURRENT_ACADEMY_SEED_VERSION && lessonCount >= 61 && questionCount > 0) {
                return@withContext
            }

            val existingStates = lessonDao.getUserStates().associateBy { it.id }

            val lessonListType = Types.newParameterizedType(List::class.java, LessonSeedPayload::class.java)
            val lessonListAdapter = moshi.adapter<List<LessonSeedPayload>>(lessonListType)
            val lessonItemAdapter = moshi.adapter(LessonSeedPayload::class.java)

            val seedFiles = context.assets.list("seed").orEmpty().sorted()

            val lessonEntities = mutableListOf<LessonEntity>()
            for (fileName in seedFiles.filter { it.startsWith("academy_") && it.endsWith(".json") }) {
                val jsonText = context.assets.open("seed/$fileName")
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                val payloads = lessonListAdapter.fromJson(jsonText).orEmpty()
                for (payload in payloads) {
                    val userState = existingStates[payload.id]
                    val searchable = buildString {
                        append(payload.titleEn).append(' ')
                        append(payload.titleBn).append(' ')
                        append(payload.introductionEn).append(' ')
                        append(payload.introductionBn).append(' ')
                        payload.englishBanglaTerms.forEach {
                            append(it.termEn).append(' ').append(it.meaningBn).append(' ')
                        }
                    }.lowercase()

                    lessonEntities += LessonEntity(
                        id = payload.id,
                        courseId = payload.courseId,
                        orderIndex = payload.orderIndex,
                        titleEn = payload.titleEn,
                        titleBn = payload.titleBn,
                        estimatedMinutes = payload.estimatedMinutes,
                        searchableText = searchable,
                        payloadJson = lessonItemAdapter.toJson(payload),
                        isCompleted = userState?.isCompleted ?: false,
                        isBookmarked = userState?.isBookmarked ?: false,
                        lastViewedAt = userState?.lastViewedAt ?: 0L,
                        completedAt = userState?.completedAt ?: 0L
                    )
                }
            }

            if (lessonEntities.isNotEmpty()) {
                lessonDao.upsertAll(lessonEntities)
            }

            val quizListType = Types.newParameterizedType(List::class.java, QuizQuestionPayload::class.java)
            val quizListAdapter = moshi.adapter<List<QuizQuestionPayload>>(quizListType)
            val quizItemAdapter = moshi.adapter(QuizQuestionPayload::class.java)

            val quizEntities = mutableListOf<QuizQuestionEntity>()
            for (fileName in seedFiles.filter { it.startsWith("quizzes_") && it.endsWith(".json") }) {
                val jsonText = context.assets.open("seed/$fileName")
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                val payloads = quizListAdapter.fromJson(jsonText).orEmpty()
                for (q in payloads) {
                    quizEntities += QuizQuestionEntity(
                        id = q.id,
                        courseId = q.courseId,
                        questionType = q.questionType,
                        payloadJson = quizItemAdapter.toJson(q)
                    )
                }
            }

            if (quizEntities.isNotEmpty()) {
                quizDao.upsertQuestions(quizEntities)
            }

            if (lessonEntities.isNotEmpty() && quizEntities.isNotEmpty()) {
                userPrefsStore.setAcademySeedVersion(CURRENT_ACADEMY_SEED_VERSION)
            }
        }
    }

    companion object {
        const val CURRENT_ACADEMY_SEED_VERSION = 1
    }
}
