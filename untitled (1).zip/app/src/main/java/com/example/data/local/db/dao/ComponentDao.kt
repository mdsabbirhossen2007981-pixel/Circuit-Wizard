package com.example.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.db.entity.ComponentEntity
import kotlinx.coroutines.flow.Flow

data class UserComponentState(
    val id: String,
    val isBookmarked: Boolean,
    val isStudied: Boolean,
    val lastViewedAt: Long,
    val viewCount: Int
)

@Dao
interface ComponentDao {
    @Query("SELECT * FROM components ORDER BY categoryId ASC, orderIndex ASC")
    fun observeAll(): Flow<List<ComponentEntity>>

    @Query("SELECT * FROM components WHERE id = :id LIMIT 1")
    fun observeById(id: String): Flow<ComponentEntity?>

    @Query("SELECT * FROM components WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ComponentEntity?

    @Query("SELECT * FROM components WHERE isBookmarked = 1 ORDER BY nameEn ASC")
    fun observeBookmarked(): Flow<List<ComponentEntity>>

    @Query("SELECT * FROM components WHERE lastViewedAt > 0 ORDER BY lastViewedAt DESC LIMIT :limit")
    fun observeRecentlyViewed(limit: Int = 10): Flow<List<ComponentEntity>>

    @Query("SELECT COUNT(*) FROM components")
    suspend fun countAll(): Int

    @Query("SELECT id, isBookmarked, isStudied, lastViewedAt, viewCount FROM components")
    suspend fun getUserStates(): List<UserComponentState>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ComponentEntity>)

    @Query("UPDATE components SET isBookmarked = :bookmarked WHERE id = :id")
    suspend fun setBookmarked(id: String, bookmarked: Boolean)

    @Query("UPDATE components SET isStudied = :studied WHERE id = :id")
    suspend fun setStudied(id: String, studied: Boolean)

    @Query("UPDATE components SET lastViewedAt = :timestamp, viewCount = viewCount + 1 WHERE id = :id")
    suspend fun recordView(id: String, timestamp: Long)
}
