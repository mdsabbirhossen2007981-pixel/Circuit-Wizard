package com.example.data.local.seed

import android.content.Context
import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.dao.ComponentDao
import com.example.data.local.db.entity.ComponentEntity
import com.example.domain.model.ComponentSeedPayload
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class DatabaseSeeder(
    private val context: Context,
    private val componentDao: ComponentDao,
    private val userPrefsStore: UserPrefsStore,
    private val moshi: Moshi
) {
    private val mutex = Mutex()

    suspend fun ensureSeeded() = mutex.withLock {
        withContext(Dispatchers.IO) {
            val currentSeedVersion = userPrefsStore.seedVersion.first()
            val count = componentDao.countAll()
            if (currentSeedVersion >= CURRENT_SEED_VERSION && count > 0) {
                return@withContext
            }

            val existingStates = componentDao.getUserStates().associateBy { it.id }
            val listType = Types.newParameterizedType(
                List::class.java,
                ComponentSeedPayload::class.java
            )
            val listAdapter = moshi.adapter<List<ComponentSeedPayload>>(listType)
            val itemAdapter = moshi.adapter(ComponentSeedPayload::class.java)

            val assetFiles = context.assets.list("seed")
                ?.filter { it.startsWith("catalog_") && it.endsWith(".json") }
                ?.sorted()
                .orEmpty()

            val entities = mutableListOf<ComponentEntity>()
            for (fileName in assetFiles) {
                val jsonText = context.assets.open("seed/$fileName")
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                val payloads = listAdapter.fromJson(jsonText).orEmpty()
                for (payload in payloads) {
                    val userState = existingStates[payload.id]
                    val searchable = buildString {
                        append(payload.nameEn).append(' ')
                        append(payload.nameBn).append(' ')
                        append(payload.summaryEn).append(' ')
                        append(payload.summaryBn).append(' ')
                        append(payload.categoryId).append(' ')
                        payload.typesAndVariations.forEach {
                            append(it.nameEn).append(' ').append(it.nameBn).append(' ')
                        }
                        payload.commonApplicationsEn.forEach { append(it).append(' ') }
                    }.lowercase()

                    entities += ComponentEntity(
                        id = payload.id,
                        categoryId = payload.categoryId,
                        orderIndex = payload.orderIndex,
                        featured = payload.featured,
                        nameEn = payload.nameEn,
                        nameBn = payload.nameBn,
                        summaryEn = payload.summaryEn,
                        summaryBn = payload.summaryBn,
                        searchableText = searchable,
                        payloadJson = itemAdapter.toJson(payload),
                        isBookmarked = userState?.isBookmarked ?: false,
                        isStudied = userState?.isStudied ?: false,
                        lastViewedAt = userState?.lastViewedAt ?: 0L,
                        viewCount = userState?.viewCount ?: 0
                    )
                }
            }

            if (entities.isNotEmpty()) {
                componentDao.upsertAll(entities)
                userPrefsStore.setSeedVersion(CURRENT_SEED_VERSION)
            }
        }
    }

    companion object {
        const val CURRENT_SEED_VERSION = 1
    }
}
