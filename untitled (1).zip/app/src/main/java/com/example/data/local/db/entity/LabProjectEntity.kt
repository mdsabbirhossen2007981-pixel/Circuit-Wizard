package com.example.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lab_projects")
data class LabProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val snapshotJson: String,
    val componentCount: Int,
    val wireCount: Int,
    val updatedAt: Long
)
