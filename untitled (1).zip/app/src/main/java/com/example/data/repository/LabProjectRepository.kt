package com.example.data.repository

import com.example.data.local.db.dao.LabProjectDao
import com.example.data.local.db.entity.LabProjectEntity
import com.example.domain.model.LabCircuitSnapshot
import com.squareup.moshi.Moshi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class SavedLabProjectSummary(
    val id: Long,
    val name: String,
    val componentCount: Int,
    val wireCount: Int,
    val updatedAt: Long
)

class LabProjectRepository(
    private val labProjectDao: LabProjectDao,
    moshi: Moshi
) {
    private val snapshotAdapter = moshi.adapter(LabCircuitSnapshot::class.java)

    fun observeSavedProjects(): Flow<List<SavedLabProjectSummary>> =
        labProjectDao.observeAll().map { rows ->
            rows.map { row ->
                SavedLabProjectSummary(
                    id = row.id,
                    name = row.name,
                    componentCount = row.componentCount,
                    wireCount = row.wireCount,
                    updatedAt = row.updatedAt
                )
            }
        }

    suspend fun saveProject(snapshot: LabCircuitSnapshot, nameOverride: String? = null): Long {
        val cleanName = (nameOverride ?: snapshot.projectName).trim().ifEmpty { "Untitled Lab Circuit" }
        val normalized = snapshot.copy(projectName = cleanName)
        val json = snapshotAdapter.toJson(normalized)
        val entity = LabProjectEntity(
            id = if (normalized.projectId > 0L) normalized.projectId else 0L,
            name = cleanName,
            snapshotJson = json,
            componentCount = normalized.components.size,
            wireCount = normalized.wires.size,
            updatedAt = System.currentTimeMillis()
        )
        return labProjectDao.upsert(entity)
    }

    suspend fun loadProject(id: Long): LabCircuitSnapshot? {
        val row = labProjectDao.getById(id) ?: return null
        val decoded = snapshotAdapter.fromJson(row.snapshotJson) ?: return null
        return decoded.copy(projectId = row.id, projectName = row.name)
    }

    suspend fun deleteProject(id: Long) {
        labProjectDao.deleteById(id)
    }
}
