package com.example.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.db.dao.ComponentDao
import com.example.data.local.db.dao.LabProjectDao
import com.example.data.local.db.dao.LessonDao
import com.example.data.local.db.dao.QuizDao
import com.example.data.local.db.entity.AchievementEntity
import com.example.data.local.db.entity.ComponentEntity
import com.example.data.local.db.entity.LabProjectEntity
import com.example.data.local.db.entity.LessonEntity
import com.example.data.local.db.entity.LessonNoteEntity
import com.example.data.local.db.entity.QuizAttemptEntity
import com.example.data.local.db.entity.QuizQuestionEntity

@Database(
    entities = [
        ComponentEntity::class,
        LessonEntity::class,
        LessonNoteEntity::class,
        QuizQuestionEntity::class,
        QuizAttemptEntity::class,
        AchievementEntity::class,
        LabProjectEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class CircuitDatabase : RoomDatabase() {
    abstract fun componentDao(): ComponentDao
    abstract fun lessonDao(): LessonDao
    abstract fun quizDao(): QuizDao
    abstract fun labProjectDao(): LabProjectDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `lessons` (
                        `id` TEXT NOT NULL,
                        `courseId` TEXT NOT NULL,
                        `orderIndex` INTEGER NOT NULL,
                        `titleEn` TEXT NOT NULL,
                        `titleBn` TEXT NOT NULL,
                        `estimatedMinutes` INTEGER NOT NULL,
                        `searchableText` TEXT NOT NULL,
                        `payloadJson` TEXT NOT NULL,
                        `isCompleted` INTEGER NOT NULL DEFAULT 0,
                        `isBookmarked` INTEGER NOT NULL DEFAULT 0,
                        `lastViewedAt` INTEGER NOT NULL DEFAULT 0,
                        `completedAt` INTEGER NOT NULL DEFAULT 0,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `lesson_notes` (
                        `lessonId` TEXT NOT NULL,
                        `noteText` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`lessonId`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `quiz_questions` (
                        `id` TEXT NOT NULL,
                        `courseId` TEXT NOT NULL,
                        `questionType` TEXT NOT NULL,
                        `payloadJson` TEXT NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `quiz_attempts` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `courseId` TEXT NOT NULL,
                        `quizTitle` TEXT NOT NULL,
                        `isTimedExam` INTEGER NOT NULL,
                        `score` INTEGER NOT NULL,
                        `totalQuestions` INTEGER NOT NULL,
                        `durationSeconds` INTEGER NOT NULL,
                        `wrongQuestionIdsJson` TEXT NOT NULL,
                        `timestamp` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `achievements` (
                        `id` TEXT NOT NULL,
                        `unlockedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `lab_projects` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `name` TEXT NOT NULL,
                        `snapshotJson` TEXT NOT NULL,
                        `componentCount` INTEGER NOT NULL,
                        `wireCount` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }
    }
}
