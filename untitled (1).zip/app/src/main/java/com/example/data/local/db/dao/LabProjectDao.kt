package com.example.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.db.entity.LabProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LabProjectDao {
    @Query("SELECT * FROM lab_projects ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<LabProjectEntity>>

    @Query("SELECT * FROM lab_projects WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): LabProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: LabProjectEntity): Long

    @Query("DELETE FROM lab_projects WHERE id = :id")
    suspend fun deleteById(id: Long)
}
