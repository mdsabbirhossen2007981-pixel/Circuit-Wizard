package com.example.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.db.entity.LessonEntity
import com.example.data.local.db.entity.LessonNoteEntity
import com.example.data.local.db.entity.LessonUserStateTuple
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonDao {
    @Query("SELECT * FROM lessons ORDER BY courseId ASC, orderIndex ASC")
    fun observeAll(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE courseId = :courseId ORDER BY orderIndex ASC")
    fun observeByCourse(courseId: String): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE id = :id LIMIT 1")
    fun observeById(id: String): Flow<LessonEntity?>

    @Query("SELECT * FROM lessons WHERE isBookmarked = 1 ORDER BY courseId ASC, orderIndex ASC")
    fun observeBookmarked(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE lastViewedAt > 0 ORDER BY lastViewedAt DESC LIMIT 1")
    fun observeLastViewed(): Flow<LessonEntity?>

    @Query("SELECT COUNT(*) FROM lessons")
    suspend fun countAll(): Int

    @Query("SELECT COUNT(*) FROM lessons WHERE isCompleted = 1")
    suspend fun countCompleted(): Int

    @Query("SELECT COUNT(DISTINCT courseId) FROM lessons WHERE lastViewedAt > 0 OR isCompleted = 1")
    suspend fun countExploredCourses(): Int

    @Query("SELECT id, isCompleted, isBookmarked, lastViewedAt, completedAt FROM lessons")
    suspend fun getUserStates(): List<LessonUserStateTuple>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<LessonEntity>)

    @Query("UPDATE lessons SET isCompleted = CASE WHEN isCompleted = 1 THEN 0 ELSE 1 END, completedAt = CASE WHEN isCompleted = 1 THEN 0 ELSE :ts END WHERE id = :id")
    suspend fun toggleCompleted(id: String, ts: Long)

    @Query("UPDATE lessons SET isBookmarked = CASE WHEN isBookmarked = 1 THEN 0 ELSE 1 END WHERE id = :id")
    suspend fun toggleBookmark(id: String)

    @Query("UPDATE lessons SET lastViewedAt = :ts WHERE id = :id")
    suspend fun recordView(id: String, ts: Long)

    @Query("SELECT * FROM lesson_notes WHERE lessonId = :lessonId LIMIT 1")
    fun observeNote(lessonId: String): Flow<LessonNoteEntity?>

    @Query("SELECT * FROM lesson_notes ORDER BY updatedAt DESC")
    fun observeAllNotes(): Flow<List<LessonNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(note: LessonNoteEntity)
}
