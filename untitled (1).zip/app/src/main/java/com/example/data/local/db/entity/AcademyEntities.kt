package com.example.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val orderIndex: Int,
    val titleEn: String,
    val titleBn: String,
    val estimatedMinutes: Int,
    val searchableText: String,
    val payloadJson: String,
    val isCompleted: Boolean = false,
    val isBookmarked: Boolean = false,
    val lastViewedAt: Long = 0L,
    val completedAt: Long = 0L
)

data class LessonUserStateTuple(
    val id: String,
    val isCompleted: Boolean,
    val isBookmarked: Boolean,
    val lastViewedAt: Long,
    val completedAt: Long
)

@Entity(tableName = "lesson_notes")
data class LessonNoteEntity(
    @PrimaryKey val lessonId: String,
    val noteText: String,
    val updatedAt: Long
)

@Entity(tableName = "quiz_questions")
data class QuizQuestionEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val questionType: String,
    val payloadJson: String
)

@Entity(tableName = "quiz_attempts")
data class QuizAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val courseId: String,
    val quizTitle: String,
    val isTimedExam: Boolean,
    val score: Int,
    val totalQuestions: Int,
    val durationSeconds: Int,
    val wrongQuestionIdsJson: String,
    val timestamp: Long
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val unlockedAt: Long
)
