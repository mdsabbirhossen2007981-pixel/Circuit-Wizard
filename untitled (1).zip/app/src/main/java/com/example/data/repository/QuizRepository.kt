package com.example.data.repository

import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.dao.QuizDao
import com.example.data.local.db.entity.AchievementEntity
import com.example.data.local.db.entity.QuizAttemptEntity
import com.example.data.local.db.entity.QuizQuestionEntity
import com.example.data.local.seed.AcademyDatabaseSeeder
import com.example.domain.model.LearningAchievement
import com.example.domain.model.QuizAttemptRecord
import com.example.domain.model.QuizQuestionPayload
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class QuizRepository(
    private val quizDao: QuizDao,
    private val prefsStore: UserPrefsStore,
    private val seeder: AcademyDatabaseSeeder,
    moshi: Moshi
) {
    private val questionAdapter = moshi.adapter(QuizQuestionPayload::class.java)
    private val stringListAdapter = moshi.adapter<List<String>>(
        Types.newParameterizedType(List::class.java, String::class.java)
    )

    suspend fun initializeQuizzes() {
        seeder.ensureSeeded()
    }

    fun observeAllQuestions(): Flow<List<QuizQuestionPayload>> =
        quizDao.observeAllQuestions().map { list -> list.mapNotNull { it.toDomain() } }

    suspend fun getQuestionsForSession(courseId: String?, timedExam: Boolean): List<QuizQuestionPayload> {
        seeder.ensureSeeded()
        val raw = if (courseId == null || courseId == "ALL") {
            quizDao.getAllQuestionsOnce()
        } else {
            quizDao.getQuestionsByCourseOnce(courseId)
        }
        val parsed = raw.mapNotNull { it.toDomain() }
        return if (timedExam) {
            parsed.shuffled().take(15.coerceAtMost(parsed.size))
        } else {
            parsed
        }
    }

    fun observeAttempts(): Flow<List<QuizAttemptRecord>> =
        quizDao.observeAttempts().map { rows ->
            rows.map { row ->
                QuizAttemptRecord(
                    id = row.id,
                    courseId = row.courseId,
                    quizTitle = row.quizTitle,
                    isTimedExam = row.isTimedExam,
                    score = row.score,
                    totalQuestions = row.totalQuestions,
                    durationSeconds = row.durationSeconds,
                    wrongQuestionIds = runCatching {
                        stringListAdapter.fromJson(row.wrongQuestionIdsJson).orEmpty()
                    }.getOrDefault(emptyList()),
                    timestamp = row.timestamp
                )
            }
        }

    suspend fun saveAttempt(
        courseId: String,
        quizTitle: String,
        isTimedExam: Boolean,
        score: Int,
        totalQuestions: Int,
        durationSeconds: Int,
        wrongQuestionIds: List<String>
    ) {
        val now = System.currentTimeMillis()
        quizDao.insertAttempt(
            QuizAttemptEntity(
                courseId = courseId,
                quizTitle = quizTitle,
                isTimedExam = isTimedExam,
                score = score,
                totalQuestions = totalQuestions,
                durationSeconds = durationSeconds,
                wrongQuestionIdsJson = stringListAdapter.toJson(wrongQuestionIds),
                timestamp = now
            )
        )
        prefsStore.recordDailyStudyActivity()

        val pct = if (totalQuestions > 0) (score * 100) / totalQuestions else 0
        if (pct >= 80) {
            quizDao.unlockAchievement(AchievementEntity("ach_quiz_master", now))
        }
        if (isTimedExam && pct >= 70) {
            quizDao.unlockAchievement(AchievementEntity("ach_timed_exam_pass", now))
        }
    }

    fun observeAchievements(): Flow<List<LearningAchievement>> =
        quizDao.observeAchievements().map { unlockedRows ->
            val unlockedMap = unlockedRows.associate { it.id to it.unlockedAt }
            achievementCatalog.map { def ->
                val ts = unlockedMap[def.id]
                def.copy(isUnlocked = ts != null, unlockedAt = ts ?: 0L)
            }
        }

    private fun QuizQuestionEntity.toDomain(): QuizQuestionPayload? =
        runCatching { questionAdapter.fromJson(payloadJson) }.getOrNull()

    companion object {
        val achievementCatalog = listOf(
            LearningAchievement(
                id = "ach_first_lesson",
                titleEn = "First Spark",
                titleBn = "প্রথম স্ফুলিঙ্গ",
                descEn = "Completed your very first Academy lesson",
                descBn = "অ্যাকাডেমির প্রথম পাঠ সম্পন্ন করেছেন",
                iconKey = "BOLT",
                isUnlocked = false,
                unlockedAt = 0L
            ),
            LearningAchievement(
                id = "ach_course_scholar",
                titleEn = "Circuit Scholar",
                titleBn = "সার্কিট স্কলার",
                descEn = "Completed 12 lessons across the Academy",
                descBn = "অ্যাকাডেমিতে ১২টি পাঠ সম্পন্ন করেছেন",
                iconKey = "SCHOOL",
                isUnlocked = false,
                unlockedAt = 0L
            ),
            LearningAchievement(
                id = "ach_halfway_engineer",
                titleEn = "Lab Technician",
                titleBn = "ল্যাব টেকনিশিয়ান",
                descEn = "Completed 30+ engineering lessons",
                descBn = "৩০টির বেশি ইঞ্জিনিয়ারিং পাঠ সম্পন্ন করেছেন",
                iconKey = "ENGINEERING",
                isUnlocked = false,
                unlockedAt = 0L
            ),
            LearningAchievement(
                id = "ach_all_courses_explorer",
                titleEn = "All-Discipline Explorer",
                titleBn = "সর্ববিষয়ক অন্বেষী",
                descEn = "Explored lessons in all 7 Academy courses",
                descBn = "অ্যাকাডেমির সব ৭টি কোর্স পরিদর্শন করেছেন",
                iconKey = "EXPLORE",
                isUnlocked = false,
                unlockedAt = 0L
            ),
            LearningAchievement(
                id = "ach_quiz_master",
                titleEn = "Precision Scorer",
                titleBn = "নির্ভুল পরীক্ষার্থী",
                descEn = "Scored 80% or higher in an Academy quiz",
                descBn = "যেকোনো কুইজে ৮০% বা তার বেশি নম্বর অর্জন করেছেন",
                iconKey = "TROPHY",
                isUnlocked = false,
                unlockedAt = 0L
            ),
            LearningAchievement(
                id = "ach_timed_exam_pass",
                titleEn = "Exam Certified",
                titleBn = "পরীক্ষায় উত্তীর্ণ",
                descEn = "Passed a Timed Electronics Examination (>=70%)",
                descBn = "সময়সীমাবদ্ধ পরীক্ষায় (>=৭০%) উত্তীর্ণ হয়েছেন",
                iconKey = "TIMER",
                isUnlocked = false,
                unlockedAt = 0L
            ),
            LearningAchievement(
                id = "ach_streak_3",
                titleEn = "3-Day Lab Habit",
                titleBn = "৩ দিনের অভ্যাস",
                descEn = "Studied electronics 3 days in a row",
                descBn = "টানা ৩ দিন ইলেকট্রনিক্স অধ্যয়ন করেছেন",
                iconKey = "FLAME",
                isUnlocked = false,
                unlockedAt = 0L
            ),
            LearningAchievement(
                id = "ach_streak_7",
                titleEn = "7-Day Bench Master",
                titleBn = "৭ দিনের মাস্টার",
                descEn = "Maintained a full 7-day learning streak",
                descBn = "টানা ৭ দিনের লার্নিং স্ট্রিক ধরে রেখেছেন",
                iconKey = "AWARD",
                isUnlocked = false,
                unlockedAt = 0L
            )
        )
    }
}
