package com.example.data.repository

import com.example.data.local.db.dao.ComponentDao
import com.example.data.local.db.entity.ComponentEntity
import com.example.data.local.seed.DatabaseSeeder
import com.example.domain.model.ComponentSeedPayload
import com.example.domain.model.ElectronicComponent
import com.squareup.moshi.Moshi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ComponentRepository(
    private val componentDao: ComponentDao,
    private val seeder: DatabaseSeeder,
    moshi: Moshi
) {
    private val payloadAdapter = moshi.adapter(ComponentSeedPayload::class.java)

    suspend fun initializeCatalog() {
        seeder.ensureSeeded()
    }

    fun observeAllComponents(): Flow<List<ElectronicComponent>> =
        componentDao.observeAll().map { list -> list.mapNotNull { it.toDomain() } }

    fun observeComponentById(id: String): Flow<ElectronicComponent?> =
        componentDao.observeById(id).map { it?.toDomain() }

    fun observeBookmarkedComponents(): Flow<List<ElectronicComponent>> =
        componentDao.observeBookmarked().map { list -> list.mapNotNull { it.toDomain() } }

    fun observeRecentlyViewed(limit: Int = 10): Flow<List<ElectronicComponent>> =
        componentDao.observeRecentlyViewed(limit).map { list -> list.mapNotNull { it.toDomain() } }

    suspend fun toggleBookmark(id: String) {
        val current = componentDao.getById(id) ?: return
        componentDao.setBookmarked(id, !current.isBookmarked)
    }

    suspend fun toggleStudied(id: String) {
        val current = componentDao.getById(id) ?: return
        componentDao.setStudied(id, !current.isStudied)
    }

    suspend fun recordComponentView(id: String) {
        componentDao.recordView(id, System.currentTimeMillis())
    }

    private fun ComponentEntity.toDomain(): ElectronicComponent? {
        val payload = payloadAdapter.fromJson(payloadJson) ?: return null
        return ElectronicComponent(
            payload = payload,
            isBookmarked = isBookmarked,
            isStudied = isStudied,
            lastViewedAt = lastViewedAt,
            viewCount = viewCount
        )
    }
}
