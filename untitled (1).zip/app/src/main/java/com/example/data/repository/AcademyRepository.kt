package com.example.data.repository

import com.example.data.local.datastore.UserPrefsStore
import com.example.data.local.db.dao.LessonDao
import com.example.data.local.db.dao.QuizDao
import com.example.data.local.db.entity.AchievementEntity
import com.example.data.local.db.entity.LessonEntity
import com.example.data.local.db.entity.LessonNoteEntity
import com.example.data.local.seed.AcademyDatabaseSeeder
import com.example.domain.model.AcademyCourse
import com.example.domain.model.Lesson
import com.example.domain.model.LessonSeedPayload
import com.squareup.moshi.Moshi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AcademyRepository(
    private val lessonDao: LessonDao,
    private val quizDao: QuizDao,
    private val prefsStore: UserPrefsStore,
    private val seeder: AcademyDatabaseSeeder,
    moshi: Moshi
) {
    private val payloadAdapter = moshi.adapter(LessonSeedPayload::class.java)

    suspend fun initializeAcademy() {
        seeder.ensureSeeded()
    }

    fun observeAllLessons(): Flow<List<Lesson>> =
        lessonDao.observeAll().map { entities -> entities.mapNotNull { it.toDomain() } }

    fun observeLessonsByCourse(course: AcademyCourse): Flow<List<Lesson>> =
        lessonDao.observeByCourse(course.id).map { entities -> entities.mapNotNull { it.toDomain() } }

    fun observeLessonById(id: String): Flow<Lesson?> =
        lessonDao.observeById(id).map { it?.toDomain() }

    fun observeBookmarkedLessons(): Flow<List<Lesson>> =
        lessonDao.observeBookmarked().map { entities -> entities.mapNotNull { it.toDomain() } }

    fun observeContinueLearningLesson(): Flow<Lesson?> =
        lessonDao.observeLastViewed().map { it?.toDomain() }

    fun observeLessonNote(lessonId: String): Flow<String> =
        lessonDao.observeNote(lessonId).map { it?.noteText.orEmpty() }

    fun observeAllNotes(): Flow<List<LessonNoteEntity>> =
        lessonDao.observeAllNotes()

    suspend fun recordLessonView(lessonId: String) {
        val now = System.currentTimeMillis()
        lessonDao.recordView(lessonId, now)
        val streak = prefsStore.recordDailyStudyActivity()
        checkAndUnlockStudyAchievements(streak)
    }

    suspend fun toggleLessonCompleted(lessonId: String) {
        val now = System.currentTimeMillis()
        lessonDao.toggleCompleted(lessonId, now)
        val streak = prefsStore.recordDailyStudyActivity()
        checkAndUnlockStudyAchievements(streak)
    }

    suspend fun toggleLessonBookmark(lessonId: String) {
        lessonDao.toggleBookmark(lessonId)
    }

    suspend fun saveLessonNote(lessonId: String, text: String) {
        lessonDao.upsertNote(
            LessonNoteEntity(
                lessonId = lessonId,
                noteText = text.trim(),
                updatedAt = System.currentTimeMillis()
            )
        )
        val streak = prefsStore.recordDailyStudyActivity()
        checkAndUnlockStudyAchievements(streak)
    }

    private suspend fun checkAndUnlockStudyAchievements(streakDays: Int) {
        val now = System.currentTimeMillis()
        val completedCount = lessonDao.countCompleted()
        val exploredCourses = lessonDao.countExploredCourses()

        if (completedCount >= 1) {
            quizDao.unlockAchievement(AchievementEntity("ach_first_lesson", now))
        }
        if (completedCount >= 12) {
            quizDao.unlockAchievement(AchievementEntity("ach_course_scholar", now))
        }
        if (completedCount >= 30) {
            quizDao.unlockAchievement(AchievementEntity("ach_halfway_engineer", now))
        }
        if (exploredCourses >= 7) {
            quizDao.unlockAchievement(AchievementEntity("ach_all_courses_explorer", now))
        }
        if (streakDays >= 3) {
            quizDao.unlockAchievement(AchievementEntity("ach_streak_3", now))
        }
        if (streakDays >= 7) {
            quizDao.unlockAchievement(AchievementEntity("ach_streak_7", now))
        }
    }

    private fun LessonEntity.toDomain(): Lesson? {
        val payload = payloadAdapter.fromJson(payloadJson) ?: return null
        return Lesson(
            payload = payload,
            isCompleted = isCompleted,
            isBookmarked = isBookmarked,
            lastViewedAt = lastViewedAt,
            completedAt = completedAt
        )
    }
}
