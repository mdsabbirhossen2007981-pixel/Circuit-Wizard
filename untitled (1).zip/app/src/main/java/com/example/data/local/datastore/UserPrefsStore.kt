package com.example.data.local.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.localization.AppLanguage
import com.example.core.localization.SortOrder
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "circuit_wizard_prefs")

data class StreakInfo(
    val currentDays: Int = 0,
    val longestDays: Int = 0,
    val lastStudyEpochDay: Long = -1L
)

class UserPrefsStore(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val LANGUAGE = stringPreferencesKey("app_language")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val SEED_VERSION = intPreferencesKey("catalog_seed_version")
        val ACADEMY_SEED_VERSION = intPreferencesKey("academy_seed_version")
        val CURRENT_STREAK = intPreferencesKey("current_streak_days")
        val LONGEST_STREAK = intPreferencesKey("longest_streak_days")
        val LAST_STUDY_DAY = longPreferencesKey("last_study_epoch_day")
    }

    val isDarkTheme: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.DARK_THEME] ?: true // Dark laboratory theme is default
    }

    val language: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        AppLanguage.fromCode(prefs[Keys.LANGUAGE])
    }

    val sortOrder: Flow<SortOrder> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.SORT_ORDER]
        SortOrder.entries.firstOrNull { it.name == raw } ?: SortOrder.CURATED
    }

    val seedVersion: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.SEED_VERSION] ?: 0
    }

    val academySeedVersion: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.ACADEMY_SEED_VERSION] ?: 0
    }

    val streakInfo: Flow<StreakInfo> = context.dataStore.data.map { prefs ->
        StreakInfo(
            currentDays = prefs[Keys.CURRENT_STREAK] ?: 0,
            longestDays = prefs[Keys.LONGEST_STREAK] ?: 0,
            lastStudyEpochDay = prefs[Keys.LAST_STUDY_DAY] ?: -1L
        )
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setSortOrder(order: SortOrder) {
        context.dataStore.edit { it[Keys.SORT_ORDER] = order.name }
    }

    suspend fun setSeedVersion(version: Int) {
        context.dataStore.edit { it[Keys.SEED_VERSION] = version }
    }

    suspend fun setAcademySeedVersion(version: Int) {
        context.dataStore.edit { it[Keys.ACADEMY_SEED_VERSION] = version }
    }

    suspend fun recordDailyStudyActivity(epochDay: Long = System.currentTimeMillis() / 86_400_000L): Int {
        var resultingStreak = 1
        context.dataStore.edit { prefs ->
            val lastDay = prefs[Keys.LAST_STUDY_DAY] ?: -1L
            val cur = prefs[Keys.CURRENT_STREAK] ?: 0
            val best = prefs[Keys.LONGEST_STREAK] ?: 0
            val next = when {
                lastDay == epochDay -> cur.coerceAtLeast(1)
                lastDay == epochDay - 1L -> cur + 1
                else -> 1
            }
            prefs[Keys.LAST_STUDY_DAY] = epochDay
            prefs[Keys.CURRENT_STREAK] = next
            if (next > best) {
                prefs[Keys.LONGEST_STREAK] = next
            }
            resultingStreak = next
        }
        return resultingStreak
    }
}
