package com.example.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "components")
data class ComponentEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val orderIndex: Int,
    val featured: Boolean,
    val nameEn: String,
    val nameBn: String,
    val summaryEn: String,
    val summaryBn: String,
    val searchableText: String,
    val payloadJson: String,
    val isBookmarked: Boolean = false,
    val isStudied: Boolean = false,
    val lastViewedAt: Long = 0L,
    val viewCount: Int = 0
)
